/*
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 */
package br.org.sidi.technicalreport.features.report.view

import android.arch.lifecycle.Observer
import android.arch.lifecycle.ViewModelProviders
import android.content.Intent
import android.os.Bundle
import android.support.v4.view.ViewPager
import android.support.v7.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import br.org.sidi.technicalreport.R
import br.org.sidi.technicalreport.common.camera.CameraActivity
import br.org.sidi.technicalreport.features.report.model.Report
import br.org.sidi.technicalreport.features.report.view.components.VerticalViewPagerComponent
import br.org.sidi.technicalreport.features.report.viewmodel.ReportViewModel
import br.org.sidi.technicalreport.util.Logger
import br.org.sidi.technicalreport.util.ToastUtils
import br.org.sidi.technicalreport.util.hideSoftKeyBoard
import kotlinx.android.synthetic.main.activity_content_view_page.*
import org.jetbrains.anko.alert

class CreateReportActivity : AppCompatActivity(), VerticalViewPagerComponent.OnScrollUpListener {
    companion object {
        const val RESULT_SUCCESS_SEND_REPORT = 4542

        const val REQUEST_PREVIEW_REPORT = 4123

        const val RESULT_OUT_OF_SYNC_PRODUCT = 5001
        const val RESULT_OUT_OF_SYNC_DEFECT = 5002
        const val RESULT_OUT_OF_SYNC_CAUSE = 5003
        const val RESULT_OUT_OF_SYNC_EVIDENCES = 5004

        const val ACTION_DETAILS = "ACTION_DETAILS"
    }

    private var currentPage = 0
    private val viewPageAdapter: ReportPagerAdapter by lazy { ReportPagerAdapter(supportFragmentManager) }

    private val customerPageFragment: CustomerPageFragment by lazy { viewPageAdapter.getItem(ReportPagerAdapter.CUSTOMER_PAGE_POSITION) as CustomerPageFragment }
    private val technicalReportPageFragment: TechnicalReportPageFragment by lazy { viewPageAdapter.getItem(ReportPagerAdapter.TECHNICAL_REPORT_PAGE_POSITION) as TechnicalReportPageFragment }
    private val symptomPageFragment: SymptomPageFragment by lazy { viewPageAdapter.getItem(ReportPagerAdapter.SYMPTOM_PAGE_POSITION) as SymptomPageFragment }
    private val evidencePageFragment: EvidencePageFragment by lazy { viewPageAdapter.getItem(ReportPagerAdapter.EVIDENCE_PAGE_POSITION) as EvidencePageFragment }
    private var errorCountList = mutableMapOf<Int, Int>()

    val reportViewModel: ReportViewModel by lazy { ViewModelProviders.of(this).get(ReportViewModel::class.java) }

    private val fragments: Array<AbstractReportPageFragment> = arrayOf(customerPageFragment, technicalReportPageFragment, symptomPageFragment, evidencePageFragment)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_content_view_page)

        setupToolbar()
        init()

        setupPageView()
        configureOnPageChange()

        reportViewModel.getTechnicalReportValid().observe(this, Observer { isValid ->
            Logger.info("IsValidTech: $isValid")
            if (isValid == true) {
                viewPageAdapter.currentTotalPages = ReportPagerAdapter.SYMPTOM_PAGE_POSITION + 1
            } else {
                viewPageAdapter.currentTotalPages = ReportPagerAdapter.TECHNICAL_REPORT_PAGE_POSITION + 1
            }
            viewPageAdapter.notifyDataSetChanged()
        })

        reportViewModel.getSymptomValid().observe(this, Observer { isValid ->
            Logger.info("IsValidSYM: $isValid")
            if (isValid == true) {
                viewPageAdapter.currentTotalPages = ReportPagerAdapter.EVIDENCE_PAGE_POSITION + 1
            } else {
                viewPageAdapter.currentTotalPages = ReportPagerAdapter.SYMPTOM_PAGE_POSITION + 1
            }
            viewPageAdapter.notifyDataSetChanged()
        })

    }

    private fun setupPageView() {
        pager.isSaveEnabled = false
        pager.offscreenPageLimit = ReportPagerAdapter.TOTAL_PAGES
        pager.adapter = viewPageAdapter
        pager.onScrollUpListener = this
        pager.isDrawingCacheEnabled = false

        count_label.text = getString(R.string.label_page_count, currentPage, viewPageAdapter.count)
    }

    private fun setupToolbar() {
        supportActionBar?.title = getString(R.string.new_report_title)
        supportActionBar?.setHomeAsUpIndicator(R.drawable.ic_baseline_close_24px)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when (item?.itemId) {
            android.R.id.home -> tryExitScreen()
            R.id.save_report -> {
                fragments.forEach { if (it.isAdded) it.setValuesToViewModel() }
                //we need validate only OS number to save report in client database
                val errorCount = technicalReportPageFragment.validateForSave()
                if (errorCount > 0) {
                    pager.currentItem = ReportPagerAdapter.TECHNICAL_REPORT_PAGE_POSITION
                } else {
                    reportViewModel.saveReport()
                    fragments.forEach { if (it.isAdded) it.hasChange = false }
                    ToastUtils.createToast(this, R.string.report_saved_successfully)
                }
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.menu_create_report, menu)



        return true
    }

    override fun onBackPressed() {
        tryExitScreen()
    }

    private fun tryExitScreen() {
        if (fragments.any { it.hasChange }) {
            alert(getString(R.string.leave_without_saving_warning)) {
                positiveButton(getString(R.string.exit)) { finish() }
                negativeButton(getString(R.string.cancel)) { it.cancel() }
            }.show()
        } else {
            finish()
        }
    }

    private fun init() {
        previous_button.setOnClickListener { v -> onClick(v) }
        next_button.setOnClickListener { v -> onClick(v) }

        inflateConfirmationButtonView()
    }

    override fun onStart() {
        super.onStart()
        val action = intent.getStringExtra(getString(R.string.action_details_key))
        when(action) {
            PreviewReportActivity.PREVIEW_REPORT -> {
                supportActionBar?.title = intent.getStringExtra(Intent.EXTRA_TITLE) ?: getString(R.string.new_report_title)
                val report = intent.getSerializableExtra(getString(R.string.report_key))
                reportViewModel.setReport(report as Report)
            }
        }
    }

    private fun inflateConfirmationButtonView() {
        view_report_button.setOnClickListener { v -> onClick(v) }
    }

    private fun configureOnPageChange() {
        pager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {

            override fun onPageSelected(position: Int) {

                when (position) {
                    ReportPagerAdapter.CUSTOMER_PAGE_POSITION -> {
                        content_report_button.visibility = View.GONE
                    }
                    ReportPagerAdapter.TECHNICAL_REPORT_PAGE_POSITION -> {
                        content_report_button.visibility = View.GONE
                    }
                    ReportPagerAdapter.SYMPTOM_PAGE_POSITION -> {
                        content_report_button.visibility = View.GONE
                    }
                    ReportPagerAdapter.EVIDENCE_PAGE_POSITION -> {
                        content_report_button.visibility = View.VISIBLE
                    }
                }
            }

            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
                updatePager()
            }

            override fun onPageScrollStateChanged(state: Int) {
                // TODO: There is no implementation for this method
                Logger.info("onPageScrollStateChanged $state")
            }
        })
    }

    private fun buttonEnabled(position: Int) {
        previous_button.isEnabled = ReportPagerAdapter.CUSTOMER_PAGE_POSITION != position
        next_button.isEnabled = ReportPagerAdapter.EVIDENCE_PAGE_POSITION != position
    }

    private fun onClick(v: View?) {
        window.decorView.rootView.hideSoftKeyBoard()
        when (v!!.id) {
            R.id.previous_button -> previousPage()
            R.id.next_button -> nextPage()
            R.id.view_report_button -> verifyFragmentsFields()
        }
    }

    private fun updatePager() {
        currentPage = pager.currentItem
        count_label.text = getString(R.string.label_page_count, currentPage + 1, ReportPagerAdapter.TOTAL_PAGES)
        buttonEnabled(currentPage)
    }

    private fun verifyFragmentsFields() {
        val errorCount = validateAllFields()

        if (errorCount > 0) {
            moveToPageWithErrorInFields()
        } else {
            evidencePageFragment.setValuesToViewModel()
            openReportPreview(reportViewModel.getReport().value!!)

        }
    }

    private fun openReportPreview(report: Report) {
        val intent = Intent(this, PreviewReportActivity::class.java)
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        intent.putExtra(PreviewReportActivity.REPORT_KEY, report)
        startActivityForResult(intent, REQUEST_PREVIEW_REPORT)
    }

    private fun validateAllFields(): Int {
        errorCountList[ReportPagerAdapter.CUSTOMER_PAGE_POSITION] = customerPageFragment.validateFields()
        errorCountList[ReportPagerAdapter.TECHNICAL_REPORT_PAGE_POSITION] = technicalReportPageFragment.validateFieldsEmpty()
        errorCountList[ReportPagerAdapter.SYMPTOM_PAGE_POSITION] = symptomPageFragment.validateFieldsEmpty()
        errorCountList[ReportPagerAdapter.EVIDENCE_PAGE_POSITION] = evidencePageFragment.validateFieldsEmpty()

        return errorCountList.values.sum()
    }

    private fun moveToPageWithErrorInFields() {
        when {
            errorCountList[ReportPagerAdapter.CUSTOMER_PAGE_POSITION]!! > 0 -> {
                pager.currentItem = ReportPagerAdapter.CUSTOMER_PAGE_POSITION
            }
            errorCountList[ReportPagerAdapter.TECHNICAL_REPORT_PAGE_POSITION]!! > 0 -> {
                pager.currentItem = ReportPagerAdapter.TECHNICAL_REPORT_PAGE_POSITION
            }
            errorCountList[ReportPagerAdapter.SYMPTOM_PAGE_POSITION]!! > 0 -> {
                pager.currentItem = ReportPagerAdapter.SYMPTOM_PAGE_POSITION
            }
            errorCountList[ReportPagerAdapter.EVIDENCE_PAGE_POSITION]!! > 0 -> {
                pager.currentItem = ReportPagerAdapter.EVIDENCE_PAGE_POSITION
            }
            else -> {
                openReportPreview(reportViewModel.getReport().value!!)
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            EvidencePageFragment.START_GET_IMAGE -> handleCameraResult(resultCode, data)
            REQUEST_PREVIEW_REPORT -> handlePreviewResult(resultCode)
        }
    }

    private fun handlePreviewResult(resultCode: Int) {
        when (resultCode) {
            RESULT_SUCCESS_SEND_REPORT -> {
                setResult(RESULT_SUCCESS_SEND_REPORT)
                finish()
            }
            RESULT_OUT_OF_SYNC_PRODUCT -> handleProductOutOfSync()
            RESULT_OUT_OF_SYNC_DEFECT -> handleDefectOutOfSync()
            RESULT_OUT_OF_SYNC_CAUSE -> handleCauseOutOfSync()
        }
    }

    private fun handleProductOutOfSync() {
        reportViewModel.productSwitch.value = !(reportViewModel.productSwitch.value ?: true)
        handleDefectOutOfSync(false)
        pager.currentItem = ReportPagerAdapter.TECHNICAL_REPORT_PAGE_POSITION
    }

    private fun handleDefectOutOfSync(goToPage: Boolean = true) {
        reportViewModel.defectSwitch.value = !(reportViewModel.defectSwitch.value ?: true)
        handleCauseOutOfSync(false)

        if (goToPage) {
            pager.currentItem = ReportPagerAdapter.SYMPTOM_PAGE_POSITION
        }
    }

    private fun handleCauseOutOfSync(goToPage: Boolean = true) {
        reportViewModel.causeSwitch.value = !(reportViewModel.causeSwitch.value ?: true)

        if (goToPage) {
            pager.currentItem = ReportPagerAdapter.SYMPTOM_PAGE_POSITION
        }
    }

    private fun handleCameraResult(resultCode: Int, data: Intent?) {
        when (resultCode) {
            CameraActivity.RESULT_FROM_IMAGE -> {
                reportViewModel.evidencePathMap[data?.getStringExtra(CameraActivity.EVIDENCE_TITLE)!!] = data.getStringExtra(CameraActivity.IMAGE_PATH)
            }
        }
    }

    private fun previousPage() = pager.arrowScroll(View.FOCUS_LEFT)

    fun nextPage() {
        val isPageFieldsValid = viewPageAdapter.getItem(pager.currentItem).validateToNextPage()
        if (isPageFieldsValid) {
            pager.arrowScroll(View.FOCUS_RIGHT)
        }
    }

    override fun onScrollUp(motionY: Float) {
        viewPageAdapter.getItem(pager.currentItem).validateToNextPage()
    }

}