/*
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 */
package br.org.sidi.technicalreport.features.report.view

import android.arch.lifecycle.Observer
import android.arch.lifecycle.ViewModelProviders
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import br.org.sidi.technicalreport.R
import br.org.sidi.technicalreport.common.validation.CheckValueHelper.Companion.greaterThanZero
import br.org.sidi.technicalreport.common.validation.CheckValueHelper.Companion.noXSS
import br.org.sidi.technicalreport.common.validation.CheckValueHelper.Companion.required
import br.org.sidi.technicalreport.common.validation.GetValueHelper.Companion.fromCustomSpinnerPosition
import br.org.sidi.technicalreport.common.validation.GetValueHelper.Companion.fromEditText
import br.org.sidi.technicalreport.common.validation.SetErrorHelper.Companion.toCustomSpinner
import br.org.sidi.technicalreport.common.validation.SetErrorHelper.Companion.toInputLayout
import br.org.sidi.technicalreport.common.validation.Validation
import br.org.sidi.technicalreport.features.report.model.Product
import br.org.sidi.technicalreport.features.report.model.Report
import br.org.sidi.technicalreport.features.report.viewmodel.ReportViewModel
import br.org.sidi.technicalreport.features.report.viewmodel.TechnicalReportViewModel
import br.org.sidi.technicalreport.util.hideSoftKeyBoard
import br.org.sidi.technicalreport.util.valueText
import kotlinx.android.synthetic.main.fragment_technical_report.view.*
import org.apache.commons.lang3.StringUtils
import org.jetbrains.anko.noButton
import org.jetbrains.anko.okButton
import org.jetbrains.anko.sdk25.coroutines.onEditorAction
import org.jetbrains.anko.support.v4.alert
import org.jetbrains.anko.yesButton

class TechnicalReportPageFragment : AbstractReportPageFragment() {

    companion object {
        private const val OS_NUMBER_LENGTH = 10
    }

    private lateinit var rootView: ViewGroup
    private val reportViewModel: ReportViewModel
        get() = (activity!! as CreateReportActivity).reportViewModel
    private val technicalReportViewModel: TechnicalReportViewModel by lazy { ViewModelProviders.of(this).get(TechnicalReportViewModel::class.java) }
    private var validation = Validation()

    private var validationToNextPage = Validation()

    override fun onPageHide() {
        setValuesToViewModel()
    }

    private fun init() {
        // This is to avoid execute some code in method onItemSelected() when the onItemSelectedListener is set in spinner
        var spinnerCreated = false

        setProductAdapter(technicalReportViewModel.productList)

        rootView.let {
            addTouchListener(it.productSpinner.getInput(), it.orderServiceEditText, it.deviceModelEditText, it.serialNumberEditText)
        }

        rootView.productSpinner.getSelectedItemPosition().observe(this, Observer { position ->
            if (spinnerCreated) {
                if (position == -1) {
                    reportViewModel.setTechnicalReportValid(false)
                    reportViewModel.lastProductSelectedPosition = -1
                    reportViewModel.setProductSelectedId(0)
                } else {
                    if (reportViewModel.lastProductSelectedPosition != -1 &&
                            position != reportViewModel.lastProductSelectedPosition &&
                            reportViewModel.checkNeedsWarning()) {
                        alert(getString(R.string.change_product_warning)) {
                            isCancelable = false
                            yesButton { fireProductSelectedCallback(position!!) }
                            noButton { setSpinnerToPreviouslySelectedProduct() }
                        }.show()
                    } else if (position != reportViewModel.lastProductSelectedPosition) {
                        fireProductSelectedCallback(position!!)
                    }
                }
            } else {
                spinnerCreated = true
            }
        })


        rootView.orderServiceEditText.onEditorAction { v, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_NEXT) {
                rootView.hideSoftKeyBoard()
                v?.clearFocus()
                rootView.productSpinner.requestFocus()
                rootView.productSpinner.performClick()
            }
        }

        rootView.serialNumberEditText.onEditorAction { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                rootView.hideSoftKeyBoard()
                rootView.postDelayed({
                    (activity as CreateReportActivity).nextPage()
                }, 300)
            }
        }
    }

    private fun setSpinnerToPreviouslySelectedProduct() {
        rootView.productSpinner.setSelection(reportViewModel.lastProductSelectedPosition + 1)
    }

    private fun setProductAdapter(list: List<Product>?) {
        if (list == null || list.count() == 0) {
            alert(getString(R.string.no_product_available)) {
                isCancelable = false
                okButton { activity?.finish() }
            }.show()
            return
        }

        rootView.productSpinner.setData(list.map { prod -> prod.name }.toTypedArray(), R.string.select_product)
        rootView.productSpinner.observeListDimensions(rootView.referenceProductSpinner)
    }

    private fun showDialogLackCauses() {
        alert(getString(R.string.product_no_contains_defects)) {
            okButton { setSpinnerToPreviouslySelectedProduct() }
        }.show()
    }

    private fun fireProductSelectedCallback(newSelectedPosition: Int) {
        if (reportViewModel.setDefectCountByProductId(getSelectedProductIdByPosition(newSelectedPosition)) == 0) {
            if (reportViewModel.lastProductSelectedPosition >= 0) {
                reportViewModel.setDefectCountByProductId(getSelectedProductIdByPosition(reportViewModel.lastProductSelectedPosition))
            }
            showDialogLackCauses()
        } else {
            reportViewModel.lastProductSelectedPosition = newSelectedPosition
            reportViewModel.setProductSelectedId(getSelectedProductIdByPosition(newSelectedPosition))
            reportViewModel.setTechnicalReportValid(validateToNextPage())
        }

        reportViewModel.evidencePathMap = HashMap()
    }

    private fun getSelectedProductIdByPosition(newSelectedPosition: Int) = technicalReportViewModel.productList[newSelectedPosition].id

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        reportViewModel.setProductSelectedId(0)

        reportViewModel.getProductSelectedId().observe(this, Observer { productId ->
            reportViewModel.updateDefectsByProductId(productId)
        })

        reportViewModel.productSwitch.observe(this, Observer {
            setProductAdapter(technicalReportViewModel.productList)
            rootView.productSpinner.postDelayed({ rootView.productSpinner.error(getString(R.string.out_of_sync_product)) }, 300)
        })

        rootView = inflater.inflate(R.layout.fragment_technical_report, container, false) as ViewGroup
        init()

        prepareValidation()


        reportViewModel.getReport().observe(this, Observer {
            setValuesToView(it!!)
        })

        return rootView
    }

    private fun prepareValidation() {
        validation
                .addComponent(rootView.orderServiceEditText, ::fromEditText,
                        toInputLayout(rootView.orderServiceInputLayout),
                        R.string.order_service_error_message, ::required, ::noXSS)

                .addComponent(rootView.deviceModelEditText, ::fromEditText,
                        toInputLayout(rootView.deviceModelInputLayout),
                        R.string.device_type_error_message, ::required, ::noXSS)

                .addComponent(rootView.serialNumberEditText, ::fromEditText,
                        toInputLayout(rootView.serialNumberInputLayout),
                        R.string.serial_number_error_message, ::required, ::noXSS)

                .addComponent(rootView.productSpinner, ::fromCustomSpinnerPosition,
                        toCustomSpinner(rootView.productSpinner),
                        R.string.select_option_error, ::required)

        validationToNextPage
                .addComponent(rootView.productSpinner, ::fromCustomSpinnerPosition,
                        toCustomSpinner(rootView.productSpinner),
                        R.string.select_option_error, ::greaterThanZero)
    }

    fun validateFieldsEmpty(): Int = validation.validate(Validation.COUNTRY_BR)

    override fun validateToNextPage() = validationToNextPage.validate(Validation.COUNTRY_DEFAULT) == 0

    override fun setValuesToViewModel() {
        reportViewModel.getReport().value?.productName = rootView.productSpinner.valueItemSelected
        var product = technicalReportViewModel.productList.find { product -> product.id == reportViewModel.getProductSelectedId().value }
        reportViewModel.getReport().value?.productId = product?.id ?: 0
        reportViewModel.getReport().value?.productWarrantyTerm = product?.warrantyTerm ?: StringUtils.EMPTY
        reportViewModel.getReport().value?.SONumber = rootView.orderServiceInputLayout.valueText()
        reportViewModel.getReport().value?.deviceSN = rootView.serialNumberInputLayout.valueText()
        reportViewModel.getReport().value?.deviceModel = rootView.deviceModelInputLayout.valueText()
    }

    override fun setValuesToView(report: Report) {
        if (report.productName.isNotEmpty()) {
            val product = technicalReportViewModel.productList.find { product -> product.name == report.productName }
            rootView.productSpinner.setItem(report.productName)
            reportViewModel.setProductSelectedId(product?.id ?: 0)
        }
        rootView.orderServiceEditText.setText(report.SONumber)
        rootView.serialNumberEditText.setText(report.deviceSN)
        rootView.deviceModelEditText.setText(report.deviceModel)
    }

    //if OSNumber is null returns true because the required validation will be triggered
    fun validateOSLength(OSNumber: String?): Boolean = if (!StringUtils.isEmpty(OSNumber)) OSNumber!!.length == OS_NUMBER_LENGTH else true

    fun validateForSave() = Validation()
            .addComponent(rootView.orderServiceEditText, ::fromEditText,
                    toInputLayout(rootView.orderServiceInputLayout),
                    Validation.Validator(::required,
                            R.string.order_service_error_message,
                            Validation.COUNTRY_BR),
                    Validation.Validator(::noXSS,
                            R.string.order_service_error_message,
                            Validation.COUNTRY_BR),
                    Validation.Validator(::validateOSLength,
                            R.string.invalid_os_number,
                            Validation.COUNTRY_BR)
            )
            .validate(Validation.COUNTRY_BR)
}