/*
 *
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 *
 */
package br.org.sidi.technicalreport.util

import android.app.ProgressDialog
import android.content.Context
import br.org.sidi.technicalreport.R
import org.jetbrains.anko.progressDialog

object DialogUtils {

    fun createProgressDialog(context: Context): ProgressDialog {
        val dialog = context.progressDialog (context.getString(R.string.please_wait))
        dialog.setProgressNumberFormat(null)
        dialog.setProgressPercentFormat(null)
        dialog.setCancelable(false)
        dialog.isIndeterminate = true
        return dialog
    }
}