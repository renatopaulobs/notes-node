/*
 *
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 *
 */

package br.org.sidi.technicalreport.features.report.service

import br.org.sidi.technicalreport.BuildConfig
import br.org.sidi.technicalreport.features.report.model.Report
import br.org.sidi.technicalreport.features.report.model.ReportSaveData
import okhttp3.OkHttpClient
import org.apache.http.HttpStatus
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit

object ReportService {

    private const val TIMEOUT = 60L

    private const val TOTAL_COUNT_HEADER = "X-Total-Count"

    private val retrofit = Retrofit.Builder()
            .baseUrl(BuildConfig.REPORT_MS_ENDPOINT)
            .addConverterFactory(MoshiConverterFactory.create())
            .client(OkHttpClient.Builder()
                    .readTimeout(TIMEOUT, TimeUnit.SECONDS)
                    .connectTimeout(TIMEOUT, TimeUnit.SECONDS)
                    .build())
            .build()
    private val reportClient = retrofit.create(ReportClient::class.java)!!

    fun sendReport(report: ReportSaveData, success: () -> Unit, error: () -> Unit) {
        reportClient.sendReport(report)
                .enqueue(object : Callback<Void> {
                    override fun onFailure(call: Call<Void>?, t: Throwable?) {
                        error()
                    }
                    override fun onResponse(call: Call<Void>?, response: Response<Void>?) {
                        when(response?.code()) {
                            HttpStatus.SC_CREATED ->  success()
                            else -> error()
                        }
                    }
                })
    }

    fun getAllReportsPaginated(serviceCenterName: String,
                               soNumber: String?,
                               _page: Int,
                               _limit: Int,
                               success: (List<ReportSaveData>?, totalCount: Int) -> Unit,
                               error: (code: Int) -> Unit) {

        reportClient.getAllReportsPaginated(serviceCenterName, soNumber, _page, _limit)
                .enqueue(object: Callback<List<ReportSaveData>?> {
                    override fun onFailure(call: Call<List<ReportSaveData>?>?, t: Throwable?) {
                        error(HttpStatus.SC_INTERNAL_SERVER_ERROR)
                    }
                    override fun onResponse(call: Call<List<ReportSaveData>?>?, response: Response<List<ReportSaveData>?>?) {
                        when(response?.code()) {
                            HttpStatus.SC_OK->  success(response.body(), Integer.valueOf(response.headers()[TOTAL_COUNT_HEADER] ?: "0"))
                            else -> error(response?.code() ?: 0)
                        }
                    }
                })

    }
}