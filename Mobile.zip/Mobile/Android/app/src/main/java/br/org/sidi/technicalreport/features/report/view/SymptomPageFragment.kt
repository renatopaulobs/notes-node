/*
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 */
package br.org.sidi.technicalreport.features.report.view

import android.arch.lifecycle.Observer
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import br.org.sidi.technicalreport.R
import br.org.sidi.technicalreport.common.validation.CheckValueHelper.Companion.greaterThanZero
import br.org.sidi.technicalreport.common.validation.CheckValueHelper.Companion.noXSS
import br.org.sidi.technicalreport.common.validation.CheckValueHelper.Companion.required
import br.org.sidi.technicalreport.common.validation.GetValueHelper.Companion.fromCustomSpinnerPosition
import br.org.sidi.technicalreport.common.validation.GetValueHelper.Companion.fromEditText
import br.org.sidi.technicalreport.common.validation.SetErrorHelper.Companion.toCustomSpinner
import br.org.sidi.technicalreport.common.validation.SetErrorHelper.Companion.toInputLayout
import br.org.sidi.technicalreport.common.validation.Validation
import br.org.sidi.technicalreport.features.report.model.Cause
import br.org.sidi.technicalreport.features.report.model.Report
import br.org.sidi.technicalreport.features.report.viewmodel.ReportViewModel
import br.org.sidi.technicalreport.util.valueText
import kotlinx.android.synthetic.main.activity_preview_report.view.*
import kotlinx.android.synthetic.main.fragment_symptom.*
import kotlinx.android.synthetic.main.fragment_symptom.view.*
import org.apache.commons.lang3.StringUtils
import org.jetbrains.anko.noButton
import org.jetbrains.anko.support.v4.alert
import org.jetbrains.anko.yesButton

class SymptomPageFragment : AbstractReportPageFragment() {
    companion object {
        private const val FIRST_POSITION = 1
    }

    private var validationToNextPage = Validation()

    private var validation = Validation()
    private lateinit var rootView: ViewGroup
    private val reportViewModel: ReportViewModel
        get() = (activity!! as CreateReportActivity).reportViewModel

    override fun onPageHide() {
        setValuesToViewModel()
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        reportViewModel.getProductSelectedId().observe(this, Observer { productId ->
            reportViewModel.updateDefectsByProductId(productId)
            setupDefectSpinner()

            rootView.let {
                addTouchListener(it.symptomEditText, it.defectSpinner.getInput(), it.causesSpinner.getInput())
            }
        })

        reportViewModel.defectSwitch.observe(this, Observer { _ ->
            reportViewModel.updateDefectsByProductId(reportViewModel.getProductSelectedId().value)
            setupDefectSpinner()
            rootView.defectSpinner.postDelayed({ rootView.defectSpinner.error(getString(R.string.out_of_sync_defect)) }, 300)
        })

        reportViewModel.causeSwitch.observe(this, Observer { _ ->
            setupCauseSpinnerAccordingSelectedDefectPosition(-1)
            if (rootView.defectSpinner.getSelectedItemPosition().value!! > 0) {
                rootView.causesSpinner.postDelayed({ rootView.causesSpinner.error(getString(R.string.out_of_sync_cause)) }, 300)
            }
        })

        rootView = inflater.inflate(R.layout.fragment_symptom, container, false) as ViewGroup

        prepareValidation()

        reportViewModel.getReport().observe(this, Observer {
            setValuesToView(it!!)
        })

        return rootView
    }

    private fun prepareValidation() {
        validation
                .addComponent(rootView.symptomEditText, ::fromEditText,
                        toInputLayout(rootView.symptom_input_layout),
                        R.string.symptom_error_message, ::required, ::noXSS)

                .addComponent(rootView.defectSpinner, ::fromCustomSpinnerPosition,
                        toCustomSpinner(rootView.defectSpinner),
                        R.string.select_option_error, ::greaterThanZero)

                .addComponent(rootView.causesSpinner, ::fromCustomSpinnerPosition,
                        toCustomSpinner(rootView.causesSpinner),
                        R.string.select_option_error, ::required)

        validationToNextPage
                .addComponent(rootView.defectSpinner, ::fromCustomSpinnerPosition,
                        toCustomSpinner(rootView.defectSpinner),
                        R.string.select_option_error, ::greaterThanZero)
    }

    private fun fireDefectSelectedCallback(newSelectedPosition: Int) {
        setupCauseSpinnerAccordingSelectedDefectPosition(newSelectedPosition)
        reportViewModel.setDefectSelectedName(reportViewModel.defectsList[newSelectedPosition].name)

        setupCauseSpinnerEvents()
        reportViewModel.setSymptomValid(validateToNextPage())

        reportViewModel.evidencePathMap = HashMap()
    }

    private fun setupCauseSpinnerAccordingSelectedDefectPosition(newSelectedPosition: Int) {
        reportViewModel.lastDefectSelectedPosition = newSelectedPosition

        if (newSelectedPosition >= 0) {
            rootView.causesSpinner.visibility = View.VISIBLE
            causesSpinnerSetup(reportViewModel.defectsList[newSelectedPosition].causes)
        } else {
            rootView.causesSpinner.visibility = View.GONE
            causesSpinnerSetup(emptyList())
            reportViewModel.setDefectSelectedName(StringUtils.EMPTY)
        }
    }

    private fun setupCauseSpinnerEvents() {
        rootView.causesSpinner.getSelectedItemPosition().observe(this, Observer {
            rootView.causesSpinner.valueItemSelected
            reportViewModel.setCauseSelectedName(rootView.causesSpinner.valueItemSelected)
        })
    }

    private fun setupDefectSpinner() {
        val listNameDefect: List<String> = reportViewModel.defectsList.map { it.name }

        rootView.defectSpinner.setData(listNameDefect.toTypedArray(), R.string.select_causes)
        rootView.defectSpinner.observeListDimensions(rootView.referenceDefectSpinner)

        causesSpinnerSetup(emptyList())

        // This is to avoid execute some code in method onItemSelected() when the onItemSelectedListener is set in spinner
        var spinnerCreated = false

        rootView.defectSpinner.getSelectedItemPosition().observe(this, Observer { position ->
            if (spinnerCreated) {
                if (position == -1) {
                    setupCauseSpinnerAccordingSelectedDefectPosition(position)
                    reportViewModel.setSymptomValid(false)
                }

                if (reportViewModel.lastDefectSelectedPosition >= 0 &&
                        position != reportViewModel.lastDefectSelectedPosition &&
                        reportViewModel.checkNeedsWarning()) {
                    alert(getString(R.string.change_defect_warning)) {
                        isCancelable = false
                        yesButton {
                            fireDefectSelectedCallback(position!!)
                        }
                        noButton { rootView.defectSpinner.setSelection(reportViewModel.lastDefectSelectedPosition + 1) }
                    }.show()
                } else if (position != reportViewModel.lastDefectSelectedPosition) {
                    fireDefectSelectedCallback(position!!)
                }
            } else {
                spinnerCreated = true
            }
        })
    }

    private fun causesSpinnerSetup(listCauses: List<Cause>?) {
        listCauses?.let {
            rootView.causesSpinner.visibility = if (listCauses.count() > 0) View.VISIBLE else View.GONE

            rootView.causesSpinner.setData(listCauses.map { cause -> cause.text }.toTypedArray(), R.string.select_causes, true)
            rootView.causesSpinner.observeListDimensions(rootView.referenceCausesSpinner)

            if (listCauses.count() == 1) {
                rootView.causesSpinner.setSelection(FIRST_POSITION)
            }
            rootView.causesSpinner.setEnabledSpinner(listCauses.count() != 1)
        }
    }

    fun validateFieldsEmpty(): Int = validation.validate(Validation.COUNTRY_BR)

    override fun validateToNextPage() = validationToNextPage.validate(Validation.COUNTRY_DEFAULT) == 0

    override fun setValuesToViewModel() {
        reportViewModel.getReport().value?.symptom = rootView.symptom_input_layout.valueText()
        reportViewModel.getReport().value?.defectName = rootView.defectSpinner.valueItemSelected
        reportViewModel.getReport().value?.rootCauseText = rootView.causesSpinner.valueItemSelected


        reportViewModel.getReport().value?.rootCauseId = reportViewModel.getSelectedCause()?.id ?: 0

        reportViewModel.getSelectedDefect()?.let {
            reportViewModel.getReport().value?.defectId = it.id
            reportViewModel.getReport().value?.defectVersion = it.version
            reportViewModel.getReport().value?.conclusion = it.conclusion
            reportViewModel.getReport().value?.diagnostic = it.diagnostic
            reportViewModel.getReport().value?.defectCode = it.code
        }
    }

    override fun setValuesToView(report: Report) {
        rootView.symptomEditText.setText(report.symptom)
        rootView.defectSpinner.setItem(report.defectName)
        rootView.causesSpinner.setItem(report.rootCauseText)
    }
}
