/*
 *
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 *
 */

package br.org.sidi.technicalreport.features.report.dao

import android.arch.persistence.room.Dao
import android.arch.persistence.room.Query
import android.arch.persistence.room.Transaction
import br.org.sidi.technicalreport.features.report.model.Defect
import br.org.sidi.technicalreport.features.report.model.DefectWithCausesAndEvidenceTypes

@Dao
interface DefectDAO : BaseDAO<Defect> {
    @Query("SELECT COUNT(*) FROM defects")
    fun count(): Int

    @Query("SELECT COUNT(*) from defects where productId = :productId")
    fun count(productId: Long) : Int

    @Query("SELECT * FROM defects")
    fun list(): List<Defect>

    @Transaction
    @Query("SELECT * from defects WHERE productId = :productId")
    fun listByProductIdEagerly(productId: Long): List<DefectWithCausesAndEvidenceTypes>

    @Transaction
    @Query("SELECT * from defects")
    fun listEagerly(): List<DefectWithCausesAndEvidenceTypes>

    @Query("SELECT * from defects WHERE defectId = :defectId")
    fun findByid(defectId: Long): List<Defect>
}