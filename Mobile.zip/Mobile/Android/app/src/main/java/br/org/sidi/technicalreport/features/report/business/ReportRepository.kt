/*
 *
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 *
 */

package br.org.sidi.technicalreport.features.report.business

import android.arch.lifecycle.LiveData
import br.org.sidi.technicalreport.features.report.dao.AppDatabase
import br.org.sidi.technicalreport.features.report.model.Evidence
import br.org.sidi.technicalreport.features.report.model.Report
import br.org.sidi.technicalreport.features.report.model.ReportSaveData
import br.org.sidi.technicalreport.features.report.model.ReportWithEvidences
import br.org.sidi.technicalreport.features.report.service.ReportService
import java.util.*

object ReportRepository {

    const val PAGE_LIMIT = 20
    const val SEQUENCE_NUMBER_PATTERN = "%04d"

    fun listEagerly(): List<Report> {
        return AppDatabase.getInstance().reportDao().listEagerly().map { it.eager }
    }

    fun add(report: Report): Long {
        var result = 0L
        AppDatabase.getInstance().runInTransaction {
            if (report.id == 0L) {
                report.id = AppDatabase.getInstance().reportDao().maxReportID() + 1
            }
            if (report.creationDate == 0L) {
                report.creationDate = Date().time
            }
            result = AppDatabase.getInstance().reportDao().insert(report)
            report.evidences.forEach { it.reportId = result }
            addEvidences(report.evidences)
        }
        return result
    }

    fun add(reports: List<Report>) {
        reports.forEach { add(it) }
    }

    fun findByIdEagerly(reportId: Long): Report {
        return AppDatabase.getInstance().reportDao().findByIdEagerly(reportId).eager
    }

    fun findByOSNumber(OSNumber: String): Report {
        return AppDatabase.getInstance().reportDao().findByOSNumber(OSNumber)
    }

    fun update(report: Report) {
        return AppDatabase.getInstance().reportDao().update(report)
    }

    fun submitReport(report: ReportSaveData, onSuccess: () -> Unit, onError: () -> Unit) {
        ReportService.sendReport(report, {
            AppDatabase.getInstance().reportDao().delete(report.getReportFromReportSaveData())
            onSuccess()
        }, {
            onError()
        })
    }

    private fun addEvidences(evidences: List<Evidence>) {
        AppDatabase.getInstance().evidenceDao().insert(evidences)
    }

    fun saveReport(report: Report) {
        report.sequenceNumber = String.format(SEQUENCE_NUMBER_PATTERN, AppDatabase.getInstance().reportDao().countBySONumber(report.SONumber) + 1)
        add(report)
    }

    fun list(): LiveData<MutableList<ReportWithEvidences>> {
        return AppDatabase.getInstance().reportDao().list()

    }

    fun delete(report: Report) {
        AppDatabase.getInstance().runInTransaction {
            AppDatabase.getInstance().evidenceDao().delete(report.evidences)
            AppDatabase.getInstance().reportDao().delete(report)
        }
    }

    fun countNonDraft(): Int {
        return AppDatabase.getInstance().reportDao().countNonDraft()
    }
}