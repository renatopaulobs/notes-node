/*
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 */

package br.org.sidi.technicalreport.util

import br.org.sidi.technicalreport.R
import br.org.sidi.technicalreport.app.TechnicalReportApplication
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*

object DateUtils {

    fun fromZuluTime(value: String?): Date? {
        if (value == null) return null
        val formatter = SimpleDateFormat(TechnicalReportApplication.getStringRes(R.string.date_zulu_format), TechnicalReportApplication.deviceLocale)
        formatter.timeZone = TimeZone.getTimeZone(TechnicalReportApplication.getStringRes(R.string.utc))
        return formatter.parse(value)
    }

    fun simpleHourString(date: Date): String {
        val resources = TechnicalReportApplication.instance.resources
        return SimpleDateFormat(resources.getString(R.string.format_hour),  TechnicalReportApplication.deviceLocale).format(date);
    }

    fun simpleDateString(date: Date, showYear: Boolean): String {
        return SimpleDateFormat(getFormatDate(showYear),  TechnicalReportApplication.deviceLocale).format(date)
    }

    private fun getFormatDate(showYear: Boolean): String {
        val resources = TechnicalReportApplication.instance.resources
        return if (showYear) resources.getString(R.string.format_date) else resources.getString(R.string.format_date_no_year)
    }

    fun getDateMessage(date: Date, today: String, yesterday: String, daysAgo: String, hideDaysAgo: Boolean): String {

        val textDate: String

        val days = getDays(date);

        val noDaysDifference:Long = 0;
        val oneDayDifference: Long = 1;

        if (days > TimeUnitType.DAYS_IN_ONE_WEEK || days < 0 || hideDaysAgo) {
            textDate = simpleDateString(date, true);
        } else if (days == noDaysDifference) {
            textDate = today;
        } else if (days == oneDayDifference) {
            textDate = yesterday;
        } else {
            textDate = String.format( TechnicalReportApplication.deviceLocale, daysAgo, days);
        }

        return textDate;
    }

    private fun getDays(date: Date): Long {
        val lastDay = Calendar.getInstance()
        lastDay.time = date
        setCalendarTimeToStartOfTheDay(lastDay)

        val dateMessage = lastDay.timeInMillis

        return getDaysSince(dateMessage)
    }

    fun getDaysSince(dateMessage: Long): Long {
        val todayCalendar = Calendar.getInstance()
        todayCalendar.time = Date()
        setCalendarTimeToStartOfTheDay(todayCalendar)

        return (todayCalendar.timeInMillis - dateMessage) / TimeUnitType.DAY.timeMillis
    }

    /***
     * Set the calendar's date to the first possible time of the given date, for cases where
     * the time is irrelevant and should not be passed on
     *
     * @param calendar
     */
    fun setCalendarTimeToStartOfTheDay(calendar: Calendar) {
        calendar.set(Calendar.MILLISECOND, 0)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.HOUR_OF_DAY, 0)
    }

    fun parseToListReplyFormat(textDate: String): String {
        val resources = TechnicalReportApplication.instance.resources
        val sdf = SimpleDateFormat(resources.getString(R.string.format_date_with_hours), TechnicalReportApplication.deviceLocale)

        try {
            val date = sdf.parse(textDate)
            var hideDaysAgo = false
            val days = getDays(date)
            if (days > 2 || days < 0) {
                hideDaysAgo = true
            }
            return parseToTimelineDateFormat(date, true, hideDaysAgo)
        } catch (e: ParseException) {
            Logger.error(e)
        }

        return textDate
    }

    private fun parseToTimelineDateFormat(date: Date, showHour: Boolean, hideDaysAgo: Boolean): String {
        val context = TechnicalReportApplication.instance

        val strToday = context.getString(R.string.today)
        val strDaysAgo = context.getString(R.string.days_ago)
        val strYesterday = context.getString(R.string.yesterday)

        val datePlaceholder = context.getString(R.string.message_date_placeholder)
        val messageHour = simpleHourString(date)
        val messageDate = getDateMessage(date, strToday, strYesterday, strDaysAgo, hideDaysAgo)

        val message: String
        if (showHour) {
            message = String.format(datePlaceholder, messageDate, messageHour)
        } else {
            message = messageDate
        }

        return message
    }
}

enum class TimeUnitType private constructor(val timeUnitId: Int, val timeMillis: Long) {
    SECONDS(0, TimeUnitType.SECOND_MILLIS),
    MINUTE(1, TimeUnitType.MIN_MILLIS),
    HOUR(2, TimeUnitType.HOUR_MILLIS),
    DAY(3, TimeUnitType.DAY_MILLIS);

    companion object {

        const val SECOND_MILLIS = 1000L
        const val MIN_MILLIS = 60 * SECOND_MILLIS
        const val HOUR_MILLIS = 60 * MIN_MILLIS
        const val DAY_MILLIS = 24 * HOUR_MILLIS

        const val DAYS_IN_ONE_WEEK = 7

        fun getType(code: Int): TimeUnitType {
            var result = HOUR

            for (type in values()) {
                if (type.timeUnitId == code) {
                    result = type
                    break
                }
            }
            return result
        }
    }
}