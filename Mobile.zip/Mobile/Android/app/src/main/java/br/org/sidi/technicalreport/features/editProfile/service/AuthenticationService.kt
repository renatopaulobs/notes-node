/*
 *
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 *
 */


package br.org.sidi.technicalreport.features.editProfile.service

import br.org.sidi.technicalreport.BuildConfig
import br.org.sidi.technicalreport.features.report.business.GeoLocationInfo
import br.org.sidi.technicalreport.features.report.business.GeoLocationRepository
import br.org.sidi.technicalreport.util.isOnline
import okhttp3.OkHttpClient
import org.apache.http.HttpStatus
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.io.Serializable
import java.util.concurrent.TimeUnit

object AuthenticationService {

    private const val TIMEOUT = 60L

    private val retrofit = Retrofit.Builder()
            .baseUrl(BuildConfig.SCD_MS_ENDPOINT)
            .addConverterFactory(MoshiConverterFactory.create())
            .client(OkHttpClient.Builder()
                    .readTimeout(TIMEOUT, TimeUnit.SECONDS)
                    .connectTimeout(TIMEOUT, TimeUnit.SECONDS)
                    .build())
            .build()

    private val authenticationClient = retrofit.create(AuthenticationClient::class.java)!!

    fun authenticate(login: LoginDTO, success: () -> Unit, error: (code: Int) -> Unit) {
        if (!isOnline()) {
            error(0)
            return
        }
        authenticationClient.authenticate(login)
                .enqueue(object : Callback<Void> {

                    override fun onFailure(call: Call<Void>?, t: Throwable?) {
                        error(HttpStatus.SC_INTERNAL_SERVER_ERROR)
                    }

                    override fun onResponse(call: Call<Void>?, response: Response<Void>?) {
                        when (response?.code()) {
                            HttpStatus.SC_OK -> success()
                            else -> error(response?.code() ?: 0)
                        }
                    }
                })
    }

    fun getGeoLocationData(countryCode: String, success: (GeoLocationInfo?) -> Unit, error: (code: Int) -> Unit) {
        if (!isOnline()) {
            error(0)
            return
        }

        authenticationClient.getGeoLocationData(countryCode)
                .enqueue(object : Callback<GeoLocationInfo?> {

                    override fun onResponse(call: Call<GeoLocationInfo?>?, response: Response<GeoLocationInfo?>?) {
                        when (response?.code()) {
                            HttpStatus.SC_OK -> success(response.body())
                            else -> error(response?.code() ?: 0)
                        }
                    }

                    override fun onFailure(call: Call<GeoLocationInfo?>?, t: Throwable?) {
                        error(HttpStatus.SC_INTERNAL_SERVER_ERROR)
                    }
                })
    }
}


class LoginDTO(val login: String, val password: String) : Serializable