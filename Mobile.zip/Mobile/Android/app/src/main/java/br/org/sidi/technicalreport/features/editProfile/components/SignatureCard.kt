/*
 *
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 *
 */

package br.org.sidi.technicalreport.features.editProfile.components

import android.content.Context
import android.support.constraint.ConstraintLayout
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import br.org.sidi.technicalreport.R
import br.org.sidi.technicalreport.util.ImageToBase64
import kotlinx.android.synthetic.main.signature_card.view.*
import org.apache.commons.lang3.StringUtils
import org.jetbrains.anko.sdk25.coroutines.onClick


class SignatureCard @JvmOverloads constructor(
        context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0)
    : ConstraintLayout(context, attrs, defStyleAttr) {

    var signatureImage = StringUtils.EMPTY

    init {
        LayoutInflater.from(context).inflate(R.layout.signature_card, this, true)
        signature_img.setImageResource(R.drawable.ic_assignature_add)
        delete_signature_image.setOnClickListener { clearImage() }
    }

    fun clickButtonEditImage(onClick: () -> Unit) {
        edit_signature_image.setOnClickListener { onClick() }
    }

    fun clickImageView(onClick: () -> Unit) {
        signature_img.setOnClickListener { onClick() }
    }

    private fun setupVisibility() {
        if (signatureImage == StringUtils.EMPTY) {
            delete_signature_image.visibility = View.GONE
            edit_signature_image.visibility = View.GONE
        } else {
            delete_signature_image.visibility = View.VISIBLE
            edit_signature_image.visibility = View.VISIBLE
        }
    }

    private fun clearImage() {
        signature_img.setImageResource(R.drawable.ic_assignature_add)
        signatureImage = StringUtils.EMPTY
        setupVisibility()
    }

    fun setImageSignature(image64: String) {
        signatureImage = image64
        signature_img.setImageBitmap(ImageToBase64.decodeBase64ToBitmap(image64))
        setupVisibility()
    }
}
