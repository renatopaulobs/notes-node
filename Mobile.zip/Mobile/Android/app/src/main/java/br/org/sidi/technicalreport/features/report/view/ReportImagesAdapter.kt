/*
 *
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 *
 */

package br.org.sidi.technicalreport.features.report.view

import android.net.Uri
import android.support.annotation.LayoutRes
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import br.org.sidi.technicalreport.R
import br.org.sidi.technicalreport.features.report.model.Evidence
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.cardview_report_image_item.view.*

class ReportImagesAdapter(var data : List<Evidence>) : RecyclerView.Adapter<ReportImagesAdapter.CardViewReportImageHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CardViewReportImageHolder {
        val view : View = parent.inflate(R.layout.cardview_report_image_item, false)

        val viewHolder = CardViewReportImageHolder(view)
        viewHolder.setIsRecyclable(false)

        return viewHolder 
    }

    private fun ViewGroup.inflate(@LayoutRes layoutRes: Int, attachToRoot: Boolean = false): View {
        return LayoutInflater.from(context).inflate(layoutRes, this, attachToRoot)
    }

    override fun getItemCount(): Int {
        return data.size
    }

    override fun onBindViewHolder(holder: CardViewReportImageHolder, position: Int) {
        holder.imageReportTitle.text = data[position].evidenceType.description
        Picasso.get().load(Uri.parse(data[position].imagePath)).into(holder.imageReportThumbnail)
    }

    class CardViewReportImageHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var imageReportTitle : TextView = itemView.report_title
        var imageReportThumbnail : ImageView = itemView.report_thumbnail
    }
}