/*
 *
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 *
 */

package br.org.sidi.technicalreport.features.sync.service

import br.org.sidi.technicalreport.BuildConfig
import br.org.sidi.technicalreport.app.TechnicalReportApplication
import br.org.sidi.technicalreport.features.report.business.GeoLocationRepository
import br.org.sidi.technicalreport.features.sync.model.SyncData
import br.org.sidi.technicalreport.util.isOnline
import org.apache.commons.lang3.StringUtils
import org.apache.http.HttpHeaders.LAST_MODIFIED
import org.apache.http.HttpStatus.SC_NOT_MODIFIED
import org.apache.http.HttpStatus.SC_OK
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory

class SyncService {
    companion object {
        private const val PREFS_LAST_SYNC = "PREFS_LAST_SYNC"
        private const val PREFS_LAST_DATA_RECEIVED = "PREFS_LAST_DATA_RECEIVED"

        private val retrofit = Retrofit.Builder()
                .baseUrl(BuildConfig.REPORT_MS_ENDPOINT)
                .addConverterFactory(MoshiConverterFactory.create())
                .build()
        private val syncClient = retrofit.create(SyncClient::class.java)!!

        fun getLastSyncDate(): String? = TechnicalReportApplication.sharedPreferences.value.getString(PREFS_LAST_SYNC, null)
        fun setLastSyncDate(date: String) = TechnicalReportApplication.sharedPreferences.value.edit().putString(PREFS_LAST_SYNC, date).apply()

        private fun getLastDataReceived(): String? = TechnicalReportApplication.sharedPreferences.value.getString(PREFS_LAST_DATA_RECEIVED, null)
        private fun setLastDataReceived(date: String) = TechnicalReportApplication.sharedPreferences.value.edit().putString(PREFS_LAST_DATA_RECEIVED, date).apply()

        fun syncData(hasChangesCallback: (SyncData?) -> Unit, alreadyUpdatedCallback: () -> Unit, failureCallback: () -> Unit) {
            if (!isOnline()) {
                failureCallback()
                return
            }

            syncClient.syncData(getLastDataReceived() ?: StringUtils.EMPTY)
                    .enqueue(
                            object : Callback<SyncData> {
                                override fun onResponse(call: Call<SyncData>?, response: Response<SyncData>?) {
                                    when (response?.code()) {
                                        SC_OK -> {
                                            setLastDataReceived(response.headers()!![LAST_MODIFIED]
                                                    ?: StringUtils.EMPTY)
                                            hasChangesCallback(response.body())
                                            org.apache.http.HttpHeaders.LAST_MODIFIED
                                        }
                                        SC_NOT_MODIFIED -> alreadyUpdatedCallback()
                                        else -> failureCallback()
                                    }
                                }

                                override fun onFailure(call: Call<SyncData>?, t: Throwable?) {
                                    failureCallback()
                                }
                            })
        }
    }
}

