/*
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 */
package br.org.sidi.technicalreport.features.report.view

import android.support.v4.app.Fragment
import android.view.MotionEvent
import android.view.View
import br.org.sidi.technicalreport.R
import br.org.sidi.technicalreport.R.id.list_spinner
import br.org.sidi.technicalreport.features.report.model.Report
import kotlinx.android.synthetic.main.custom_spinner.*

abstract class AbstractReportPageFragment : Fragment(), View.OnTouchListener {

    var hasChange = false

    override fun setMenuVisibility(menuVisible: Boolean) {
        super.setMenuVisibility(menuVisible)

        if (isResumed && !menuVisible) {
            onPageHide()
        }
    }

    abstract fun onPageHide()

    open fun validateToNextPage() = true

    abstract fun setValuesToViewModel()
    abstract fun setValuesToView(report: Report)

    override fun onTouch(v: View?, event: MotionEvent?): Boolean {
        if (v!!.id != R.id.selectItemEditText && list_spinner != null && list_spinner.visibility == View.VISIBLE) {
            list_spinner.visibility = View.GONE
        }
        hasChange = true

        if (v!!.id != R.id.selectItemEditText && list_spinner != null && list_spinner.visibility == View.VISIBLE) {
            list_spinner.visibility = View.GONE
        }

        return false
    }

    fun addTouchListener(vararg views: View) {
        views.forEach { it.setOnTouchListener(this) }
    }
}