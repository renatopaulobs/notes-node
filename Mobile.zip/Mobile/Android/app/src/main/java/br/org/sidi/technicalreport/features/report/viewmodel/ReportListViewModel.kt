/*
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 */

package br.org.sidi.technicalreport.features.report.viewmodel

import android.arch.lifecycle.LiveData
import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.ViewModel
import br.org.sidi.technicalreport.features.report.business.ReportRepository
import br.org.sidi.technicalreport.features.report.model.ReportWithEvidences
import br.org.sidi.technicalreport.features.report.service.ReportService.getAllReportsPaginated
import br.org.sidi.technicalreport.util.Logger
import org.apache.http.HttpStatus

class ReportListViewModel : ViewModel() {

    private var currentPage: Int = 1
    private var requestStatus = MutableLiveData<Int>()

    var hasMore = true
    var reportList: LiveData<MutableList<ReportWithEvidences>> = ReportRepository.list()

    fun getRequestStatus(): LiveData<Int> {
        return requestStatus
    }

    fun setCurrentPage(currentPage: Int) {
        this.currentPage = currentPage
    }

    fun getReportsPaginated(page: Int = currentPage, limit: Int = ReportRepository.PAGE_LIMIT, osNumber: String? = null) {
        //TODO Change serviceCenterName MOCK to real data from sync API
        getAllReportsPaginated("RICARDO CESAR NABAO ME", osNumber, page, limit,
                { list, totalCount ->
                    val totalPages = Math.ceil(totalCount.toDouble() / ReportRepository.PAGE_LIMIT)
                    list?.let {
                        hasMore = (currentPage < totalPages) && (ReportRepository.countNonDraft() < totalCount)
                        if (it.count() > 0) {
                            it.map { x -> x.getReportFromReportSaveData() }
                                    .let { reports ->
                                        ReportRepository.add(reports)
                                        reportList = ReportRepository.list()
                                        currentPage += 1
                                        requestStatus.value = HttpStatus.SC_OK
                                    }
                        }
                    }
                },
                {
                    requestStatus.value = it
                    Logger.error(null, "Error on requestReportsFromServer")
                })
    }


}

