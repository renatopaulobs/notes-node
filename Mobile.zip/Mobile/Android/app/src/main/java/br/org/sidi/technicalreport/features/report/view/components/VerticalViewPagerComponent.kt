/*
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 */
package br.org.sidi.technicalreport.features.report.view.components

import android.content.Context
import android.support.v4.view.ViewPager
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import br.org.sidi.technicalreport.util.hideSoftKeyBoard

class VerticalViewPagerComponent(context: Context, attrs: AttributeSet? = null) : ViewPager(context, attrs) {
    init {
        setPageTransformer(true, VerticalPageTransformer())
        overScrollMode = View.OVER_SCROLL_NEVER
    }

    interface OnScrollUpListener {
        fun onScrollUp(motionY: Float)
    }

    var onScrollUpListener : OnScrollUpListener? = null

    private var initialY = 0F

    private inner class VerticalPageTransformer : ViewPager.PageTransformer {

        override fun transformPage(view: View, position: Float) {
            view.hideSoftKeyBoard()

            when {
                position < -1 -> view.alpha = 0f
                position <= 1 -> {
                    view.alpha = 1f

                    view.translationX = view.width * -position

                    val yPosition = position * view.height
                    view.translationY = yPosition
                }
                else -> view.alpha = 0f
            }
        }
    }

    private fun swapXY(ev: MotionEvent): MotionEvent {
        val width = width.toFloat()
        val height = height.toFloat()

        val newX = (ev.y / height) * width
        val newY = (ev.x / width) * height

        ev.setLocation(newX, newY)

        return ev
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        val intercepted = super.onInterceptTouchEvent(swapXY(ev))
        swapXY(ev)
        return intercepted
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {

        var motionY = 0F
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                initialY = event.y
            }
            MotionEvent.ACTION_UP -> {
                motionY = event.y - initialY
            }
        }

        if (motionY < 0) {
            onScrollUpListener?.onScrollUp(motionY)
        }

        return super.onTouchEvent(swapXY(event))
    }








}
