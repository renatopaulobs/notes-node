/*
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 */

package br.org.sidi.technicalreport.common.camera

import android.content.Context
import android.util.AttributeSet
import android.view.TextureView
import android.view.View

class AspectRatioTextureView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null, defStyle: Int = 0) : TextureView(context, attrs, defStyle) {
    private var ratioWidth = 0
    private var ratioHeight = 0

    private fun ratioIsZero() = ratioWidth == 0 || ratioHeight == 0
    private fun isSameRatioOrientation(width: Int, height: Int) = width < (height * ratioWidth / ratioHeight)

    fun setAspectRatio(width: Int, height: Int) {
        ratioWidth = if (width > 0) width else 0
        ratioHeight = if (height > 0) height else 0
        requestLayout()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        var width = View.MeasureSpec.getSize(widthMeasureSpec)
        var height = View.MeasureSpec.getSize(heightMeasureSpec)

        width = if (ratioIsZero() || isSameRatioOrientation(width, height)) width else height * ratioWidth / ratioHeight
        height = if (ratioIsZero() || !isSameRatioOrientation(width, height)) height else width * ratioHeight / ratioWidth

        setMeasuredDimension(width, height)
    }
}
