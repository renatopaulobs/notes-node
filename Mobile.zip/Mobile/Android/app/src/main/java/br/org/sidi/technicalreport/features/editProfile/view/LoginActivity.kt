/*
 *
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 *
 */

package br.org.sidi.technicalreport.features.editProfile.view

import android.app.ProgressDialog
import android.arch.lifecycle.Observer
import android.arch.lifecycle.ViewModelProviders
import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import br.org.sidi.technicalreport.R
import br.org.sidi.technicalreport.features.editProfile.business.TechnicianRepository
import br.org.sidi.technicalreport.features.editProfile.service.LoginDTO
import br.org.sidi.technicalreport.features.editProfile.viewmodel.TechnicianProfileViewModel
import br.org.sidi.technicalreport.features.report.business.GeoLocationRepository
import br.org.sidi.technicalreport.features.report.model.TechnicianStatus
import br.org.sidi.technicalreport.features.report.view.ReportListActivity
import br.org.sidi.technicalreport.util.DialogUtils
import br.org.sidi.technicalreport.util.ToastUtils
import kotlinx.android.synthetic.main.activity_login.*
import org.apache.commons.lang3.StringUtils
import org.apache.http.HttpStatus
import org.jetbrains.anko.alert

class LoginActivity : AppCompatActivity() {

    private val technicianViewModel: TechnicianProfileViewModel by lazy { ViewModelProviders.of(this).get(TechnicianProfileViewModel::class.java) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        var dialog: ProgressDialog? = null

        login_btn.setOnClickListener {
            dialog = DialogUtils.createProgressDialog(this@LoginActivity)
            dialog!!.show()
            //TODO (LSTRS-216) change in SP#4 to call login before call getTechnician
            val loginDTO = LoginDTO(loginEditText.text.toString(), StringUtils.EMPTY)
            technicianViewModel.getTechnicianProfile(loginDTO)
            GeoLocationRepository.fetchGeoLocationData()
        }

        technicianViewModel.getRequestResult().observe(this, Observer {
            dialog?.hide()
            when (it) {
            //TODO (LSTRS-217) change the hardcoded number to the login attempts from server (SCD) in SP#4
                HttpStatus.SC_UNAUTHORIZED,
                HttpStatus.SC_NOT_FOUND -> ToastUtils.createToast(this@LoginActivity, String.format(getString(R.string.login_attempts), 5))
                HttpStatus.SC_INTERNAL_SERVER_ERROR -> {
                    alert(getString(R.string.no_internet_connection_msg)) {
                        positiveButton(getString(R.string.try_again)) { technicianViewModel.updateTechnicianProfile() }
                        negativeButton(getString(R.string.cancel)) { it.cancel() }
                    }.show()
                }
            }
        })

        technicianViewModel.getTechnician().observe(this, Observer {
            dialog?.hide()
            it?.let {
                var intent: Intent?
                if (it.status == TechnicianStatus.FIRST_ACCESS.code) {
                    intent = Intent(this@LoginActivity, EditProfileActivity::class.java)
                    intent.putExtra(TechnicianRepository.TECHNICIAN_KEY, it)
                } else {
                    intent = Intent(this@LoginActivity, ReportListActivity::class.java)
                }
                startActivity(intent)
            }
        })
    }
}
