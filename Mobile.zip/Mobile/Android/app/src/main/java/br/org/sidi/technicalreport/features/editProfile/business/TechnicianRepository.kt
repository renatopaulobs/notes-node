/*
 *
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 *
 */

package br.org.sidi.technicalreport.features.editProfile.business

import android.util.Log
import br.org.sidi.technicalreport.features.editProfile.service.TechnicianService
import br.org.sidi.technicalreport.features.report.dao.AppDatabase
import br.org.sidi.technicalreport.features.report.model.Technician

object TechnicianRepository {

    val TECHNICIAN_KEY: String = "TECHNICIAN_KEY"

    fun getTechnician(name: String): Technician? {
        var result: Technician? = null
        TechnicianService.getTechnician(name,
                success = { result = it },
                error = { Log.e(TechnicianRepository.javaClass.name, "Error on get technician") })
        return result
    }

    fun updateProfile(name: String, technician: Technician): Boolean {
        var result = false
        TechnicianService.updateProfile(name, technician.getTechnicianSaveData(),
                success = {
                    result = true
                },
                error = { Log.e(TechnicianRepository.javaClass.name, "Error on update technician profile") })
        return result
    }
}