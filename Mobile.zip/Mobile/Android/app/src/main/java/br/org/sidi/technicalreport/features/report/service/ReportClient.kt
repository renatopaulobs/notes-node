/*
 *
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 *
 */

package br.org.sidi.technicalreport.features.report.service

import br.org.sidi.technicalreport.features.report.model.ReportSaveData
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

interface ReportClient {

    @POST("report")
    fun sendReport(@Body report: ReportSaveData) : Call<Void>

    @GET("report")
    fun getAllReportsPaginated(@Query("serviceCenterName")serviceCenterName: String,
                               @Query("SONumber")soNumber: String?,
                               @Query("_page")_page: Int,
                               @Query("_limit")_limit: Int): Call<List<ReportSaveData>?>
}