/*
 *
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 *
 */

package br.org.sidi.technicalreport.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import org.apache.commons.io.IOUtils
import org.apache.commons.lang3.StringUtils
import java.io.ByteArrayOutputStream

object ImageToBase64 {
    fun encodeExternalBitmapToBase64(context: Context, imagePath: String): String {
        if (StringUtils.isEmpty(imagePath)) return StringUtils.EMPTY
        val uriPath = Uri.parse(imagePath)
        val fileInputStream = context.contentResolver.openInputStream(uriPath)
        val fileByteArray = IOUtils.toByteArray(fileInputStream)
        return Base64.encodeToString(fileByteArray, Base64.DEFAULT)
    }

    fun encodeBitmapToBase64(image: Bitmap): String {
        val output = ByteArrayOutputStream()
        image.compress(Bitmap.CompressFormat.PNG, 100, output)
        return Base64.encodeToString(output.toByteArray(), Base64.DEFAULT)
    }

    fun decodeBase64ToBitmap(image64: String): Bitmap {
        val imageBytes = Base64.decode(image64, Base64.DEFAULT)
        return BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size)
    }
}