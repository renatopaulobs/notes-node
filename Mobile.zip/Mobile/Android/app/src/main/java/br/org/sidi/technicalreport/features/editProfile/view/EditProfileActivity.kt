/*
 *
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 *
 */

package br.org.sidi.technicalreport.features.editProfile.view

import android.arch.lifecycle.Observer
import android.arch.lifecycle.ViewModelProviders
import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import br.org.sidi.technicalreport.R
import br.org.sidi.technicalreport.common.validation.CheckValueHelper
import br.org.sidi.technicalreport.common.validation.GetValueHelper
import br.org.sidi.technicalreport.common.validation.SetErrorHelper
import br.org.sidi.technicalreport.common.validation.Validation
import br.org.sidi.technicalreport.features.editProfile.business.TechnicianRepository
import br.org.sidi.technicalreport.features.editProfile.viewmodel.TechnicianProfileViewModel
import br.org.sidi.technicalreport.features.report.model.Technician
import br.org.sidi.technicalreport.features.report.view.ReportListActivity
import br.org.sidi.technicalreport.util.*
import kotlinx.android.synthetic.main.activity_edit_profile.*
import org.apache.commons.lang3.StringUtils
import org.apache.http.HttpStatus
import org.jetbrains.anko.alert
import org.jetbrains.anko.contentView

class EditProfileActivity : AppCompatActivity() {


    private var validation = Validation()

    private val technicianViewModel: TechnicianProfileViewModel by lazy { ViewModelProviders.of(this).get(TechnicianProfileViewModel::class.java) }

    companion object {
        const val SIGNATURE_REQUEST = 9513
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_profile)
        technicianViewModel.setTechnician(intent.getSerializableExtra(TechnicianRepository.TECHNICIAN_KEY) as Technician?)
        setValues()
        setupFields()
        signature.clickButtonEditImage(::onClick)
        signature.clickImageView(::onClick)

        technicianViewModel.getRequestResult().observe(this@EditProfileActivity, Observer {
            if (it != null) {
                when (it) {
                    HttpStatus.SC_OK -> {
                        ToastUtils.createToast(this@EditProfileActivity, getString(R.string.profile_data_saved_successfully))
                        val intent = Intent(this@EditProfileActivity, ReportListActivity::class.java)
                        startActivity(intent)
                    }
                    else -> alert(getString(R.string.no_internet_connection_msg)) {
                        positiveButton(getString(R.string.try_again)) { technicianViewModel.updateTechnicianProfile() }
                        negativeButton(getString(R.string.cancel)) { it.cancel() }
                    }.show()
                }
            }
        })
    }

    fun onClick() {
        val intent = Intent(this@EditProfileActivity, SignatureActivity::class.java)
        startActivityForResult(intent, SIGNATURE_REQUEST)
    }

    private fun setupFields() {
        supportActionBar?.title = getString(R.string.edit_profile_title)
        contentView?.hideSoftKeyBoard()
        documentEditText.setCpfMask()
        prepareValidation()
    }

    private fun prepareValidation() {
        validation
                .addComponent(nameEditText, GetValueHelper.Companion::fromEditText,
                        SetErrorHelper.toInputLayout(nameInputLayout),
                        R.string.technician_name_error_message, CheckValueHelper.Companion::required, CheckValueHelper.Companion::noXSS)

                .addComponent(documentEditText, GetValueHelper.Companion::fromEditText,
                        SetErrorHelper.toInputLayout(documentInputLayout),
                        Validation.Validator({ value: String? ->
                            if (StringUtils.isEmpty(value)) true else isValidCPF((value
                                    ?: StringUtils.EMPTY).onlyDigits())
                        },
                                R.string.only_person_document_invalid_error_message,
                                Validation.COUNTRY_BR))
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            SIGNATURE_REQUEST -> {
                data?.let {
                    var response = data.getStringExtra(SignatureActivity.SIGNATURE_KEY_RESPONSE)
                    signature.setImageSignature(response)
                    technicianViewModel.getTechnician()?.value?.signatureImage = response
                }
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.menu_edit_profile, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when (item?.itemId) {
            R.id.done_edit_profile -> {
                val errorCount = validation.validate(Validation.COUNTRY_BR)
                if (errorCount == 0) {
                    technicianViewModel.getTechnician().value?.let {
                        it.name = nameEditText.text.toString()
                        it.technicianProfessionalDocument = professionalDocumentEditText.text.toString()
                        it.technicianNaturalPersonalDocument = documentEditText.text.toString()
                    }
                    technicianViewModel.updateTechnicianProfile()
                }
            }
        }
        return true
    }

    private fun setValues() {
        technicianViewModel.getTechnician().value?.let {
            loginEditText.setText(it.login)
            nameEditText.setText(it.name)
            emailEditText.setText(it.email)
        }
    }
}
