/*
 *
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 *
 */
package br.org.sidi.technicalreport.features.editProfile.viewmodel

import android.arch.lifecycle.LiveData
import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.ViewModel
import br.org.sidi.technicalreport.features.editProfile.service.LoginDTO
import br.org.sidi.technicalreport.features.editProfile.service.TechnicianService

import br.org.sidi.technicalreport.features.report.model.Technician
import org.apache.http.HttpStatus

class TechnicianProfileViewModel : ViewModel() {

    private var technician = MutableLiveData<Technician>()
    private var requestResult: MutableLiveData<Int> = MutableLiveData()

    fun getRequestResult(): LiveData<Int> {
        return requestResult
    }

    fun getTechnician(): LiveData<Technician> {
        return technician
    }

    fun setTechnician(technician: Technician?) {
        this.technician.value = technician
    }

    fun getTechnicianProfile(loginDTO: LoginDTO) {
        TechnicianService.getTechnician(loginDTO.login,
                {
                    it?.let {
                        this.technician.value = it
                    }
                },
                {
                    requestResult.value = it
                })
    }

    fun updateTechnicianProfile() {
        TechnicianService.updateProfile(this.technician.value?.login!!,
                this.technician.value!!.getTechnicianSaveData(),
                {
                    it?.let {
                        requestResult.value = HttpStatus.SC_OK
                        this.technician.value = it
                    }

                    if (it == null) {
                        requestResult.value = HttpStatus.SC_NOT_FOUND
                    }
                },
                {
                    requestResult.value = it
                })
    }
}

