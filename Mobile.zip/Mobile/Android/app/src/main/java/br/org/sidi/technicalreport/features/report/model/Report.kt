/*
 *
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 *
 */

package br.org.sidi.technicalreport.features.report.model

import android.arch.persistence.room.*
import br.org.sidi.technicalreport.R
import br.org.sidi.technicalreport.features.report.model.Report.Companion.REPORT_TABLE
import br.org.sidi.technicalreport.util.DateUtils
import org.apache.commons.lang3.StringUtils
import java.io.Serializable
import java.util.*

@Entity(tableName = REPORT_TABLE,
        primaryKeys = [(Report.REPORT_ID_COLUMN), (Report.REPORT_STATUS_COLUMN)])
data class Report(
        @ColumnInfo(name = Report.REPORT_ID_COLUMN)
        var id: Long = 0,
        var serviceCenterId: Int = 0,
        var serviceCenterName: String = StringUtils.EMPTY,
        var serviceCenterCode: String = StringUtils.EMPTY,
        var serviceCenterAddress: String = StringUtils.EMPTY,
        var serviceCenterNeighborhood: String = StringUtils.EMPTY,
        var serviceCenterCity: String = StringUtils.EMPTY,
        var serviceCenterState: String = StringUtils.EMPTY,
        var serviceCenterZipCode: String = StringUtils.EMPTY,
        var serviceCenterJuridicalPersonDocument: String = StringUtils.EMPTY,
        var serviceCenterTelephone: String = StringUtils.EMPTY,
        var SONumber: String = StringUtils.EMPTY,
        var deviceModel: String = StringUtils.EMPTY,
        var deviceSN: String = StringUtils.EMPTY,
        var symptom: String = StringUtils.EMPTY,
        var customerName: String = StringUtils.EMPTY,
        var customerNaturalPersonDocument: String? = StringUtils.EMPTY,
        var customerJuridicalPersonDocument: String? = StringUtils.EMPTY,
        var customerTelephone: String = StringUtils.EMPTY,
        var customerEmail: String = StringUtils.EMPTY,
        var customerAddress: String = StringUtils.EMPTY,
        var customerCityName: String = StringUtils.EMPTY,
        var customerStateCode: String = StringUtils.EMPTY,
        var customerCountryCode: String = StringUtils.EMPTY,
        var defectId: Long = 0,
        var defectName: String = StringUtils.EMPTY,
        var defectCode: String? = StringUtils.EMPTY,
        var defectVersion: String = StringUtils.EMPTY,
        var conclusion: String? = StringUtils.EMPTY,
        var diagnostic: String = StringUtils.EMPTY,
        var productId: Long = 0,
        var productName: String = StringUtils.EMPTY,
        var productWarrantyTerm: String = StringUtils.EMPTY,
        var rootCauseId: Long = 0,
        var rootCauseText: String = StringUtils.EMPTY,
        var technicianId: Long = 0,
        var technicianName: String = StringUtils.EMPTY,
        var technicianProfessionalDocument: String = StringUtils.EMPTY,
        var technicianNaturalPersonDocument: String = StringUtils.EMPTY,
        var technicianSignaturePath: String = StringUtils.EMPTY,
        var status: Int = ReportStatus.DRAFT.code,
        var sequenceNumber: String = StringUtils.EMPTY,
        var creationDate: Long = 0,
        @Ignore var evidences: List<Evidence> = emptyList()) : Serializable {

    companion object {
        const val REPORT_TABLE = "reports"
        const val REPORT_ID_COLUMN = "reportId"
        const val REPORT_STATUS_COLUMN = "status"
    }

    enum class ReportStatus(val code: Int) {
        DRAFT(1), SENT(2);

        companion object {
            fun getStringResource(code: Int): Int {
                when (code) {
                    1 -> return R.string.report_status_draft
                    2 -> return R.string.report_status_sent
                }
                return 0
            }

            fun getShapeResource(code: Int): Int {
                when (code) {
                    1 -> return R.drawable.report_status_shape_draft
                    2 -> return R.drawable.report_status_shape_sent
                }
                return 0
            }
        }
    }
}

class ReportSaveData(var id: Long = 0,
                     var serviceCenterId: Int = 0,
                     var serviceCenterName: String = StringUtils.EMPTY,
                     var serviceCenterCode: String = StringUtils.EMPTY,
                     var serviceCenterAddress: String = StringUtils.EMPTY,
                     var serviceCenterNeighborhood: String = StringUtils.EMPTY,
                     var serviceCenterCity: String = StringUtils.EMPTY,
                     var serviceCenterState: String = StringUtils.EMPTY,
                     var serviceCenterZipCode: String = StringUtils.EMPTY,
                     var serviceCenterJuridicalPersonDocument: String = StringUtils.EMPTY,
                     var serviceCenterTelephone: String = StringUtils.EMPTY,
                     var SONumber: String = StringUtils.EMPTY,
                     var deviceModel: String = StringUtils.EMPTY,
                     var deviceSN: String = StringUtils.EMPTY,
                     var symptom: String = StringUtils.EMPTY,
                     var customerName: String = StringUtils.EMPTY,
                     var customerNaturalPersonDocument: String = StringUtils.EMPTY,
                     var customerJuridicalPersonDocument: String = StringUtils.EMPTY,
                     var customerTelephone: String = StringUtils.EMPTY,
                     var customerEmail: String = StringUtils.EMPTY,
                     var customerAddress: String = StringUtils.EMPTY,
                     var customerCityName: String = StringUtils.EMPTY,
                     var customerStateCode: String = StringUtils.EMPTY,
                     var customerCountryCode: String = StringUtils.EMPTY,
                     var defectId: Long = 0,
                     var defectName: String = StringUtils.EMPTY,
                     var defectCode: String? = StringUtils.EMPTY,
                     var defectVersion: String = StringUtils.EMPTY,
                     var conclusion: String? = StringUtils.EMPTY,
                     var diagnostic: String = StringUtils.EMPTY,
                     var productId: Long = 0,
                     var productName: String = StringUtils.EMPTY,
                     var productWarrantyTerm: String = StringUtils.EMPTY,
                     var rootCauseId: Long = 0,
                     var rootCauseText: String = StringUtils.EMPTY,
                     var technicianId: Long = 0,
                     var technicianName: String = StringUtils.EMPTY,
                     var technicianProfessionalDocument: String = StringUtils.EMPTY,
                     var technicianNaturalPersonDocument: String = StringUtils.EMPTY,
                     var technicianSignaturePath: String = StringUtils.EMPTY,
                     var sequenceNumber: String = StringUtils.EMPTY,
                     var status: Int = Report.ReportStatus.DRAFT.code,
                     var sysPeriod:  Array<String>? = null,
                     var evidences: List<EvidenceDTO> = emptyList()) {

    fun getReportFromReportSaveData(): Report {
        var result = Report()
        result.id = this.id
        result.serviceCenterId = this.serviceCenterId
        result.serviceCenterAddress = this.serviceCenterAddress
        result.serviceCenterCity = this.serviceCenterCity
        result.serviceCenterCode = this.serviceCenterCode
        result.serviceCenterJuridicalPersonDocument = this.serviceCenterJuridicalPersonDocument
        result.serviceCenterName = this.serviceCenterName
        result.serviceCenterNeighborhood = this.serviceCenterNeighborhood
        result.serviceCenterState = this.serviceCenterState
        result.serviceCenterTelephone = this.serviceCenterTelephone
        result.serviceCenterZipCode = this.serviceCenterZipCode
        result.SONumber = this.SONumber
        result.deviceModel = this.deviceModel
        result.deviceSN = this.deviceSN
        result.symptom = this.symptom
        result.technicianId = this.technicianId
        result.technicianName = this.technicianName
        result.technicianSignaturePath = this.technicianSignaturePath
        result.technicianNaturalPersonDocument = this.technicianNaturalPersonDocument
        result.technicianProfessionalDocument = this.technicianProfessionalDocument
        result.defectId = this.defectId
        result.defectName = this.defectName
        result.defectCode = this.defectCode
        result.defectVersion = this.defectVersion
        result.diagnostic = this.diagnostic
        result.conclusion = this.conclusion
        result.productId = this.productId
        result.productName = this.productName
        result.productWarrantyTerm = this.productWarrantyTerm
        result.rootCauseId = this.rootCauseId
        result.rootCauseText = this.rootCauseText
        result.customerName = this.customerName
        result.customerNaturalPersonDocument = this.customerNaturalPersonDocument
        result.customerJuridicalPersonDocument = this.customerJuridicalPersonDocument
        result.customerTelephone = this.customerTelephone
        result.customerEmail = this.customerEmail
        result.customerAddress = this.customerAddress
        result.customerCityName = this.customerCityName
        result.customerStateCode = this.customerStateCode
        result.customerCountryCode = this.customerCountryCode
        result.sequenceNumber = this.sequenceNumber
        result.status = this.status
        result.creationDate = DateUtils.fromZuluTime(this.sysPeriod?.get(0))?.time ?: 0
        result.evidences = this.evidences.map {
            Evidence(evidenceTypeId = it.evidenceTypeId, evidenceTypeDescription = it.evidenceTypeDescription,
                    evidenceImage = it.evidenceImage, imagePath = it.evidencePath)
        }
        return result
    }
}
