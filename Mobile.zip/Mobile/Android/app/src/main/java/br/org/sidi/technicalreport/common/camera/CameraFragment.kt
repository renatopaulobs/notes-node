/*
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 */

package br.org.sidi.technicalreport.common.camera

import android.Manifest
import android.app.ProgressDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.*
import android.hardware.camera2.*
import android.media.ImageReader
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.provider.MediaStore
import android.support.v4.app.ActivityCompat
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentActivity
import android.support.v4.content.ContextCompat
import android.util.Size
import android.util.SparseIntArray
import android.view.*
import br.org.sidi.technicalreport.R
import br.org.sidi.technicalreport.features.report.model.EvidenceType
import br.org.sidi.technicalreport.util.Constant.Companion.REQUEST_PERMISSIONS
import br.org.sidi.technicalreport.util.DialogUtils
import br.org.sidi.technicalreport.util.Logger
import br.org.sidi.technicalreport.util.ToastUtils
import com.theartofdev.edmodo.cropper.CropImage
import kotlinx.android.synthetic.main.fragment_camera_basic.*
import kotlinx.android.synthetic.main.fragment_camera_basic.view.*
import org.jetbrains.anko.support.v4.alert
import java.util.*
import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit

private const val minPixelCount = 5035536

class CameraFragment : Fragment(), View.OnClickListener,
        ActivityCompat.OnRequestPermissionsResultCallback {

    private val samsungGalleryPackageName = "com.sec.android.gallery3d";

    private val surfaceTextureListener = object : TextureView.SurfaceTextureListener {
        override fun onSurfaceTextureAvailable(texture: SurfaceTexture, width: Int, height: Int) {
            openCamera(width, height)
        }

        override fun onSurfaceTextureSizeChanged(texture: SurfaceTexture, width: Int, height: Int) {
            configureTransform(width, height)
        }

        override fun onSurfaceTextureDestroyed(texture: SurfaceTexture) = true

        override fun onSurfaceTextureUpdated(texture: SurfaceTexture) = Unit
    }

    private lateinit var cameraId: String
    private lateinit var textureView: AspectRatioTextureView
    private lateinit var previewSize: Size
    private lateinit var previewRequestBuilder: CaptureRequest.Builder
    private lateinit var previewRequest: CaptureRequest

    private var dialog: ProgressDialog? = null

    private var captureSession: CameraCaptureSession? = null
    private var cameraDevice: CameraDevice? = null
    private var backgroundThread: HandlerThread? = null
    private var backgroundHandler: Handler? = null
    private var imageReader: ImageReader? = null
    private var state = STATE_PREVIEW
    private val cameraOpenCloseLock = Semaphore(1)
    private var flashSupported = false
    private var forceFlash = false
    private var sensorOrientation = 0

    private val stateCallback = object : CameraDevice.StateCallback() {

        override fun onOpened(cameraDevice: CameraDevice) {
            cameraOpenCloseLock.release()
            this@CameraFragment.cameraDevice = cameraDevice
            createCameraPreviewSession()
        }

        override fun onDisconnected(cameraDevice: CameraDevice) {
            cameraOpenCloseLock.release()
            cameraDevice.close()
            this@CameraFragment.cameraDevice = null
        }

        override fun onError(cameraDevice: CameraDevice, error: Int) {
            onDisconnected(cameraDevice)
            this@CameraFragment.activity?.finish()
        }
    }

    private val onImageAvailableListener = ImageReader.OnImageAvailableListener {
        backgroundHandler?.post(ImageSaver(activity!!.contentResolver,
                it.acquireNextImage(), { result ->

            val imageUri = Uri.parse(result)
            CropImage.activity(imageUri)
                    .setActivityTitle(evidence_title.text)
                    .setCropMenuCropButtonTitle("OK")
                    .setInitialCropWindowPaddingRatio(0f)
                    .setAutoZoomEnabled(false)
                    .setAllowFlipping(false)
                    .setBackgroundColor(android.R.color.black)
                    .setActivityMenuIconColor(R.color.button_color)
                    .setOutputUri(imageUri)
                    .setOutputCompressQuality(85)
                    .setOutputCompressFormat(Bitmap.CompressFormat.JPEG)
                    .start(context!!, this)

        }))
    }

    private val captureCallback = object : CameraCaptureSession.CaptureCallback() {
        private fun process() {
            when (state) {
                STATE_PREVIEW -> Unit // Do nothing when the camera preview is working normally.
                STATE_TAKE_PICTURE -> capturePicture()
            }
        }

        private fun capturePicture() {
            state = STATE_PICTURE_TAKEN
            captureStillPicture()
        }

        override fun onCaptureProgressed(session: CameraCaptureSession,
                                         request: CaptureRequest,
                                         partialResult: CaptureResult) {
            process()
        }

        override fun onCaptureCompleted(session: CameraCaptureSession,
                                        request: CaptureRequest,
                                        result: TotalCaptureResult) {
            process()
        }
    }

    override fun onCreateView(inflater: LayoutInflater,
                              container: ViewGroup?,
                              savedInstanceState: Bundle?)
            : View? = inflater.inflate(R.layout.fragment_camera_basic, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        evidence_title.text = activity?.intent?.getStringExtra(CameraActivity.EVIDENCE_TITLE)
        setOnClickListeners(view)
        textureView = (view.findViewById(R.id.texture)) as AspectRatioTextureView

        var mask = activity?.intent?.getStringExtra(CameraActivity.MASK_RESOURCE)!!

        var resource = when (mask.toInt()) {
            EvidenceType.Types.EVIDENCE_TYPE_FRONTAL.code -> R.drawable.mask1
            EvidenceType.Types.EVIDENCE_TYPE_AREA_PANORAMIC.code -> R.drawable.mask1
            EvidenceType.Types.EVIDENCE_TYPE_AREA_ZOOM_IN.code -> R.drawable.mask2
            EvidenceType.Types.EVIDENCE_TYPE_BACK.code -> R.drawable.mask1
            EvidenceType.Types.EVIDENCE_TYPE_BORDER_BOTTOM.code -> R.drawable.mask1
            EvidenceType.Types.EVIDENCE_TYPE_BORDER_LEFT.code -> R.drawable.mask4
            EvidenceType.Types.EVIDENCE_TYPE_BORDER_RIGHT.code -> R.drawable.mask4
            EvidenceType.Types.EVIDENCE_TYPE_BORDER_TOP.code -> R.drawable.mask4
            EvidenceType.Types.EVIDENCE_TYPE_CUSTOMER_SCREEN_ZOOM_OUT.code -> R.drawable.mask1
            EvidenceType.Types.EVIDENCE_TYPE_DATA_REF_TABLE.code -> R.drawable.mask1
            EvidenceType.Types.EVIDENCE_TYPE_LABEL_HUMIDITY.code -> R.drawable.mask3
            EvidenceType.Types.EVIDENCE_TYPE_LABEL_LOCAL.code -> R.drawable.mask1
            EvidenceType.Types.EVIDENCE_TYPE_LABEL_ZOOM_IN.code -> R.drawable.mask2
            EvidenceType.Types.EVIDENCE_TYPE_MODEL_SCREEN_ZOOM_OUT.code -> R.drawable.mask2
            EvidenceType.Types.EVIDENCE_TYPE_NEW_ZOOM_IN.code -> R.drawable.mask2
            EvidenceType.Types.EVIDENCE_TYPE_ORIGINAL_REF_TABLE.code -> R.drawable.mask1
            EvidenceType.Types.EVIDENCE_TYPE_OXIDATION_PANORAMIC.code -> R.drawable.mask1
            EvidenceType.Types.EVIDENCE_TYPE_REF_PANORAMIC.code -> R.drawable.mask1
            else -> {
                R.drawable.mask1
            }
        }

        maskcamera.setImageResource(resource)
    }

    private fun setOnClickListeners(view: View) {
        view.takePicture.setOnClickListener(this)
        view.takeGallery.setOnClickListener(this)
        view.flash.setOnClickListener(this)
        view.close.setOnClickListener(this)
    }

    override fun onResume() {
        super.onResume()

        startBackgroundThread()

        if (textureView.isAvailable) {
            openCamera(textureView.width, textureView.height)
        } else {
            textureView.surfaceTextureListener = surfaceTextureListener
        }
    }

    override fun onPause() {
        closeCamera()
        stopBackgroundThread()
        dialog?.hide()
        super.onPause()
    }

    private fun requestNeededPermissions() = requestPermissions(arrayOf(Manifest.permission.CAMERA,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE),
            REQUEST_PERMISSIONS)

    override fun onRequestPermissionsResult(requestCode: Int,
                                            permissions: Array<String>,
                                            grantResults: IntArray) {
        if (requestCode == REQUEST_PERMISSIONS) {
            if (grantResults.any { it != PackageManager.PERMISSION_GRANTED }) {
                activity?.finish()
            }
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        }
    }

    private fun setUpCameraOutputs(width: Int, height: Int) {
        val currentActivity: FragmentActivity = activity ?: return
        val manager = currentActivity.getSystemService(Context.CAMERA_SERVICE) as CameraManager

        try {
            for (cameraId in manager.cameraIdList) {
                val characteristics = manager.getCameraCharacteristics(cameraId)
                val cameraDirection = characteristics.get(CameraCharacteristics.LENS_FACING)

                if (cameraDirection != null && cameraDirection == CameraCharacteristics.LENS_FACING_FRONT) {
                    continue
                }

                val map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                        ?: continue

                val outputSizesByArea = Arrays.asList(*map.getOutputSizes(ImageFormat.JPEG))

                Collections.sort(outputSizesByArea, CompareSizesByArea())

                val largest = Collections.max(outputSizesByArea, CompareSizesByArea())

                if (largest.width * largest.height < minPixelCount) {
                    throw Exception("Camera resolution too low")
                }

                var minWidthGreaterThan5MP = largest.width
                var minHeightGreaterThan5MP = largest.height

                for (outputSize in outputSizesByArea) {
                    val pixelCount = outputSize.width * outputSize.height
                    if ((pixelCount < minPixelCount)
                            || (pixelCount >= minPixelCount && (outputSize.width / outputSize.height.toDouble()) != 16 / 9.toDouble())) continue

                    minWidthGreaterThan5MP = outputSize.width
                    minHeightGreaterThan5MP = outputSize.height
                    break
                }

                imageReader = ImageReader.newInstance(minWidthGreaterThan5MP, minHeightGreaterThan5MP,
                        ImageFormat.JPEG, 2).apply {
                    setOnImageAvailableListener(onImageAvailableListener, backgroundHandler)
                }

                val displayRotation = currentActivity.windowManager.defaultDisplay.rotation

                sensorOrientation = characteristics.get(CameraCharacteristics.SENSOR_ORIENTATION)
                val swappedDimensions = areDimensionsSwapped(displayRotation)

                val displaySize = Point()
                currentActivity.windowManager.defaultDisplay.getSize(displaySize)
                val rotatedPreviewWidth = if (swappedDimensions) height else width
                val rotatedPreviewHeight = if (swappedDimensions) width else height
                var maxPreviewWidth = if (swappedDimensions) displaySize.y else displaySize.x
                var maxPreviewHeight = if (swappedDimensions) displaySize.x else displaySize.y

                if (maxPreviewWidth > MAX_PREVIEW_WIDTH) maxPreviewWidth = MAX_PREVIEW_WIDTH
                if (maxPreviewHeight > MAX_PREVIEW_HEIGHT) maxPreviewHeight = MAX_PREVIEW_HEIGHT

                previewSize = chooseOptimalSize(map.getOutputSizes(SurfaceTexture::class.java),
                        rotatedPreviewWidth, rotatedPreviewHeight,
                        maxPreviewWidth, maxPreviewHeight,
                        largest)

                // We fit the aspect ratio of TextureView to the size of preview we picked.
                if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
                    textureView.setAspectRatio(previewSize.width, previewSize.height)
                } else {
                    textureView.setAspectRatio(previewSize.height, previewSize.width)
                }

                // Check if the flash is supported.
                flashSupported = characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true

                this.cameraId = cameraId

                // We've found a viable camera and finished setting up member variables,
                // so we don't need to iterate through other available cameras.
                return
            }
        } catch (e: CameraAccessException) {
            Logger.error(e)
        }
    }

    private fun areDimensionsSwapped(displayRotation: Int): Boolean {
        var swappedDimensions = false
        when (displayRotation) {
            Surface.ROTATION_0, Surface.ROTATION_180 -> {
                if (sensorOrientation == 90 || sensorOrientation == 270) {
                    swappedDimensions = true
                }
            }
            Surface.ROTATION_90, Surface.ROTATION_270 -> {
                if (sensorOrientation == 0 || sensorOrientation == 180) {
                    swappedDimensions = true
                }
            }
            else -> {
                Logger.error(message = "Display rotation is invalid: $displayRotation")
            }
        }
        return swappedDimensions
    }

    private fun openCamera(width: Int, height: Int) {
        val currentActivity: FragmentActivity = activity ?: return

        setUpCameraOutputs(width, height)
        configureTransform(width, height)

        val cameraPermission = ContextCompat.checkSelfPermission(currentActivity, Manifest.permission.CAMERA)
        val readPermission = ContextCompat.checkSelfPermission(currentActivity, Manifest.permission.READ_EXTERNAL_STORAGE)
        val writePermission = ContextCompat.checkSelfPermission(currentActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if (cameraPermission != PackageManager.PERMISSION_GRANTED ||
                readPermission != PackageManager.PERMISSION_GRANTED ||
                writePermission != PackageManager.PERMISSION_GRANTED) {
            requestNeededPermissions()
            return
        }

        val manager = currentActivity.getSystemService(Context.CAMERA_SERVICE) as CameraManager

        try {
            // Wait for camera to open - 2.5 seconds is sufficient
            if (!cameraOpenCloseLock.tryAcquire(2500, TimeUnit.MILLISECONDS)) {
                throw RuntimeException("Time out waiting to lock camera opening.")
            }
            manager.openCamera(cameraId, stateCallback, backgroundHandler)
        } catch (e: CameraAccessException) {
            Logger.error(e)
        } catch (e: InterruptedException) {
            throw RuntimeException("Interrupted while trying to lock camera opening.", e)
        }

    }

    private fun closeCamera() {
        try {
            cameraOpenCloseLock.acquire()
            captureSession?.close()
            captureSession = null
            cameraDevice?.close()
            cameraDevice = null
            imageReader?.close()
            imageReader = null
        } catch (e: InterruptedException) {
            throw RuntimeException("Interrupted while trying to lock camera closing.", e)
        } finally {
            cameraOpenCloseLock.release()
        }
    }

    private fun startBackgroundThread() {
        backgroundThread = HandlerThread("CameraBackground").also { it.start() }
        backgroundHandler = Handler(backgroundThread?.looper)
    }

    private fun stopBackgroundThread() {
        backgroundThread?.quitSafely()
        try {
            backgroundThread?.join()
            backgroundThread = null
            backgroundHandler = null
        } catch (e: InterruptedException) {
            Logger.error(e)
        }
    }

    private fun createCameraPreviewSession() {
        try {
            val texture = textureView.surfaceTexture
            texture.setDefaultBufferSize(previewSize.width, previewSize.height)

            val surface = Surface(texture)

            previewRequestBuilder = cameraDevice!!.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
            previewRequestBuilder.addTarget(surface)

            cameraDevice?.createCaptureSession(Arrays.asList(surface, imageReader?.surface),
                    object : CameraCaptureSession.StateCallback() {

                        override fun onConfigured(cameraCaptureSession: CameraCaptureSession) {
                            if (cameraDevice == null) return

                            captureSession = cameraCaptureSession
                            try {
                                previewRequestBuilder.set(CaptureRequest.CONTROL_AF_MODE,
                                        CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                                setAutoFlash(previewRequestBuilder)

                                previewRequest = previewRequestBuilder.build()
                                captureSession?.setRepeatingRequest(previewRequest, captureCallback, backgroundHandler)
                            } catch (e: CameraAccessException) {
                                onNoFocus()
                                Logger.error(e)
                            } catch (e: IllegalStateException) {
                                Logger.error(e)
                            }
                        }

                        override fun onConfigureFailed(session: CameraCaptureSession) {
                            val currentActivity: FragmentActivity = activity ?: return
                            ToastUtils.createToast(currentActivity, "Failed")
                        }
                    }, null)
        } catch (e: CameraAccessException) {
            onNoFocus()
            Logger.error(e)
        } catch (e: IllegalStateException) {
            Logger.error(e)
        }

    }

    private fun configureTransform(viewWidth: Int, viewHeight: Int) {
        val currentActivity: FragmentActivity = activity ?: return
        val rotation = currentActivity.windowManager.defaultDisplay.rotation
        val matrix = Matrix()
        val viewRect = RectF(0f, 0f, viewWidth.toFloat(), viewHeight.toFloat())
        val bufferRect = RectF(0f, 0f, previewSize.height.toFloat(), previewSize.width.toFloat())
        val centerX = viewRect.centerX()
        val centerY = viewRect.centerY()

        if (Surface.ROTATION_90 == rotation || Surface.ROTATION_270 == rotation) {
            bufferRect.offset(centerX - bufferRect.centerX(), centerY - bufferRect.centerY())
            val scale = Math.max(
                    viewHeight.toFloat() / previewSize.height,
                    viewWidth.toFloat() / previewSize.width)
            with(matrix) {
                setRectToRect(viewRect, bufferRect, Matrix.ScaleToFit.FILL)
                postScale(scale, scale, centerX, centerY)
                postRotate((90 * (rotation - 2)).toFloat(), centerX, centerY)
            }
        } else if (Surface.ROTATION_180 == rotation) {
            matrix.postRotate(180f, centerX, centerY)
        }
        textureView.setTransform(matrix)
    }

    private fun lockFocus() {
        try {
            dialog = dialog ?: DialogUtils.createProgressDialog(context!!)
            dialog?.show()

            // This is how to tell the camera to lock focus.
            previewRequestBuilder.set(CaptureRequest.CONTROL_AF_TRIGGER,
                    CameraMetadata.CONTROL_AF_TRIGGER_START)
            // Tell #captureCallback to wait for the lock.
            state = STATE_TAKE_PICTURE
            captureSession?.capture(previewRequestBuilder.build(), captureCallback, backgroundHandler)
        } catch (e: CameraAccessException) {
            onNoFocus()
            Logger.error(e)
        }
    }

    private fun captureStillPicture() {
        try {
            if (activity == null || cameraDevice == null) return

            val captureBuilder = cameraDevice?.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)?.apply {
                addTarget(imageReader?.surface)
                set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
            }?.also { setAutoFlash(it) }

            val captureCallback = object : CameraCaptureSession.CaptureCallback() {
                override fun onCaptureCompleted(session: CameraCaptureSession,
                                                request: CaptureRequest,
                                                result: TotalCaptureResult) {
                    unlockFocus()
                }
            }

            captureSession?.apply {
                stopRepeating()
                abortCaptures()
                capture(captureBuilder?.build(), captureCallback, null)
            }
        } catch (e: CameraAccessException) {
            onNoFocus()
            Logger.error(e)
        }

    }

    private fun onNoFocus() {
        dialog?.hide()
        alert(getString(R.string.focus_error)).show()
    }

    private fun unlockFocus() {
        try {
            state = STATE_PREVIEW
            captureSession?.setRepeatingRequest(previewRequest, captureCallback, backgroundHandler)
        } catch (e: CameraAccessException) {
            onNoFocus()
            Logger.error(e)
        }
    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.takePicture -> lockFocus()
            R.id.takeGallery -> selectFromGallery()
            R.id.flash -> setFlash()
            R.id.close -> activity?.finish()
        }
    }

    private fun selectFromGallery() {

        var intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)

        intent.`package` = samsungGalleryPackageName

        intent.putExtra(Intent.EXTRA_TITLE, getString(R.string.select_from_gallery))

        intent.type = "image/*"

        activity?.startActivityForResult(intent, CameraActivity.RESULT_FROM_GALLERY)
    }

    private fun setFlash() {
        forceFlash = !forceFlash

        flash.background = if (forceFlash) activity?.getDrawable(R.drawable.ic_baseline_flash_on_24px) else activity?.getDrawable(R.drawable.ic_baseline_flash_off_24px)

        try {
            setAutoFlash(previewRequestBuilder)
            captureSession?.setRepeatingRequest(previewRequestBuilder.build(),
                    captureCallback, backgroundHandler)
        } catch (e: CameraAccessException) {
            Logger.error(e)
        }
    }

    private fun setAutoFlash(requestBuilder: CaptureRequest.Builder) {
        if (flashSupported) {
            requestBuilder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)

            val flashMode = if (forceFlash) CaptureRequest.FLASH_MODE_TORCH else CaptureRequest.FLASH_MODE_OFF
            requestBuilder.set(CaptureRequest.FLASH_MODE, flashMode)
        }
    }

    companion object {
        private val ORIENTATIONS = SparseIntArray()

        init {
            ORIENTATIONS.append(Surface.ROTATION_0, 90)
            ORIENTATIONS.append(Surface.ROTATION_90, 0)
            ORIENTATIONS.append(Surface.ROTATION_180, 270)
            ORIENTATIONS.append(Surface.ROTATION_270, 180)
        }

        private const val STATE_PREVIEW = 0
        private const val STATE_TAKE_PICTURE = 1
        private const val STATE_PICTURE_TAKEN = 2
        private const val MAX_PREVIEW_WIDTH = 1920
        private const val MAX_PREVIEW_HEIGHT = 1080

        @JvmStatic
        private fun chooseOptimalSize(
                choices: Array<Size>,
                textureViewWidth: Int,
                textureViewHeight: Int,
                maxWidth: Int,
                maxHeight: Int,
                aspectRatio: Size
        ): Size {
            val bigEnough = ArrayList<Size>()
            val notBigEnough = ArrayList<Size>()
            val w = aspectRatio.width
            val h = aspectRatio.height

            for (option in choices) {
                if (option.width <= maxWidth && option.height <= maxHeight &&
                        option.height == option.width * h / w) {
                    if (option.width >= textureViewWidth && option.height >= textureViewHeight) {
                        bigEnough.add(option)
                    } else {
                        notBigEnough.add(option)
                    }
                }
            }

            return when {
                bigEnough.size > 0 -> Collections.min(bigEnough, CompareSizesByArea())
                notBigEnough.size > 0 -> Collections.max(notBigEnough, CompareSizesByArea())
                else -> choices[0]
            }
        }

        @JvmStatic
        fun newInstance(): CameraFragment = CameraFragment()
    }
}
