/*
 *
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 *
 */

package br.org.sidi.technicalreport.features.report.model

import android.arch.persistence.room.Embedded
import android.arch.persistence.room.Relation

class DefectWithCausesAndEvidenceTypes : RelationEntity<Defect>() {
    @Embedded
    var defect: Defect = Defect()
    @Relation(parentColumn = Defect.DEFECT_ID_COLUMN, entityColumn = Defect.DEFECT_ID_COLUMN)
    var causes: List<Cause> = emptyList()
    @Relation(parentColumn = Defect.DEFECT_ID_COLUMN, entityColumn = Defect.DEFECT_ID_COLUMN)
    var evidenceType: List<EvidenceType> = emptyList()

    override fun getEagerEntity(): Defect {
        defect.causes = causes
        defect.evidenceTypes = evidenceType
        return defect
    }
}