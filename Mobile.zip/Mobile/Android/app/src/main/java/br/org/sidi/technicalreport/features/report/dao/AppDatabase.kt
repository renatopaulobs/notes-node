/*
 *
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 *
 */

package br.org.sidi.technicalreport.features.report.dao

import android.arch.lifecycle.LifecycleObserver
import android.arch.persistence.room.Database
import android.arch.persistence.room.Room
import android.arch.persistence.room.RoomDatabase
import android.content.Context
import br.org.sidi.technicalreport.features.report.model.*

@Database(entities = [Product::class, Defect::class, Cause::class, Evidence::class, EvidenceType::class, Report::class, Technician::class], version = 1)
abstract class AppDatabase : RoomDatabase(), LifecycleObserver {
    abstract fun defectDao(): DefectDAO

    abstract fun productDao(): ProductDAO

    abstract fun causeDao(): CauseDAO

    abstract fun evidenceDao(): EvidenceDAO

    abstract fun evidenceTypeDao(): EvidenceTypeDAO

    abstract fun reportDao(): ReportDAO

    abstract fun technicianDao(): TechnicianDAO

    companion object {
        private const val DATABASE_NAME = "app.db"

        private var instance: AppDatabase? = null

        fun getInstance(context: Context? = null) : AppDatabase {
            if (instance == null && context == null) {
                throw RuntimeException("No database instance found. Call getInstance() with Context parameter to initialize instance.")
            }
            if (instance == null && context != null){
                synchronized(AppDatabase::class) {
                    instance = Room.databaseBuilder(context.applicationContext,
                            AppDatabase::class.java,
                            DATABASE_NAME).allowMainThreadQueries().build()
                }
            }
            return instance!!
        }

        fun destroyInstance() {
            instance = null
        }
    }
}