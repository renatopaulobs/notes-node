/*
 *
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 *
 */

package br.org.sidi.technicalreport.features.report.viewmodel

import android.arch.lifecycle.ViewModel
import br.org.sidi.technicalreport.features.report.business.ReportRepository
import br.org.sidi.technicalreport.features.report.business.ReportRepository.submitReport
import br.org.sidi.technicalreport.features.report.model.EvidenceDTO
import br.org.sidi.technicalreport.features.report.model.Report
import br.org.sidi.technicalreport.features.report.model.ReportSaveData
import br.org.sidi.technicalreport.features.sync.business.SyncBO
import br.org.sidi.technicalreport.features.sync.model.SyncDiff
import br.org.sidi.technicalreport.util.CNPJ_MAX_LENGTH
import br.org.sidi.technicalreport.util.CPF_MAX_LENGTH
import br.org.sidi.technicalreport.util.onlyDigits
import org.apache.commons.lang3.StringUtils


class PreviewReportViewModel : ViewModel() {

    var reportSaveData: ReportSaveData = ReportSaveData()

    fun sendReport(reportSaveData: ReportSaveData, onSuccess: () -> Unit, onError: () -> Unit, onOutOfSync: (SyncDiff.OutOfSync) -> Unit) {
        SyncBO.syncAndGetDiff(
                {
                    val outOfSyncData = it.checkReport(reportSaveData.getReportFromReportSaveData())
                    if (outOfSyncData.isOutOfSync) {
                        onOutOfSync(outOfSyncData)
                    } else {
                        send(onSuccess, onError)
                    }
                },
                { send(onSuccess, onError) },
                onError
        )
    }

    private fun send(onSuccess: () -> Unit, onError: () -> Unit) {
        submitReport(reportSaveData,
                { onSuccess() },
                { onError() })
    }

    fun setupReportSaveData(report: Report) {
        this.reportSaveData.id = report.id
        this.reportSaveData.serviceCenterId = report.serviceCenterId
        this.reportSaveData.SONumber = report.SONumber
        this.reportSaveData.deviceModel = report.deviceModel
        this.reportSaveData.deviceSN = report.deviceSN
        this.reportSaveData.symptom = report.symptom
        this.reportSaveData.technicianId = report.technicianId
        this.reportSaveData.technicianName = report.technicianName
        this.reportSaveData.technicianSignaturePath = report.technicianSignaturePath
        this.reportSaveData.technicianNaturalPersonDocument = report.technicianNaturalPersonDocument
        this.reportSaveData.technicianProfessionalDocument = report.technicianProfessionalDocument
        this.reportSaveData.defectId = report.defectId
        this.reportSaveData.defectName = report.defectName
        this.reportSaveData.defectCode = report.defectCode
        this.reportSaveData.defectVersion = report.defectVersion
        this.reportSaveData.diagnostic = report.diagnostic
        this.reportSaveData.conclusion = report.conclusion
        this.reportSaveData.productId = report.productId
        this.reportSaveData.productName = report.productName
        this.reportSaveData.productWarrantyTerm = report.productWarrantyTerm
        this.reportSaveData.rootCauseId = report.rootCauseId
        this.reportSaveData.rootCauseText = report.rootCauseText
        this.reportSaveData.customerName = report.customerName
        this.reportSaveData.customerNaturalPersonDocument = if (report.customerNaturalPersonDocument?.onlyDigits()?.length == CPF_MAX_LENGTH) report.customerNaturalPersonDocument!! else StringUtils.EMPTY
        this.reportSaveData.customerJuridicalPersonDocument = if (report.customerJuridicalPersonDocument?.onlyDigits()?.length == CNPJ_MAX_LENGTH) report.customerJuridicalPersonDocument!! else StringUtils.EMPTY
        this.reportSaveData.customerTelephone = report.customerTelephone
        this.reportSaveData.customerEmail = report.customerEmail
        this.reportSaveData.customerAddress = report.customerAddress
        this.reportSaveData.customerCityName = report.customerCityName
        this.reportSaveData.customerStateCode = report.customerStateCode
        this.reportSaveData.customerCountryCode = report.customerCountryCode
        this.reportSaveData.sequenceNumber = report.sequenceNumber
        this.reportSaveData.evidences = report.evidences.map { evidence ->
            EvidenceDTO(evidenceImage = evidence.evidenceImage,
                    evidencePath = evidence.imagePath,
                    evidenceTypeDescription = evidence.evidenceTypeDescription,
                    evidenceTypeId = evidence.evidenceTypeId)
        }
    }

    fun saveReport() {
        ReportRepository.saveReport(reportSaveData.getReportFromReportSaveData())
    }

    fun deleteReport() {
        ReportRepository.delete(reportSaveData.getReportFromReportSaveData())
    }

    fun getReport(id: Long): Report {
        return ReportRepository.findByIdEagerly(id)
    }
}