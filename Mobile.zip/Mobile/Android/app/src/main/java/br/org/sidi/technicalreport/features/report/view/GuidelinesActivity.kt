/*
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 */

package br.org.sidi.technicalreport.features.report.view

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import br.org.sidi.technicalreport.R
import br.org.sidi.technicalreport.app.TechnicalReportApplication
import br.org.sidi.technicalreport.common.camera.CameraActivity
import kotlinx.android.synthetic.main.guidelines_layout.*

class GuidelinesActivity : AppCompatActivity() {

    companion object {
        private const val PREFS_GUIDELINE_NEVER_SHOW_AGAIN = "PREFS_GUIDELINE_NEVER_SHOW_AGAIN"

        fun neverOpenAgain() = TechnicalReportApplication.sharedPreferences.value.getBoolean(PREFS_GUIDELINE_NEVER_SHOW_AGAIN, false)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.guidelines_layout)
        setResult(CameraActivity.RESULT_FROM_GUIDELINES)

        toolbar.navigationIcon = getDrawable(R.drawable.ic_baseline_close_24px)
        toolbar.navigationIcon!!.setTint(getColor(R.color.button_color))
        toolbar.setNavigationOnClickListener { _ -> finish() }

        btn_ok.setOnClickListener { _ ->
            if (chk_doNotShowAgain.isChecked){
                TechnicalReportApplication.sharedPreferences.value.edit().putBoolean(PREFS_GUIDELINE_NEVER_SHOW_AGAIN, true).apply()
            }
            finish()
        }
    }
}
