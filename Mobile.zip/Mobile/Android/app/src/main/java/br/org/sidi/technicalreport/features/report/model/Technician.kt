/*
 *
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 *
 */

package br.org.sidi.technicalreport.features.report.model

import android.arch.persistence.room.ColumnInfo
import android.arch.persistence.room.Entity
import android.arch.persistence.room.Ignore
import android.arch.persistence.room.PrimaryKey
import br.org.sidi.technicalreport.features.report.model.Technician.Companion.TECHNICIAN_TABLE
import org.apache.commons.lang3.StringUtils
import java.io.Serializable


@Entity(tableName = TECHNICIAN_TABLE)
data class Technician(@PrimaryKey
                      @ColumnInfo(name = Technician.TECHNICIAN_COLUMN_ID)
                      var id: Long = 0L,
                      var serviceCenterId: Int = 0,
                      var login: String = StringUtils.EMPTY,
                      var email: String = StringUtils.EMPTY,
                      var status: Int = 0,
                      var name: String = StringUtils.EMPTY,
                      var technicianProfessionalDocument: String = StringUtils.EMPTY,
                      var technicianNaturalPersonalDocument: String = StringUtils.EMPTY,
                      var technicianDigitizedSignaturePath: String = StringUtils.EMPTY,
                      @Ignore var signatureImage: String = StringUtils.EMPTY) : Serializable {

    fun getTechnicianSaveData(): TechnicianSaveData {
        return TechnicianSaveData(name = this.name,
                technicianNaturalPersonalDocument = if (StringUtils.EMPTY == this.technicianNaturalPersonalDocument) null else this.technicianNaturalPersonalDocument,
                technicianProfessionalDocument = if (StringUtils.EMPTY == this.technicianProfessionalDocument) null else this.technicianProfessionalDocument,
                technicianDigitizedSignatureImage = if (StringUtils.EMPTY == this.signatureImage) null else this.signatureImage)
    }

    companion object {
        const val TECHNICIAN_TABLE = "technicians"
        const val TECHNICIAN_COLUMN_ID = "technicianId"
    }
}

data class TechnicianSaveData(var name: String?,
                              var technicianNaturalPersonalDocument: String?,
                              var technicianProfessionalDocument: String?,
                              var technicianDigitizedSignatureImage: String?) {}

enum class TechnicianStatus(var code: Int) {
    FIRST_ACCESS(0), VALID(1)
}
