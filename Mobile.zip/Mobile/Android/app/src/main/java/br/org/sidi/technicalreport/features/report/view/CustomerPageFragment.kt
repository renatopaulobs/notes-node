/*
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 */
package br.org.sidi.technicalreport.features.report.view

import android.arch.lifecycle.Observer
import android.os.Bundle
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.TextView
import br.org.sidi.technicalreport.R
import br.org.sidi.technicalreport.app.TechnicalReportApplication
import br.org.sidi.technicalreport.common.validation.CheckValueHelper.Companion.email
import br.org.sidi.technicalreport.common.validation.CheckValueHelper.Companion.greaterThanZero
import br.org.sidi.technicalreport.common.validation.CheckValueHelper.Companion.noXSS
import br.org.sidi.technicalreport.common.validation.CheckValueHelper.Companion.required
import br.org.sidi.technicalreport.common.validation.CheckValueHelper.Companion.telephone
import br.org.sidi.technicalreport.common.validation.GetValueHelper.Companion.fromAutoComplete
import br.org.sidi.technicalreport.common.validation.GetValueHelper.Companion.fromCustomSpinnerPosition
import br.org.sidi.technicalreport.common.validation.GetValueHelper.Companion.fromEditText
import br.org.sidi.technicalreport.common.validation.SetErrorHelper.Companion.toCustomSpinner
import br.org.sidi.technicalreport.common.validation.SetErrorHelper.Companion.toInputLayout
import br.org.sidi.technicalreport.common.validation.Validation
import br.org.sidi.technicalreport.common.view.OnCustomSpinnerItemSelected
import br.org.sidi.technicalreport.features.report.business.GeoLocationRepository
import br.org.sidi.technicalreport.features.report.model.Report
import br.org.sidi.technicalreport.features.report.model.Technician
import br.org.sidi.technicalreport.features.report.viewmodel.ReportViewModel
import br.org.sidi.technicalreport.opensource.PhoneNumberFormattingTextWatcher
import br.org.sidi.technicalreport.util.*
import kotlinx.android.synthetic.main.custom_spinner.*
import kotlinx.android.synthetic.main.fragment_customer.*
import kotlinx.android.synthetic.main.fragment_customer.view.*
import org.apache.commons.lang3.StringUtils
import org.jetbrains.anko.sdk25.coroutines.onEditorAction
import org.jetbrains.anko.support.v4.alert

class CustomerPageFragment : AbstractReportPageFragment() {

    private lateinit var rootView: ViewGroup
    private lateinit var citiesAutoCompleteAdapter: ArrayAdapter<String>

    private val reportViewModel: ReportViewModel
        get() = (activity!! as CreateReportActivity).reportViewModel
    private var validation = Validation()

    override fun onPageHide() {
        setValuesToViewModel()
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        rootView = inflater.inflate(R.layout.fragment_customer, container, false) as ViewGroup
        setupFields()
        prepareValidation()

        reportViewModel.getReport().observe(this, Observer {
            setValuesToView(it!!)
        })

        return rootView
    }

    private fun setupFields() {

        var states = GeoLocationRepository.getStatesList()

        rootView.stateSpinner.setData(states.toTypedArray(), R.string.state_label, false)
        rootView.stateSpinner.customSpinnerItemSelectListener = object : OnCustomSpinnerItemSelected {
            override fun onSelectItem(value: String) {
                rootView.cityAutoComplete.text.clear()
                reportViewModel.setSelectedState(value)
                hasChange = true
            }
        }

        rootView.let {
            addTouchListener(it.nameOrSocialNameEditText, it.addressEditText, it.personDocumentEditText, it.cityAutoComplete,
                    it.telephoneEditText, it.emailEditText)
        }

        rootView.stateSpinner.getInput().setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN ->
                    if (!TechnicalReportApplication.hasPreferenceKey(GeoLocationRepository.STATE_LIST_KEY)) {
                        alert(getString(R.string.not_geo_location_info)) {
                            isCancelable = false
                            positiveButton(getString(R.string.try_again)) {
                                val dialog = DialogUtils.createProgressDialog(context!!)
                                dialog.show()
                                GeoLocationRepository.fetchGeoLocationData {
                                    states = GeoLocationRepository.getStatesList()
                                    rootView.stateSpinner.setData(states.toTypedArray(), R.string.state_label)
                                    dialog.hide()
                                }
                            }
                            negativeButton(getString(R.string.cancel)) { it.cancel() }
                        }.show()
                    }
            }
            false
        }

        rootView.addressEditText.onEditorAction { v, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_NEXT) {
                rootView.hideSoftKeyBoard()
                v?.clearFocus()
                rootView.stateSpinner.requestFocus()
                rootView.stateSpinner.performClick()
            }
        }

        rootView.emailEditText.onEditorAction { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                rootView.hideSoftKeyBoard()
                rootView.postDelayed({
                    (activity as CreateReportActivity).nextPage()
                }, 300)
            }
        }

        reportViewModel.cityList.value = mutableListOf()

        citiesAutoCompleteAdapter = ArrayAdapter(context, android.R.layout.simple_dropdown_item_1line, reportViewModel.cityList.value)

        rootView.cityAutoComplete.setAdapter(citiesAutoCompleteAdapter)

        rootView.telephoneEditText.addTextChangedListener(PhoneNumberFormattingTextWatcher(getString(R.string.country_code)))
        rootView.personDocumentEditText.setCpfCnpjMask()

        reportViewModel.selectedState.observe(this@CustomerPageFragment, Observer {
            citiesAutoCompleteAdapter.clear()
            citiesAutoCompleteAdapter.addAll(reportViewModel.cityList.value)
            citiesAutoCompleteAdapter.notifyDataSetChanged()
        })
    }

    private fun prepareValidation() {
        validation
                .addComponent(rootView.nameOrSocialNameEditText, ::fromEditText,
                        toInputLayout(rootView.nameOrSocialNameInputLayout),
                        R.string.name_error_message, ::required, ::noXSS)

                .addComponent(rootView.addressEditText, ::fromEditText,
                        toInputLayout(rootView.addressInputLayout),
                        R.string.address_error_message, ::required, ::noXSS)

                .addComponent(rootView.personDocumentEditText, ::fromEditText,
                        toInputLayout(rootView.personDocumentInputLayout),
                        Validation.Validator({ value: String? ->
                            isValidCPForCNPJ((value ?: StringUtils.EMPTY).onlyDigits())
                        },
                                R.string.person_document_invalid_error_message,
                                Validation.COUNTRY_BR))

                .addComponent(rootView.cityAutoComplete, ::fromAutoComplete,
                        toInputLayout(rootView.cityTextInputLayout),
                        R.string.city_error_message, ::required, ::noXSS)

                .addComponent(rootView.telephoneEditText, ::fromEditText,
                        toInputLayout(rootView.telephoneInputLayout),
                        Validation.Validator(::required, R.string.telephone_error_message, Validation.COUNTRY_BR),
                        Validation.Validator(::noXSS, R.string.invalid_phone_msg, Validation.COUNTRY_BR),
                        Validation.Validator(::telephone, R.string.invalid_phone_msg, Validation.COUNTRY_BR))

                .addComponent(rootView.stateSpinner, ::fromCustomSpinnerPosition,
                        toCustomSpinner(rootView.stateSpinner),
                        R.string.select_option_error, ::greaterThanZero)

                .addComponent(rootView.emailEditText, ::fromEditText,
                        toInputLayout(rootView.emailInputLayout),
                        R.string.email_error_message, ::noXSS, ::email)
    }

    fun validateFields(): Int = validation.validate(Validation.COUNTRY_BR)

    override fun setValuesToViewModel() {
        reportViewModel.getReport().value?.customerName = rootView.nameOrSocialNameInputLayout.valueText()
        reportViewModel.getReport().value?.customerNaturalPersonDocument = rootView.personDocumentInputLayout.valueText()
        reportViewModel.getReport().value?.customerJuridicalPersonDocument = rootView.personDocumentInputLayout.valueText()
        reportViewModel.getReport().value?.customerTelephone = rootView.telephoneInputLayout.valueText()
        reportViewModel.getReport().value?.customerEmail = rootView.emailInputLayout.valueText()
        reportViewModel.getReport().value?.customerAddress = rootView.addressInputLayout.valueText()
        reportViewModel.getReport().value?.customerStateCode = rootView.stateSpinner.valueItemSelected
        reportViewModel.getReport().value?.customerCityName = rootView.cityTextInputLayout.valueText()

        // TODO: Only valid during the MOCK
        reportViewModel.getReport().value?.customerCountryCode = TechnicalReportApplication.sharedPreferences.value.getString(GeoLocationRepository.COUNTRY_KEY, TechnicalReportApplication.deviceLocale.toString())
        val technician = Technician()
        reportViewModel.getReport().value?.technicianId = technician.id
        reportViewModel.getReport().value?.serviceCenterId = technician.serviceCenterId
        reportViewModel.getReport().value?.technicianName = technician.name
        reportViewModel.getReport().value?.technicianNaturalPersonDocument = technician.technicianNaturalPersonalDocument
        reportViewModel.getReport().value?.technicianProfessionalDocument = technician.technicianProfessionalDocument
        reportViewModel.getReport().value?.technicianSignaturePath = technician.technicianDigitizedSignaturePath
    }

    override fun setValuesToView(report: Report) {
        rootView.nameOrSocialNameEditText.setText(report.customerName)
        rootView.personDocumentEditText.setText(report.customerNaturalPersonDocument)
        rootView.telephoneEditText.setText(report.customerTelephone)
        rootView.emailEditText.setText(report.customerEmail)
        rootView.addressEditText.setText(report.customerAddress)

        stateSpinner.setItem(report.customerStateCode)
        rootView.cityAutoComplete.setText(report.customerCityName)
    }
}