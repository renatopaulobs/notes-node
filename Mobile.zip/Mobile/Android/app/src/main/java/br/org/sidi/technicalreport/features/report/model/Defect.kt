/*
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 */
package br.org.sidi.technicalreport.features.report.model

import android.arch.persistence.room.*
import br.org.sidi.technicalreport.features.report.model.Defect.Companion.DEFECT_TABLE_NAME
import br.org.sidi.technicalreport.features.report.model.Defect.Companion.PRODUCT_ID_COLUMN
import org.apache.commons.lang3.StringUtils
import java.io.Serializable

@Entity(tableName = DEFECT_TABLE_NAME
        , foreignKeys = [
    ForeignKey(entity = Product::class,
            parentColumns = [PRODUCT_ID_COLUMN],
            childColumns = [PRODUCT_ID_COLUMN],
            onDelete = ForeignKey.CASCADE)],
        indices = [Index(Defect.PRODUCT_ID_COLUMN)])
data class Defect(@PrimaryKey
                  @ColumnInfo(name=DEFECT_ID_COLUMN)
                  var id: Long = 0,
                  var name: String = StringUtils.EMPTY,
                  var code: String? = StringUtils.EMPTY,
                  var version: String = StringUtils.EMPTY,
                  var diagnostic: String = StringUtils.EMPTY,
                  var conclusion: String? = StringUtils.EMPTY,
                  var productId: Long = 0,
                  @Ignore var product: Product = Product(),
                  @Ignore var causes: List<Cause> = mutableListOf(),
                  @Ignore var evidenceTypes: List<EvidenceType> = mutableListOf()): Serializable {
    companion object {
        const val DEFECT_TABLE_NAME = "defects"
        const val PRODUCT_ID_COLUMN = "productId"
        const val DEFECT_ID_COLUMN = "defectId"
    }

    override fun equals(other: Any?): Boolean {
        if (other !is Defect) return false

        val defect: Defect = other

        return  this.id == defect.id
                && this.name == defect.name
                && this.code == defect.code
                && this.version == defect.version
                && this.diagnostic == defect.diagnostic
                && this.conclusion == defect.conclusion
                && this.productId == defect.productId
                && !causes.any{it != other.causes.firstOrNull { cause -> it.id == cause.id }}
                && !evidenceTypes.any{it != other.evidenceTypes.firstOrNull { evidenceType -> it.id == evidenceType.id }}
    }
}