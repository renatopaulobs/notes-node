/*
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 */
package br.org.sidi.technicalreport.features.report.view

import android.support.annotation.LayoutRes
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import br.org.sidi.technicalreport.R
import br.org.sidi.technicalreport.features.report.model.EvidenceType
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.cardview_evidence_item.view.*
import org.jetbrains.anko.alert
import java.lang.ref.WeakReference

class EvidencesAdapter(val data: List<EvidenceType>, val parent: WeakReference<EvidencePageFragment>) : RecyclerView.Adapter<EvidencesAdapter.CardViewHolder>() {
    val holders: HashMap<String, CardViewHolder> = HashMap()
    val errors: HashMap<String, Boolean> = HashMap()

    init {
        data.forEach { errors[it.description] = false }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CardViewHolder {
        val view: View = parent.inflate(R.layout.cardview_evidence_item, false)

        val cardViewHolder = CardViewHolder(view)
        cardViewHolder.setIsRecyclable(false)

        return cardViewHolder
    }

    private fun ViewGroup.inflate(@LayoutRes layoutRes: Int, attachToRoot: Boolean = false): View {
        return LayoutInflater.from(context).inflate(layoutRes, this, attachToRoot)
    }

    override fun getItemCount(): Int {
        return data.size
    }

    override fun onBindViewHolder(holder: CardViewHolder, position: Int) {
        val evidenceType = data[position]
        holder.evidenceTitle.text = evidenceType.description
        holder.setupErrorVisibility()

        setCardOnClick(holder)

        holder.itemView.delete_image.setOnClickListener {

            val ctx = parent.get()?.context!!

            ctx.alert(ctx.getString(R.string.remove_evidence_confirmation_msg)) {
                positiveButton(ctx.getString(R.string.remove)) {
                    parent.get()?.setEvidencePath(type = evidenceType.description, path = null, placeholder = evidenceType.placeholderPath)
                    setCardOnClick(holder)
                }
                negativeButton(ctx.getString(R.string.cancel)) {
                    it.cancel()
                }
            }.show()
        }

        holder.itemView.edit_image.setOnClickListener {
            parent.get()?.openCameraForEvidence(evidenceType)
        }

        holders[evidenceType.description] = holder

        if (evidenceType.placeholderPath != null) {
            Picasso.get().load(evidenceType.placeholderPath).into(holder.imageEvidenceThumbnail)
        }
    }

    fun setCardOnClick(holder: CardViewHolder, clear: Boolean = false) {
        if (!clear) {
            holder.itemView.setOnClickListener {
                parent.get()?.openCameraForEvidence(data[holder.adapterPosition])
            }
        } else {
            holder.itemView.setOnClickListener(null)
        }
    }

    fun setCardError(type: String, isInError: Boolean) {
        errors[type] = isInError
        holders[type]?.setupErrorVisibility()
    }

    inner class CardViewHolder(item: View) : RecyclerView.ViewHolder(item) {
        val evidenceTitle: TextView = itemView.evidence_title
        val imageEvidenceThumbnail: ImageView = itemView.evidence_thumbnail
        private val errorBorder: View = itemView.error_shape
        private val errorText: TextView = itemView.error_text

        fun setButtonsVisibility(isVisible: Boolean) {
            val visible = if (isVisible) View.VISIBLE else View.GONE
            itemView.apply {
                this.edit_image.visibility = visible
                this.delete_image.visibility = visible
            }
        }

        fun setupErrorVisibility() {
            val visibility = if (errors[evidenceTitle.text] == true) View.VISIBLE else View.INVISIBLE
            errorBorder.visibility = visibility
            errorText.visibility = visibility
        }
    }
}