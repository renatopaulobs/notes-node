/*
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 */
package br.org.sidi.technicalreport.features.report.viewmodel

import android.arch.lifecycle.LiveData
import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.ViewModel
import br.org.sidi.technicalreport.features.report.business.DefectRepository
import br.org.sidi.technicalreport.features.report.business.GeoLocationRepository.Companion.getCitiesByStateCode
import br.org.sidi.technicalreport.features.report.business.ReportRepository
import br.org.sidi.technicalreport.features.report.model.Cause
import br.org.sidi.technicalreport.features.report.model.Defect
import br.org.sidi.technicalreport.features.report.model.EvidenceType
import br.org.sidi.technicalreport.features.report.model.Report

class ReportViewModel : ViewModel() {


    lateinit var evidenceViewModel: EvidenceViewModel
    private var report: MutableLiveData<Report> = MutableLiveData()
    init {
        report.value = Report()
    }

    var lastProductSelectedPosition : Int = -1
    private val productSelectedId = MutableLiveData<Long>()

    var lastDefectSelectedPosition : Int = -1
    lateinit var defectsList : List<Defect>
    private var defectSelectedName =  MutableLiveData<String>()

    var defectCount : Int = 0

    private var causeSelectedName =  MutableLiveData<String>()

    var evidenceTypeList : List<EvidenceType> = emptyList()

    var evidencePathMap: HashMap<String, String?> = HashMap()

    private var technicalReportValid = MutableLiveData<Boolean>()
    private var symptomValid = MutableLiveData<Boolean>()

    var productSwitch = MutableLiveData<Boolean>()
    var defectSwitch = MutableLiveData<Boolean>()
    var causeSwitch = MutableLiveData<Boolean>()

    var selectedState = MutableLiveData<String>()
    val cityList = MutableLiveData<MutableList<String>>()

    fun setSelectedState(selectedState: String) {
        cityList.value = getCitiesByStateCode(selectedState)
        this.selectedState.value = selectedState
    }

    fun getDefectSelectedName() : LiveData<String> {
        return this.defectSelectedName
    }

    fun setDefectSelectedName(defectSelectedName : String) {
        this.defectSelectedName.value = defectSelectedName
    }

    fun setCauseSelectedName(causeSelectedName: String) {
        this.causeSelectedName.value = causeSelectedName
    }

    fun updateDefectsByProductId(productId: Long?) {
        defectsList = DefectRepository.listByProductIdEagerly(productId ?: 0)
    }

    fun updateEvidenceTypesByDefectName(defectName : String?) {
        evidenceTypeList = defectsList.firstOrNull {defect -> defect.name == defectName}?.evidenceTypes ?: emptyList()
    }

    fun getSelectedDefect(): Defect? {
        return defectsList.find { it.name == defectSelectedName.value }
    }

    fun getSelectedCause(): Cause? {
        return getSelectedDefect()?.causes?.find {  it.text == causeSelectedName.value }
    }

    fun getProductSelectedId() : LiveData<Long> {
        return productSelectedId
    }

    fun setProductSelectedId(productSelectedId : Long) {
        this.productSelectedId.value = productSelectedId
        setDefectCountByProductId(productSelectedId)
    }

    fun setDefectCountByProductId(productSelectedId: Long): Int {
        this.defectCount = DefectRepository.count(productSelectedId)
        return this.defectCount
    }

    fun checkNeedsWarning(): Boolean = evidencePathMap.any { it.value != null }


    fun setTechnicalReportValid(isValid: Boolean) {
        technicalReportValid.value = isValid
    }

    fun getTechnicalReportValid() : LiveData<Boolean> {
        return technicalReportValid
    }

    fun setSymptomValid(isValid: Boolean) {
        symptomValid.value = isValid
    }

    fun getSymptomValid() : LiveData<Boolean> {
        return symptomValid
    }

    fun saveReport() {
        ReportRepository.saveReport(report.value!!)
    }

    fun getReport(): LiveData<Report> {
        return report
    }

    fun setReport(report: Report) {
        this.report.value = report
    }
}
