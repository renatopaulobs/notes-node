/*
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 */
package br.org.sidi.technicalreport.common.view

import android.arch.lifecycle.LiveData
import android.arch.lifecycle.MutableLiveData
import android.content.Context
import android.support.constraint.ConstraintLayout
import android.util.AttributeSet
import android.view.*
import android.widget.ArrayAdapter
import android.widget.ListView
import br.org.sidi.technicalreport.R
import br.org.sidi.technicalreport.util.hideSoftKeyBoard
import kotlinx.android.synthetic.main.custom_spinner.view.*
import org.apache.commons.lang3.StringUtils


interface OnCustomSpinnerItemSelected {
    fun onSelectItem(value: String)
}

class CustomSpinner @JvmOverloads constructor(
        context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : ConstraintLayout(context, attrs, defStyleAttr) {

    companion object {
        private const val MAX_NUMBER = 10
    }

    var customSpinnerItemSelectListener: OnCustomSpinnerItemSelected? = null

    private var positionItemSelected = MutableLiveData<Int>()
    var valueItemSelected = StringUtils.EMPTY
    private set

    private lateinit var items: Array<String>

    init {
        this.hideSoftKeyBoard()
        positionItemSelected.value = -1
        LayoutInflater.from(context).inflate(R.layout.custom_spinner, this, true)

        setAttributes(attrs)
    }

    private fun setAttributes(attrs: AttributeSet?) {
        attrs?.let {
            val typedArray = context.obtainStyledAttributes(it,
                    R.styleable.custom_spinner_attributes, 0, 0)

            val hint = resources.getText(typedArray
                    .getResourceId(R.styleable
                            .custom_spinner_attributes_custom_spinner_hint,
                            R.string.select_option_error))

            selectItemEditText.hint = hint
            typedArray.recycle()
        }
    }

    fun setData(data: Array<String>, firstItemResource: Int, isLatSpinner: Boolean = false) {
        items = arrayOf(resources.getString(firstItemResource)) + data
        val arrayAdapter = ArrayAdapter(context, R.layout.item_spinner, R.id.tv_item_spinner, items)
        list_spinner.adapter = arrayAdapter
        list_spinner.divider = context.getDrawable(R.drawable.divider_spinner_shape)

        list_spinner.setOnItemClickListener { _, _, position, _ ->
            valueItemSelected = list_spinner.getItemAtPosition(position) as String
            positionItemSelected.value = position
            selectItemTextInputLayout.editText!!.setText(valueItemSelected)
            val firstItem = list_spinner.getItemAtPosition(0) as String
            if (valueItemSelected.equals(firstItem, false)) {
                selectItemTextInputLayout.editText!!.text.clear()
            }

            visibilityListSpinner(items.size, isLatSpinner)

            customSpinnerItemSelectListener?.onSelectItem(valueItemSelected)
        }

        selectItemEditText.setOnClickListener {
            visibilityListSpinner(items.size, isLatSpinner)
        }

    }

    private fun setListViewDimensions(size: Int, isLatSpinner: Boolean) {
        var value = selectItemTextInputLayout.editText!!.text.toString()
        if ((!isLatSpinner || value.isEmpty()) && size < MAX_NUMBER) {
            content_list_spinner.layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT
            list_spinner.layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT
            list_spinner.requestLayout()
        } else {
            content_list_spinner.layoutParams.height = ViewGroup.LayoutParams.MATCH_PARENT
            list_spinner.layoutParams.height = 0
            list_spinner.requestLayout()
        }
    }

    fun setEnabledSpinner(enabled: Boolean) {
        selectItemEditText.isEnabled = enabled
    }

    fun setSelection(position: Int) {
        valueItemSelected = list_spinner.getItemAtPosition(position) as String
        selectItemTextInputLayout.editText!!.setText(valueItemSelected)
    }

    //    Note the changes in the dimension of the list to update the reference component.
    fun observeListDimensions(referenceView: View) {
        selectItemTextInputLayout.waitForLayout {
            referenceView.layoutParams.height = selectItemTextInputLayout.height
            referenceView.requestLayout()
        }
    }

    private inline fun <T : View> T.waitForLayout(crossinline callback: T.() -> Unit) {
        viewTreeObserver.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                viewTreeObserver.removeOnGlobalLayoutListener(this)
                callback()
            }
        })
    }

    fun setItem(value: String) {
        selectItemEditText.setText(value)
        for(i in 0 until items.count() - 1) {
            if (items[i] == value) {
                positionItemSelected.value = i
            }
        }
    }

    fun getSelectedItemPosition(): LiveData<Int> {
        return positionItemSelected
    }

    fun getInput(): View {
        return selectItemEditText
    }

    fun getList(): ListView {
        return list_spinner
    }


    private fun visibilityListSpinner(size: Int, isLatSpinner: Boolean) {
        this.hideSoftKeyBoard()
        if (list_spinner.visibility == View.GONE) {
            setListViewDimensions(size, isLatSpinner)
            list_spinner.visibility = View.VISIBLE
        } else {
            list_spinner.visibility = View.GONE
        }
    }

    fun error(errorResource: String?) {
        selectItemTextInputLayout.isErrorEnabled = (errorResource != null)
        selectItemTextInputLayout.error = errorResource
    }

}
