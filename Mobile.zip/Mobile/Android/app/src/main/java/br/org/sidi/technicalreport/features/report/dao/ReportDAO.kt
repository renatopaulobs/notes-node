/*
 *
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 *
 */

package br.org.sidi.technicalreport.features.report.dao

import android.arch.lifecycle.LiveData
import android.arch.lifecycle.MutableLiveData
import android.arch.persistence.room.Dao
import android.arch.persistence.room.Query
import android.arch.persistence.room.Transaction
import br.org.sidi.technicalreport.features.report.model.Report
import br.org.sidi.technicalreport.features.report.model.ReportWithEvidences

@Dao
interface ReportDAO : BaseDAO<Report> {
    @Transaction
    @Query("SELECT * from reports")
    fun listEagerly(): List<ReportWithEvidences>

    @Transaction
    @Query("SELECT * FROM reports WHERE reportId = :reportId")
    fun findByIdEagerly(reportId: Long) : ReportWithEvidences

    @Transaction
    @Query("SELECT * FROM reports WHERE SONumber = :OSNumber")
    fun findByOSNumber(OSNumber: String): Report

    @Transaction
    @Query("SELECT COUNT(*) FROM reports WHERE SONumber = :OSNumber")
    fun countBySONumber(OSNumber: String): Int

    @Transaction
    @Query("SELECT * FROM reports ORDER BY creationDate DESC")
    fun list(): LiveData<MutableList<ReportWithEvidences>>

    @Transaction
    @Query("SELECT MAX(reportId) FROM reports")
    fun maxReportID(): Long

    @Transaction
    @Query("SELECT COUNT(1) FROM reports WHERE status != 1")
    fun countNonDraft(): Int
}