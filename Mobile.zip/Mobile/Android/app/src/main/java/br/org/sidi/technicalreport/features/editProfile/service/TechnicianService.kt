/*
 *
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 *
 */

package br.org.sidi.technicalreport.features.editProfile.service

import br.org.sidi.technicalreport.BuildConfig
import br.org.sidi.technicalreport.features.report.model.Technician
import br.org.sidi.technicalreport.features.report.model.TechnicianSaveData
import br.org.sidi.technicalreport.util.isOnline
import okhttp3.OkHttpClient
import org.apache.http.HttpStatus
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit
import javax.net.ssl.HttpsURLConnection

object TechnicianService {

    private const val TIMEOUT = 60L

    private val retrofit = Retrofit.Builder()
            .baseUrl(BuildConfig.TECHNICIAN_MS_ENDPOINT)
            .addConverterFactory(MoshiConverterFactory.create())
            .client(OkHttpClient.Builder()
                    .readTimeout(TechnicianService.TIMEOUT, TimeUnit.SECONDS)
                    .connectTimeout(TechnicianService.TIMEOUT, TimeUnit.SECONDS)
                    .build())
            .build()

    private val technicianClient = retrofit.create(TechnicianClient::class.java)!!

    fun getTechnician(userLogin: String, success: (Technician?) -> Unit, error: (status: Int) -> Unit) {
        if (!isOnline()) {
            error(0)
            return
        }
        technicianClient.getTechnician(userLogin)
                .enqueue(object : Callback<Technician> {

                    override fun onFailure(call: Call<Technician>?, t: Throwable?) {
                        error(HttpStatus.SC_INTERNAL_SERVER_ERROR)
                    }

                    override fun onResponse(call: Call<Technician>?, response: Response<Technician>?) {
                        when (response?.code()) {
                            HttpStatus.SC_OK -> success(response.body())
                            else -> error(response?.code() ?: 0)
                        }
                    }
                })
    }

    fun updateProfile(userLogin: String, technician: TechnicianSaveData, success: (Technician?) -> Unit, error: (Int)  -> Unit) {
        if (!isOnline()){
            error(0)
            return
        }
        technicianClient.updateProfile(userLogin, technician)
                .enqueue(object: Callback<Technician> {
                    override fun onFailure(call: Call<Technician>?, t: Throwable?) {
                        error(HttpStatus.SC_INTERNAL_SERVER_ERROR)
                    }

                    override fun onResponse(call: Call<Technician>?, response: Response<Technician>?) {
                        when(response?.code()) {
                            HttpStatus.SC_OK -> success(response.body())
                            else -> error(response?.code() ?: 0)
                        }
                    }
                })
    }
}