/*
 *
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 *
 */

package br.org.sidi.technicalreport.features.sync.model

import br.org.sidi.technicalreport.features.report.model.*

data class SyncDiff(val newProducts: List<Product> = emptyList(),
                    val removedProducts: List<Product> = emptyList(),
                    val changedProducts: List<Product> = emptyList(),
                    val newDefects: List<Defect> = emptyList(),
                    val removedDefects: List<Defect> = emptyList(),
                    val changedDefects: List<Defect> = emptyList(),
                    val newCauses: List<Cause> = emptyList(),
                    val removedCauses: List<Cause> = emptyList(),
                    val changedCauses: List<Cause> = emptyList(),
                    val newEvidenceTypes: List<EvidenceType> = emptyList(),
                    val removedEvidenceTypes: List<EvidenceType> = emptyList(),
                    val changedEvidenceTypes: List<EvidenceType> = emptyList()) {

    data class OutOfSync(val product: Boolean, val defect: Boolean, val cause: Boolean, val evidenceType: Boolean) {
        val isOutOfSync: Boolean
            get() = product || defect || cause || evidenceType
    }

    fun checkReport(report: Report): OutOfSync {
        val evidencesInReport = report.evidences.map { it.evidenceTypeId }
        return OutOfSync(report.productId in changedProducts.map { it.id } || report.productId in removedProducts.map { it.id },
                report.defectId in changedDefects.map { it.id } || report.defectId in removedDefects.map { it.id },
                report.rootCauseId in changedCauses.map { it.id } || report.rootCauseId in removedCauses.map { it.id },
                evidencesInReport.any { it in changedEvidenceTypes.map { x -> x.id } } || evidencesInReport.any { it in removedEvidenceTypes.map { x -> x.id } })
    }
}