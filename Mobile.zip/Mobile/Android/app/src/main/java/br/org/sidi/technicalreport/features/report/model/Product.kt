/*
 *
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 *
 */

package br.org.sidi.technicalreport.features.report.model

import android.arch.persistence.room.ColumnInfo
import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey
import br.org.sidi.technicalreport.features.report.model.Product.Companion.PRODUCT_TABLE_NAME
import org.apache.commons.lang3.StringUtils

@Entity(tableName = PRODUCT_TABLE_NAME)
data class Product(@PrimaryKey @ColumnInfo(name=PRODUCT_ID_COLUMN)
                   var id: Long = 0,
                   var name: String = StringUtils.EMPTY,
                   var warrantyTerm: String? = StringUtils.EMPTY) {

    companion object {
        const val PRODUCT_TABLE_NAME = "products"
        const val PRODUCT_ID_COLUMN = "productId"
    }

    override fun equals(other: Any?): Boolean {
        if (other !is Product) return false

        var product : Product = other

        return  this.id == product.id
                && this.name == product.name
                && this.warrantyTerm == product.warrantyTerm
    }
}