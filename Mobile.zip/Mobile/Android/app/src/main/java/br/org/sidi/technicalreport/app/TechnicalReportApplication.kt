/*
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 */

package br.org.sidi.technicalreport.app

import android.app.Application
import android.content.Context
import android.os.Build
import android.support.annotation.StringRes
import br.org.sidi.technicalreport.R
import br.org.sidi.technicalreport.features.report.dao.AppDatabase
import java.util.*

class TechnicalReportApplication : Application() {
    companion object {
        private const val PREFS_FILENAME = "TechReportPrefs"

        lateinit var instance: TechnicalReportApplication private set
        lateinit var deviceLocale: Locale private set

        var sharedPreferences = lazy { instance.getSharedPreferences(PREFS_FILENAME, Context.MODE_PRIVATE) }

        fun hasPreferenceKey(key: String) = sharedPreferences.value.contains(key)

        fun getStringRes(@StringRes resId: Int): String = instance.getString(resId)
        fun getSupportedLanguages() : Array<String> = instance.resources.getStringArray(R.array.supported_languages)
    }

    override fun onCreate() {
        super.onCreate()

        instance = this

        configureLanguage()

        initDatabase()
    }

    private fun initDatabase() {
        AppDatabase.getInstance(this)
    }

    private fun configureLanguage() {
        @Suppress("DEPRECATION")
        deviceLocale =  if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N)
                            resources.configuration.locales[0]
                        else
                            resources.configuration.locale
    }
}