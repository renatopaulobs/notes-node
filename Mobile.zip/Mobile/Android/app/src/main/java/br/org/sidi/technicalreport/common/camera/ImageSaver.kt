/*
 *
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 *
 */

package br.org.sidi.technicalreport.common.camera

import android.content.ContentResolver
import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.Image
import android.net.Uri
import android.provider.MediaStore




internal class ImageSaver(private val contentResolver: ContentResolver, private val image: Image, private val callback: (result: String?) -> Unit) : Runnable {
    override fun run() {
        val image = getBitmap()
        val values = prepareImageContentValues()
        var newPhotoPath: Uri? = null

        try {
            newPhotoPath = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)

            contentResolver.openOutputStream(newPhotoPath!!).use { image.compress(Bitmap.CompressFormat.JPEG, 85, it) }
        } catch (_: Exception) {
            if (newPhotoPath != null) {
                contentResolver.delete(newPhotoPath, null, null)
                newPhotoPath = null
            }
        }

        callback(newPhotoPath?.toString())
    }

    private fun getBitmap() : Bitmap {
        val buffer = image.planes[0].buffer
        val bytes = ByteArray(buffer.capacity())
        buffer.get(bytes)
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, null)
    }

    private fun prepareImageContentValues(): ContentValues {
        val values = ContentValues()
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        values.put(MediaStore.Images.Media.DATE_ADDED, System.currentTimeMillis() / 1000)
        values.put(MediaStore.Images.Media.DATE_TAKEN, System.currentTimeMillis())
        return values
    }
}
