/*
 *
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 *
 */

package br.org.sidi.technicalreport.features.editProfile.view

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import br.org.sidi.technicalreport.R
import br.org.sidi.technicalreport.common.validation.Validation
import br.org.sidi.technicalreport.util.ImageToBase64
import kotlinx.android.synthetic.main.activity_signature.*

class SignatureActivity : AppCompatActivity() {

    companion object {
        const val SIGNATURE_KEY_RESPONSE = "br.org.sidi.technicalreport.features.editProfile"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signature)

        signature_view.backgroundColor = Color.TRANSPARENT
        supportActionBar?.title = getString(R.string.design_your_signature_title)
    }

    private fun clearArea (){
        signature_view.clearCanvas()
    }

    private fun saveSignature(){
        if (!signature_view.isBitmapEmpty) {
            val intent = Intent()
            intent.putExtra(SIGNATURE_KEY_RESPONSE, ImageToBase64.encodeBitmapToBase64(signature_view.signatureBitmap))

            setResult(RESULT_OK, intent)
        }
        finish()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.menu_signature, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when (item?.itemId) {
            R.id.save_signature -> { saveSignature() }
            R.id.clear_signature -> { clearArea() }
        }
        return true
    }
}
