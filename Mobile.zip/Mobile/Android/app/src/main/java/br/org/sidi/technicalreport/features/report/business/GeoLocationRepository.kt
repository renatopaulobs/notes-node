/*
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 *
 */

package br.org.sidi.technicalreport.features.report.business

import br.org.sidi.technicalreport.app.TechnicalReportApplication
import br.org.sidi.technicalreport.features.editProfile.service.AuthenticationService
import br.org.sidi.technicalreport.util.Logger
import org.apache.commons.lang3.StringUtils
import java.io.Serializable

class GeoLocationRepository {

    companion object {

        const val COUNTRY_KEY = "COUNTRY"
        const val STATE_LIST_KEY = "STATE_LIST"

        fun fetchGeoLocationData(onResult: (() -> Unit)? = null) {
            AuthenticationService.getGeoLocationData(TechnicalReportApplication.deviceLocale.country,
                    {
                        storeGeolocationData(it)
                        onResult?.invoke()
                    },
                    { Logger.log(String.format("Error on get geolocation info: %d", it)) })
        }


        private fun storeGeolocationData(locationInfo: GeoLocationInfo?) {
            val geoLocationDataItems = locationInfo?.data?.Items

            TechnicalReportApplication
                    .sharedPreferences
                    .value
                    .edit()
                    .remove(COUNTRY_KEY)
                    .putString(COUNTRY_KEY, TechnicalReportApplication.deviceLocale.country)
                    .apply()

            if (geoLocationDataItems?.isNotEmpty()!!) {

                TechnicalReportApplication
                        .sharedPreferences
                        .value
                        .edit()
                        .remove(STATE_LIST_KEY)
                        .putStringSet(STATE_LIST_KEY, geoLocationDataItems.map { a -> a.StateCode }.toSet())
                        .apply()

                geoLocationDataItems.forEach {
                    it.run {

                        TechnicalReportApplication
                                .sharedPreferences
                                .value
                                .edit()
                                .remove(it.StateCode)
                                .putStringSet(it.StateCode, it.Cities.toSet())
                                .apply()
                    }
                }
            }
        }

        fun getStatesList(): List<String> {
            return TechnicalReportApplication
                    .sharedPreferences
                    .value
                    .getStringSet(STATE_LIST_KEY, emptySet())
                    .toList()
                    .sorted()
        }

        fun getCitiesByStateCode(stateCode: String): MutableList<String> {
            return TechnicalReportApplication
                    .sharedPreferences
                    .value
                    .getStringSet(stateCode, mutableSetOf())
                    .sorted()
                    .toMutableList()
        }
    }
}

data class GeoLocation(var CountryCode: String = StringUtils.EMPTY,
                       var CountryName: String = StringUtils.EMPTY,
                       var StateCode: String = StringUtils.EMPTY,
                       var StateName: String = StringUtils.EMPTY,
                       var Cities: List<String> = mutableListOf()) : Serializable

data class GeoLocationData(var Items: List<GeoLocation> = mutableListOf()) : Serializable

data class GeoLocationInfo(var Message: String = StringUtils.EMPTY,
                           var data: GeoLocationData = GeoLocationData()) : Serializable

