/*
 *
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 *
 */

package br.org.sidi.technicalreport.util

import android.app.Activity
import android.content.Context
import android.graphics.Rect
import android.view.Gravity
import android.view.View
import android.widget.Toast
import br.org.sidi.technicalreport.R
import kotlinx.android.synthetic.main.toast.*
import kotlinx.android.synthetic.main.toast.view.*
import org.jetbrains.anko.layoutInflater
import org.jetbrains.anko.viewAnimator
import org.jetbrains.anko.windowManager

object ToastUtils {

    private const val DEFAULT_TOAST_HEIGHT = 48.0F

    fun createToast(context: Context, message: String) {
        val toastView = context.layoutInflater.inflate(R.layout.toast,
                (context as Activity).findViewById(R.id.toast_layout_root))

        val t = Toast(context)

        var rect = Rect()
        context.windowManager.defaultDisplay.getRectSize(rect)

        t.view = toastView
        t.view.toast_message.text = message
        t.view.minimumWidth = rect.width()
        t.view.inner_layout.minimumWidth = rect.width()
        t.view.inner_layout.minimumHeight = ViewUtils.convertToPixels(context, DEFAULT_TOAST_HEIGHT).toInt()
        t.show()
    }

    fun createToast(context: Context, messageId: Int) {
        createToast(context, context.getString(messageId))
    }
}