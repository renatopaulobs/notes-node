/*
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 */
package br.org.sidi.technicalreport.features.report.model

import android.arch.persistence.room.*
import br.org.sidi.technicalreport.features.report.model.EvidenceType.Companion.EVIDENCE_TYPE_TABLE
import org.apache.commons.lang3.StringUtils
import java.io.Serializable

@Entity(tableName = EVIDENCE_TYPE_TABLE,
        primaryKeys = [EvidenceType.EVIDENCE_TYPE_ID_COLUMN, "defectId"],
        foreignKeys = [
    (ForeignKey(entity = Defect::class,
            parentColumns = [Defect.DEFECT_ID_COLUMN],
            childColumns = [Defect.DEFECT_ID_COLUMN],
            onDelete = ForeignKey.CASCADE))],
        indices = [(Index(Defect.DEFECT_ID_COLUMN))])
data class EvidenceType(@ColumnInfo(name=EVIDENCE_TYPE_ID_COLUMN)
                        var id: Long = 0,
                        var placeholderPath: String? = StringUtils.EMPTY,
                        var description: String = StringUtils.EMPTY,
                        @Ignore var lightBoxMask: MaskType = MaskType.DEFAULT,
                        var lightBoxMaskCode: Int = lightBoxMask.code,
                        var isFactoryStandard: Boolean = false,
                        var index: Int = 0,
                        @Ignore var imageOrientation: Orientation = Orientation.LANDSCAPE,
                        var orientation: Int = imageOrientation.code,
                        var isMandatory: Boolean = false,
                        var defectId: Long = 0): Serializable {
    companion object {
        const val EVIDENCE_TYPE_TABLE = "evidencesType"
        const val EVIDENCE_TYPE_ID_COLUMN = "evidencesTypeId"
    }
    enum class MaskType(val code: Int) {
        DEFAULT(0),
        SQUARE(1),
        RECT(2)
    }

    enum class Types (val code: Int) {
        EVIDENCE_TYPE_FRONTAL(1),
        EVIDENCE_TYPE_BACK(2),
        EVIDENCE_TYPE_LABEL_ZOOM_IN(3),
        EVIDENCE_TYPE_AREA_PANORAMIC(4),
        EVIDENCE_TYPE_AREA_ZOOM_IN(5),
        EVIDENCE_TYPE_BORDER_TOP(6),
        EVIDENCE_TYPE_BORDER_BOTTOM(7),
        EVIDENCE_TYPE_BORDER_RIGHT(8),
        EVIDENCE_TYPE_BORDER_LEFT(9),
        EVIDENCE_TYPE_LABEL_HUMIDITY(10), // 10
        EVIDENCE_TYPE_OXIDATION_PANORAMIC(11),
        EVIDENCE_TYPE_CUSTOMER_SCREEN_ZOOM_OUT(12),
        EVIDENCE_TYPE_REF_PANORAMIC(13),
        EVIDENCE_TYPE_NEW_ZOOM_IN(14),
        EVIDENCE_TYPE_MODEL_SCREEN_ZOOM_OUT(15),
        EVIDENCE_TYPE_LABEL_LOCAL(16),
        EVIDENCE_TYPE_ORIGINAL_REF_TABLE(17),
        EVIDENCE_TYPE_DATA_REF_TABLE(18)
    }

    enum class Orientation(val code: Int){
        PORTRAIT(0),
        LANDSCAPE(1)
    }
}