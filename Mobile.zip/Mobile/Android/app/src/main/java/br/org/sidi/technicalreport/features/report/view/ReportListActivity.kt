/*
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 */

package br.org.sidi.technicalreport.features.report.view

import android.app.Dialog
import android.app.ProgressDialog
import android.app.SearchManager
import android.arch.lifecycle.ViewModelProviders
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.support.v4.media.session.MediaButtonReceiver.handleIntent
import android.support.v7.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView
import br.org.sidi.technicalreport.R
import br.org.sidi.technicalreport.R.id.*
import br.org.sidi.technicalreport.app.TechnicalReportApplication
import br.org.sidi.technicalreport.features.report.business.ReportRepository
import br.org.sidi.technicalreport.features.report.model.Report
import br.org.sidi.technicalreport.features.report.viewmodel.ReportListViewModel
import br.org.sidi.technicalreport.features.sync.business.SyncBO
import br.org.sidi.technicalreport.features.sync.service.SyncService
import br.org.sidi.technicalreport.util.*
import com.facebook.stetho.Stetho
import kotlinx.android.synthetic.main.activity_report_list.*
import kotlinx.android.synthetic.main.report_list_footer.*
import kotlinx.android.synthetic.main.report_list_footer.view.*
import org.apache.commons.lang3.StringUtils
import org.apache.http.HttpStatus
import org.jetbrains.anko.alert
import org.jetbrains.anko.sdk25.coroutines.onClick
import org.jetbrains.anko.support.v4.swipeRefreshLayout
import java.text.SimpleDateFormat
import java.util.*



class ReportListActivity : AppCompatActivity() {

    private val reportListViewModel: ReportListViewModel
            by lazy { ViewModelProviders.of(this).get(ReportListViewModel::class.java) }

    private lateinit var reportListAdapter: ReportListAdapter
    private lateinit var searchView: android.support.v7.widget.SearchView

    companion object {
        const val REQUEST_CREATE_REPORT = 7785
        const val REPORT_LIST_ACTIVITY = "br.org.sidi.technicalreport.features.report.view.ReportListActivity"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_report_list)

        val dialog = DialogUtils.createProgressDialog(this@ReportListActivity)
        dialog.show()

        val footer = getFooterView()
        reportList.addFooterView(footer)

        reportList.emptyView = emptyReportList

        swipe_container.setOnRefreshListener {
            reportListViewModel.setCurrentPage(1)
            reportListViewModel.getReportsPaginated()
            swipe_container.isRefreshing = false
        }

        footer.load_list_report_btn.onClick { v -> onClick(v) }
        addReport.setOnClickListener { v -> onClick(v) }

        if (!SyncBO.hasEverDoneASuccessfulSync()) {
            handleForceSync()
        }

        Stetho.initializeWithDefaults(this)

        reportList.onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
            val report = reportListAdapter.getItem(position)
            report?.let {
                val intent = Intent(this@ReportListActivity, PreviewReportActivity::class.java)
                intent.putExtra(Intent.EXTRA_TITLE, String.format(getString(R.string.prod_def_summary_report_pattern, report.productName, report.defectName)))
                intent.putExtra(PreviewReportActivity.REPORT_KEY, report)
                intent.putExtra(PreviewReportActivity.ACTION_DETAILS, REPORT_LIST_ACTIVITY)
                startActivity(intent)
            }
        }

        reportListViewModel.getReportsPaginated()

        reportListViewModel.reportList.observe(this, android.arch.lifecycle.Observer {
            if (!this@ReportListActivity::reportListAdapter.isInitialized) {
                reportListAdapter = ReportListAdapter(this, it!!)
                reportList.adapter = reportListAdapter
            } else {
                reportListAdapter.setData(it!!)
                reportListAdapter.notifyDataSetChanged()
            }
            if (reportListViewModel.hasMore) {
                footer.load_list_report_btn.visibility = View.VISIBLE
            } else {
                footer.load_list_report_btn.visibility = View.INVISIBLE
            }
        })

        reportListViewModel.getRequestStatus().observe(this, android.arch.lifecycle.Observer {
            it?.let {
                when(it) {
                    HttpStatus.SC_OK -> dialog.hide()
                    else -> {
                        dialog.hide()
                        alert(getString(R.string.no_internet_connection_msg)) {
                            positiveButton(getString(R.string.try_again)) { reportListViewModel.getReportsPaginated() }
                            negativeButton(getString(R.string.cancel)) { it.cancel() }
                        }.show()
                    }

                }
            }
        })
    }

    private fun setupFooter(): View {
        val footer = layoutInflater.inflate(R.layout.report_list_footer, null)
        val pixels16dp = ViewUtils.convertToPixels(this, resources.getDimension(R.dimen.margin_16dp)).toInt()
        val pixels100dp = ViewUtils.convertToPixels(this, resources.getDimension(R.dimen.margin_100dp)).toInt()
        footer.container_footer.setPadding(pixels16dp, pixels16dp, pixels16dp, pixels100dp)
        footer.container_footer.isEnabled = false
        footer.container_footer.isClickable = false
        reportList.addFooterView(footer)
        return footer
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.menu_list_report, menu)

        val searchManager = this@ReportListActivity.getSystemService(Context.SEARCH_SERVICE) as SearchManager
        val searchItem  = menu?.findItem(R.id.action_search)
        if (searchItem != null) {
            searchView = searchItem.actionView as android.support.v7.widget.SearchView
        }

        if (this@ReportListActivity::searchView.isInitialized) {
            searchView.setSearchableInfo(searchManager.getSearchableInfo(this@ReportListActivity.componentName))
            searchView.maxWidth = Integer.MAX_VALUE


            searchView.setOnQueryTextListener(object: android.support.v7.widget.SearchView.OnQueryTextListener {
                override fun onQueryTextSubmit(query: String?): Boolean {
                    reportListAdapter.filter(query)
                    return false
                }

                override fun onQueryTextChange(query: String?): Boolean {
                    reportListAdapter.filter(query)
                    return true
                }
            } )
        }
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when (item?.itemId) {
            R.id.sync_button -> handleForceSync()
            R.id.action_search -> return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun getFooterView(): View {
        val footer = layoutInflater.inflate(R.layout.report_list_footer, null)
        val pixels16dp = ViewUtils.convertToPixels(this, resources.getDimension(R.dimen.margin_16dp)).toInt()
        val pixels100dp = ViewUtils.convertToPixels(this, resources.getDimension(R.dimen.margin_50dp)).toInt()
        footer.container_footer.setPadding(pixels16dp, pixels16dp, pixels16dp, pixels100dp)
        footer.container_footer.isEnabled = false
        footer.container_footer.isClickable = false

        return footer
    }

    private fun handleForceSync() {
        if (!isOnline()) {
            showConnectionDialog()
        } else {
            performSync {
                ToastUtils.createToast(this, R.string.sync_success_msg)
            }
        }
    }

    override fun onBackPressed() {
        if (!searchView.isIconified) {
            searchView.isIconified = true
            return
        }
        super.onBackPressed()
    }

    private fun performSync(success: (() -> Unit)? = null) {
        Logger.log("Start Sync")

        SyncBO.syncAndGetDiff({
            Logger.log("Sync Data Successful - Changes received")
            success?.let { success() }
            refreshAfterSync()
        },
                {
                    refreshAfterSync()
                    Logger.log("Sync Data Successful - Already Updated") /*Handle no changes*/
                },
                {
                    showConnectionDialog()
                })
    }

    private fun showConnectionDialog() {
        alert(getString(R.string.no_internet_connection_msg)) {
            positiveButton(getString(R.string.try_again)) { handleForceSync() }
            negativeButton(getString(R.string.cancel)) { it.cancel() }
        }.show()
    }

    override fun onResume() {
        super.onResume()

        refreshLastSyncLabel(SyncService.getLastSyncDate())
        addReport.isEnabled = true
    }

    private fun refreshAfterSync() {
        val formatter = SimpleDateFormat(getString(R.string.date_zulu_format), TechnicalReportApplication.deviceLocale)
        formatter.timeZone = TimeZone.getTimeZone(getString(R.string.utc))
        val lastSync = formatter.format(Date())
        SyncService.setLastSyncDate(lastSync)

        refreshLastSyncLabel(lastSync)
    }

    private fun refreshLastSyncLabel(lastSync: String?) {
        lastUpdate.text = if (!StringUtils.isEmpty(lastSync)) {
            val format = SimpleDateFormat(getString(R.string.date_zulu_format), TechnicalReportApplication.deviceLocale)
            format.timeZone = TimeZone.getTimeZone(getString(R.string.utc))
            val date = format.parse(lastSync)
            val formatted = SimpleDateFormat(getString(R.string.sync_datetime_format), TechnicalReportApplication.deviceLocale).format(date)
            String.format(getString(R.string.lastSync), formatted)
        } else {
            getString(R.string.no_sync)
        }
    }

    private fun onClick(v: View?) {
        when (v?.id) {
            R.id.addReport -> {
                addReport.isEnabled = false
                val dialog = DialogUtils.createProgressDialog(this)
                dialog.show()
                SyncBO.syncAndGetDiff({
                    dialog.hide()
                    openCreateReportScreen()
                }, {
                    dialog.hide()
                    openCreateReportScreen()
                }, {
                    dialog.hide()
                    openCreateReportScreen()
                })
            }
            R.id.load_list_report_btn -> {
                reportListViewModel.getReportsPaginated()
            }
        }
    }

    private fun openCreateReportScreen() {
        val intent = Intent(this, CreateReportActivity::class.java)
        startActivityForResult(intent, REQUEST_CREATE_REPORT)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        when (requestCode) {
            REQUEST_CREATE_REPORT -> handleCreateReportResult(resultCode)
        }
    }

    private fun handleCreateReportResult(resultCode: Int) {
        when (resultCode) {
            CreateReportActivity.RESULT_SUCCESS_SEND_REPORT -> ToastUtils.createToast(this, R.string.success_technical_report)
        }
    }
}
