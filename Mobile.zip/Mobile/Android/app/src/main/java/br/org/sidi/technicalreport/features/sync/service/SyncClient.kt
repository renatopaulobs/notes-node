/*
 *
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 *
 */

package br.org.sidi.technicalreport.features.sync.service

import br.org.sidi.technicalreport.features.sync.model.SyncData
import org.apache.http.HttpHeaders.IF_MODIFIED_SINCE
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Header

interface SyncClient {
    //ifModifiedSinceHeader sample: Tue, 12 Jun 2018 13:00:00 GMT
    @GET("report/syncdata")
    fun syncData(@Header(IF_MODIFIED_SINCE) ifModifiedSinceHeader: String): Call<SyncData>
}