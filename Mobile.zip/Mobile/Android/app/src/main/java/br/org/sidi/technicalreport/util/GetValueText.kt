/*
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 */
package br.org.sidi.technicalreport.util

import android.support.design.widget.TextInputLayout
import fr.ganfra.materialspinner.MaterialSpinner
import org.apache.commons.lang3.StringUtils

fun TextInputLayout.valueText(): String {
    return this.editText!!.text.toString()
}

fun MaterialSpinner.valueText(): String {
    return this.selectedItem?.toString() ?: StringUtils.EMPTY
}
