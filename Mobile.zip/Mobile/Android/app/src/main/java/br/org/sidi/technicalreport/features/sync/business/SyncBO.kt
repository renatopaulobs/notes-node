/*
 *
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 *
 */

package br.org.sidi.technicalreport.features.sync.business

import br.org.sidi.technicalreport.features.report.business.DefectRepository
import br.org.sidi.technicalreport.features.report.business.ProductRepository
import br.org.sidi.technicalreport.features.sync.model.SyncData
import br.org.sidi.technicalreport.features.sync.model.SyncDiff
import br.org.sidi.technicalreport.features.sync.service.SyncService

object SyncBO {
    fun hasEverDoneASuccessfulSync() = SyncService.getLastSyncDate() != null

    fun syncAndGetDiff(successCallback: (SyncDiff) -> Unit,
                       alreadyUpdatedCallback: () -> Unit,
                       failureCallback: () -> Unit) {
                SyncService.syncData({
                    successCallback(identifyChanges(it))
                    it?.let {
                        ProductRepository.clear()
                        DefectRepository.clear()
                        ProductRepository.add(it.products)
                        DefectRepository.add(it.defects)
                    }
                },
                { alreadyUpdatedCallback() },
                { failureCallback() })
    }

    private fun identifyChanges(newData: SyncData?): SyncDiff {
        if (newData == null) return SyncDiff()

        var allProducts = ProductRepository.list()
        var allDefects = DefectRepository.listEagerly()
        var allCauses = allDefects.map { it.causes }.flatten()

        newData.defects = newData.defects.map {
            it.productId = it.product.id
            it
        }

        var receivedCauses = newData.defects.map { it.causes.map { cause -> cause.defectId = it.id; cause } }.flatten()
        var allEvidenceTypes = allDefects.map { it.evidenceTypes }.flatten()
        var receivedEvidenceTypes = newData.defects.map { it.evidenceTypes.map {evidenceType -> evidenceType.defectId = it.id; evidenceType } }.flatten()

        val newProducts = newData.products.filter { it.id !in allProducts.map { product -> product.id } }
        val removedProducts = allProducts.filter { it.id !in newData.products.map { newProduct -> newProduct.id } }
        val changedProducts = allProducts.filter { it != newData.products.firstOrNull { product -> product.id == it.id } }
        val newDefects = newData.defects.filter { it.id !in allDefects.map { defect -> defect.id } }
        val removedDefects = allDefects.filter { it.id !in newData.defects.map { newDefect -> newDefect.id } }
        val changedDefects = allDefects.filter { it != newData.defects.firstOrNull { defect -> defect.id == it.id } }
        val newCauses = receivedCauses.filter { it.id !in allCauses.map { cause -> cause.id } }
        val removedCauses = allCauses.filter { it.id !in receivedCauses.map { newCause -> newCause.id } }
        val changedCauses = allCauses.filter { it != receivedCauses.firstOrNull { cause -> cause.id == it.id } }
        val newEvidenceTypes = receivedEvidenceTypes.filter { it.id !in allEvidenceTypes.map { evidenceType -> evidenceType.id } }
        val removedEvidenceTypes = allEvidenceTypes.filter { it.id !in receivedEvidenceTypes.map { newEvidenceType -> newEvidenceType.id } }
        val changedEvidenceTypes = allEvidenceTypes.filter { it != receivedEvidenceTypes.firstOrNull { evidenceType -> evidenceType.id == it.id && evidenceType.defectId == it.defectId } }
        return SyncDiff(newProducts,
                removedProducts,
                changedProducts,

                newDefects,
                removedDefects,
                changedDefects,

                newCauses,
                removedCauses,
                changedCauses,

                newEvidenceTypes,
                removedEvidenceTypes,
                changedEvidenceTypes)
    }
}