/*
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 */

package br.org.sidi.technicalreport.common.validation

import android.support.annotation.StringRes
import br.org.sidi.technicalreport.app.TechnicalReportApplication
import br.org.sidi.technicalreport.util.Logger

class Validation {
    companion object {
        const val COUNTRY_ALL = "ALL"
        const val COUNTRY_BR = "BR"
        const val COUNTRY_DEFAULT = COUNTRY_ALL
    }

    private var components : HashMap<Any, Pair<(component: Any) -> String?, (errorMessage: String?) -> Unit>> = HashMap()
    private var validations: HashMap<Any, HashMap<String, MutableList<Pair<(value: String?) -> Boolean, String>>>> = HashMap()

    data class Validator(val validationFunction: (value: String?) -> Boolean, @StringRes val errorMessageId: Int, val countryCode: String = COUNTRY_DEFAULT)

    fun addComponent(component: Any,
                     getValue: (component: Any) -> String?,
                     setError: (errorMessage: String?) -> Unit,
                     @StringRes errorMessageId: Int,
                     vararg validationFunction: (value: String?) -> Boolean,
                     countryCode: String = COUNTRY_DEFAULT) : Validation {
        return addComponent(component, getValue, setError, *validationFunction.map { Validator(it, errorMessageId, countryCode) }.toTypedArray() )
    }

    fun addComponent(component: Any, getValue: (component: Any) -> String?, setError: (errorMessage: String?) -> Unit, vararg validators: Validator) : Validation{
        addComponent(component, getValue,  setError)
        validators.forEach { addValidation(component, it.validationFunction, it.errorMessageId, it.countryCode) }
        return this
    }

    private fun addComponent(component: Any, getValue: (component: Any) -> String?, setError: (errorMessage: String?) -> Unit) : Validation {
        if (components.containsKey(component)){
            throw ValidationException("Component Already Exists")
        }

        components[component] = Pair(getValue, setError)
        return this
    }

    private fun addValidation(component: Any, validationFunction: (value: String?) -> Boolean, @StringRes errorMessage: Int, countryCode: String = COUNTRY_DEFAULT) : Validation {
        if (!components.containsKey(component)){
            throw ValidationException("Add component before adding validations")
        }

        if (!validations.containsKey(component)) {
            validations[component] = HashMap()
        }

        if (!validations[component]!!.containsKey(countryCode)){
            validations[component]!![countryCode] = ArrayList()
        }

        validations[component]!![countryCode]!!.add(Pair(validationFunction, TechnicalReportApplication.getStringRes(errorMessage)))

        return this
    }

    fun validate(countryCode: String): Int {
        var totalErrorCount = 0
        for(validationItem in validations){
            components[validationItem.key]!!.second.invoke(null)
            Logger.log("All errors cleared")

            for (validation in validationItem.value.filter { it.key == COUNTRY_ALL || it.key == countryCode }){
                for (validator in validation.value){
                    if (!validator.first.invoke(components[validationItem.key]!!.first.invoke(validationItem.key))){
                        components[validationItem.key]!!.second.invoke(validator.second)
                        totalErrorCount++
                    }
                }
            }
        }
        return totalErrorCount
    }
}