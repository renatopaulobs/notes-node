/*
 *
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 *
 */

package br.org.sidi.technicalreport.common.camera

import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.PersistableBundle
import android.support.v7.app.AppCompatActivity
import br.org.sidi.technicalreport.R
import br.org.sidi.technicalreport.features.report.view.GuidelinesActivity
import com.theartofdev.edmodo.cropper.CropImage
import kotlinx.android.synthetic.main.fragment_camera_basic.*


class CameraActivity : AppCompatActivity() {
    companion object {
        const val ORIENTATION = "DESIRED_ORIENTATION"
        const val MASK_TYPE = "MASK_TYPE"
        const val MASK_RESOURCE = "MASK_RESOURCE"
        const val IMAGE_PATH = "IMAGE_PATH"
        const val EVIDENCE_TITLE = "EVIDENCE_TITLE"
        const val FORCE_SKIP_GUIDELINE = "FORCE_SKIP_GUIDELINE"

        const val RESULT_FROM_GUIDELINES = 6548
        const val RESULT_FROM_IMAGE = 9843
        const val RESULT_FROM_GALLERY = 8455
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val forceSkipGuideline = intent.getBooleanExtra(FORCE_SKIP_GUIDELINE, false)
                || (savedInstanceState?.getBoolean(FORCE_SKIP_GUIDELINE, false) ?: false)

        if (forceSkipGuideline || GuidelinesActivity.neverOpenAgain()){
            setupCamera(savedInstanceState)
        } else {
            startActivityForResult(Intent(this, GuidelinesActivity::class.java), RESULT_FROM_GUIDELINES)
        }
    }

    override fun onSaveInstanceState(outState: Bundle?, outPersistentState: PersistableBundle?) {
        super.onSaveInstanceState(outState, outPersistentState)
        outState?.putBoolean(FORCE_SKIP_GUIDELINE, true)
    }

    private fun setupCamera(savedInstanceState: Bundle?) {
        val orientation = intent.getIntExtra(ORIENTATION, ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE)
        requestedOrientation = orientation

        setContentView(R.layout.activity_camera)

        savedInstanceState ?: supportFragmentManager.beginTransaction()
                .replace(R.id.cameraFrame, CameraFragment.newInstance())
                .commit()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        when(resultCode) {
            RESULT_FROM_GUIDELINES -> setupCamera(null)
            RESULT_OK -> {
                val orientation = intent.getIntExtra(ORIENTATION, ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE)
                requestedOrientation = orientation

                val evidenceTitle = intent.getStringExtra(CameraActivity.EVIDENCE_TITLE)

                if (requestCode == RESULT_FROM_GALLERY) {
                    val path = data?.data.toString()
                    val imageUri = Uri.parse(path)
                    CropImage.activity(imageUri)
                            .setActivityTitle(evidence_title.text)
                            .setCropMenuCropButtonTitle("OK")
                            .setInitialCropWindowPaddingRatio(0f)
                            .setAutoZoomEnabled(false)
                            .setAllowFlipping(false)
                            .setBackgroundColor(android.R.color.black)
                            .setActivityMenuIconColor(R.color.button_color)
                            .setOutputUri(imageUri)
                            .setOutputCompressQuality(85)
                            .setOutputCompressFormat(Bitmap.CompressFormat.JPEG)
                            .start(this)
                } else {
                    val path = CropImage.getActivityResult(data).uri.toString()
                    setResult(CameraActivity.RESULT_FROM_IMAGE,
                            Intent().putExtra(CameraActivity.IMAGE_PATH, path)
                                    .putExtra(CameraActivity.EVIDENCE_TITLE, evidenceTitle))
                    finish()
                }
            }
        }
    }
}
