/*
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 */

package br.org.sidi.technicalreport.features.report.business

import br.org.sidi.technicalreport.features.report.dao.AppDatabase
import br.org.sidi.technicalreport.features.report.model.Defect

object DefectRepository {

    fun listByProductIdEagerly(idProduct: Long) = AppDatabase.getInstance().defectDao().listByProductIdEagerly(idProduct).map { it.eager }

    fun count() = AppDatabase.getInstance().defectDao().count()

    fun count(productId: Long) = AppDatabase.getInstance().defectDao().count(productId)

    fun add(defects: List<Defect>) {
        var list = defects.map {
            it.productId = it.product.id
            it
        }
        AppDatabase.getInstance().defectDao().insert(list)

        list.forEach {
            CauseRepository.add(it.causes, it.id)
            EvidenceTypeRepository.add(it.evidenceTypes, it.id)
        }
    }

    fun listEagerly(): List<Defect> = AppDatabase.getInstance().defectDao().listEagerly().map { it.eager }

    fun clear() = AppDatabase.getInstance().defectDao().apply { this.delete(this.list()) }
}