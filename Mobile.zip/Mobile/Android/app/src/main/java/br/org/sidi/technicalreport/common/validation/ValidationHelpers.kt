/*
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 */

package br.org.sidi.technicalreport.common.validation

import android.support.design.widget.TextInputLayout
import android.support.v7.widget.AppCompatAutoCompleteTextView
import android.widget.EditText
import br.org.sidi.technicalreport.common.view.CustomSpinner
import br.org.sidi.technicalreport.util.Constant
import org.apache.commons.lang3.StringUtils
import org.apache.commons.validator.routines.EmailValidator
import java.util.regex.Pattern

class GetValueHelper {
    companion object {

        fun fromAutoComplete(view: Any): String? = (view as AppCompatAutoCompleteTextView).text.toString()

        fun fromEditText(view: Any): String? = (view as EditText).text.toString()

        fun fromCustomSpinnerPosition(view: Any): String? = (view as CustomSpinner).getSelectedItemPosition().value.toString()
    }
}

class CheckValueHelper {
    companion object {

        private val telephoneRegexPattern = Pattern.compile(Constant.TELEPHONE_REGULAR_EXPRESSION)
        private val forbiddenXssPattern = Pattern.compile(Constant.XSS_REGULAR_EXPRESSION)

        fun required(value: String?): Boolean = StringUtils.isNotBlank(value)
        fun noXSS(value: String?): Boolean = !forbiddenXssPattern.matcher(value).find()
        fun greaterThanZero(value: String?): Boolean = (value?.toInt() ?: -1) > 0
        fun email(email: String?): Boolean = StringUtils.isEmpty(email) || EmailValidator.getInstance().isValid(email)
        //if telephone is empty returns true because the required validation has a different message to show.
        fun telephone(telephone: String?): Boolean = if (!StringUtils.isEmpty(telephone)) { telephoneRegexPattern.matcher(telephone).find() } else { true }
    }
}

class SetErrorHelper {
    companion object {
        fun toInputLayout(inputLayout: TextInputLayout) = { err: String? ->
            inputLayout.apply {
                isErrorEnabled = (err != null)
                error = err
            }
            Unit
        }

        fun toCustomSpinner(spinner: CustomSpinner) = { err: String? ->
            spinner.error(err)
        }

        fun toAutoComplete(autoCompleteTextView: AppCompatAutoCompleteTextView) = {err: String? -> autoCompleteTextView.error = err }
    }
}