/*
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 */

package br.org.sidi.technicalreport.util

import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import org.apache.commons.lang3.StringUtils

private const val maskCNPJ = "##.###.###/####-##"
private const val maskCPF = "###.###.###-##"
const val CPF_MAX_LENGTH = 11
const val CNPJ_MAX_LENGTH = 14

private val onlyDigitsRegex = Regex("[^0-9]*")

fun String.onlyDigits() = this.replace(onlyDigitsRegex, StringUtils.EMPTY)

fun EditText.setCpfMask() = this.addTextChangedListener(MaskCpfCnpjTextWatcher(this, maskCPF))

fun EditText.setCpfCnpjMask() = this.addTextChangedListener(MaskCpfCnpjTextWatcher(this))

private fun calculateVerificationDigit(documentNumber: String, maxWeight: Int): Int {
    var sum = 0

    var weight = 2
    for (i in 0..(documentNumber.length - 1)) {
        val digit = Integer.parseInt(documentNumber[documentNumber.length - i - 1].toString())
        sum += digit * weight
        if (++weight > maxWeight) {
            weight = 2
        }
    }

    sum = 11 - sum % 11
    return if (sum > 9) 0 else sum
}

private fun isValidBrazilianTwoVerificationDigitsDocument(documentNumber: String, maxLength: Int, maxWeight: Int): Boolean =
        if (documentNumber.length != maxLength) {
            false
        } else {
            val baseDocument = documentNumber.substring(0, maxLength - 2)
            val firstDigit = calculateVerificationDigit(baseDocument, maxWeight)
            val secondDigit = calculateVerificationDigit(baseDocument + firstDigit, maxWeight)
            documentNumber == (baseDocument + firstDigit) + secondDigit
        }

fun isValidCPF(cpf: String): Boolean = isValidBrazilianTwoVerificationDigitsDocument(cpf, CPF_MAX_LENGTH, 11)

fun isValidCNPJ(cnpj: String): Boolean = isValidBrazilianTwoVerificationDigitsDocument(cnpj, CNPJ_MAX_LENGTH, 9)

fun isValidCPForCNPJ(documentNumber: String): Boolean = (isValidCPF(documentNumber) || isValidCNPJ(documentNumber))

class MaskCpfCnpjTextWatcher(private val editText: EditText,
                             private val mask: String = StringUtils.EMPTY) : TextWatcher {
    private var isChanging = false
    private var oldText = StringUtils.EMPTY

    override fun onTextChanged(currentText: CharSequence, start: Int, before: Int, count: Int) {
        val unmaskedText = currentText.toString().onlyDigits()
        val currentMask = if (StringUtils.isEmpty(mask))
            if (unmaskedText.length <= CPF_MAX_LENGTH) maskCPF else maskCNPJ
        else
            mask

        if (isChanging) {
            oldText = unmaskedText
            isChanging = false
            return
        }

        var position = 0
        val maskedTextBuilder = StringBuffer()
        for (currentChar in currentMask) {
            if (currentChar != '#'
                    && ((unmaskedText.length > oldText.length)
                            || (unmaskedText.length < oldText.length
                            && unmaskedText.length != position))) {
                maskedTextBuilder.append(currentChar)
            } else {
                if (position < unmaskedText.length) {
                    maskedTextBuilder.append(unmaskedText[position++])
                } else {
                    break
                }
            }
        }

        isChanging = true

        val maskedText = maskedTextBuilder.toString()
        editText.setText(maskedText)

        editText.setSelection(maskedText.length)
    }

    override fun afterTextChanged(s: Editable?) = Unit

    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
}