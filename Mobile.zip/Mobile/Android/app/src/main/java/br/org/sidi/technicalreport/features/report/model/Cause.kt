/*
 *
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 *
 */

package br.org.sidi.technicalreport.features.report.model

import android.arch.persistence.room.*
import br.org.sidi.technicalreport.features.report.model.Cause.Companion.CAUSE_TABLE_NAME
import java.io.Serializable

@Entity(tableName = CAUSE_TABLE_NAME,
        foreignKeys = [
            ForeignKey(entity = Defect::class,
                    parentColumns = [Defect.DEFECT_ID_COLUMN],
                    childColumns = [Defect.DEFECT_ID_COLUMN],
                    onDelete = ForeignKey.CASCADE)],
        indices = [(Index(Defect.DEFECT_ID_COLUMN))])
data class Cause(@PrimaryKey
                 @ColumnInfo(name=CAUSE_ID_COLUMN)
                 var id: Long,
                 var text: String,
                 var defectId: Long): Serializable {
    companion object {
        const val CAUSE_TABLE_NAME = "causes"
        const val CAUSE_ID_COLUMN = "causeId"
    }

    override fun toString(): String = text

    override fun equals(other: Any?): Boolean {
        if (other !is Cause) return false

        val cause : Cause = other
        return  this.id == cause.id
                && this.text == cause.text
                && this.defectId == cause.defectId
    }
}