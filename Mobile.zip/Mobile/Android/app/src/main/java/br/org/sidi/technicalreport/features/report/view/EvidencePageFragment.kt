/*
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 */
package br.org.sidi.technicalreport.features.report.view

import android.arch.lifecycle.Observer
import android.arch.lifecycle.ViewModelProviders
import android.content.Intent
import android.content.pm.ActivityInfo
import android.os.Bundle
import android.support.annotation.LayoutRes
import android.support.v7.widget.GridLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import br.org.sidi.technicalreport.R
import br.org.sidi.technicalreport.app.TechnicalReportApplication
import br.org.sidi.technicalreport.common.camera.CameraActivity
import br.org.sidi.technicalreport.common.validation.Validation
import br.org.sidi.technicalreport.common.validation.Validation.Companion.COUNTRY_BR
import br.org.sidi.technicalreport.features.report.model.Evidence
import br.org.sidi.technicalreport.features.report.model.EvidenceType
import br.org.sidi.technicalreport.features.report.model.Report
import br.org.sidi.technicalreport.features.report.viewmodel.EvidenceViewModel
import br.org.sidi.technicalreport.features.report.viewmodel.ReportViewModel
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.fragment_evidence.*
import kotlinx.android.synthetic.main.fragment_evidence.view.*
import org.apache.commons.lang3.StringUtils
import java.lang.ref.WeakReference

class EvidencePageFragment : AbstractReportPageFragment() {
    companion object {
        const val START_GET_IMAGE = 4685
        private const val EVIDENCE_TYPES = "adapterData"
        private const val EVIDENCE_PATHS = "pathsData"
    }

    private lateinit var rootView: View
    private var evidenceAdapter: EvidencesAdapter? = null
    private var forceSkipGuideline = false
    private var validation = Validation()

    private val evidenceViewModel: EvidenceViewModel by lazy { ViewModelProviders.of(this).get(EvidenceViewModel::class.java) }

    private val reportViewModel: ReportViewModel
        get() = (activity!! as CreateReportActivity).reportViewModel

    override fun onPageHide() {
        setValuesToViewModel()
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        reportViewModel.evidenceViewModel = evidenceViewModel

        reportViewModel.getDefectSelectedName().observe(this, Observer { defectSelectedName ->
            reportViewModel.updateEvidenceTypesByDefectName(defectSelectedName)
            reportViewModel.evidencePathMap = if (reportViewModel.evidenceTypeList.isEmpty()) {
                emptyMap<String, String?>().toMutableMap() as HashMap<String, String?>
            } else {
                reportViewModel.evidenceTypeList.map { it.description to null }.toMap<String, String?>() as HashMap<String, String?>
            }
            setupEvidenceCards()

            defect_not_selected.visibility = if (reportViewModel.evidenceTypeList.count() == 0) View.VISIBLE else View.GONE
        })

        rootView = container!!.inflate(R.layout.fragment_evidence, false)

        setupEvidenceCards()

        return rootView
    }

    private fun prepareValidation() {
        validation = Validation()

        reportViewModel.evidenceTypeList.forEach {
            validation.addComponent(it,
                    { _: Any -> reportViewModel.evidencePathMap[it.description] },
                    { errorMessage: String? -> evidenceAdapter?.setCardError(it.description, errorMessage != null) },
                    R.string.fill_all_pictures,
                    { value: String? -> value != null })
        }
    }

    private fun getEvidenceAdapter(): EvidencesAdapter {
        return evidenceAdapter ?: setupEvidenceCards()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)

        outState.putSerializable(EVIDENCE_TYPES, reportViewModel.evidenceTypeList.toTypedArray())
        outState.putSerializable(EVIDENCE_PATHS, reportViewModel.evidencePathMap)
    }

    private fun ViewGroup.inflate(@LayoutRes layoutRes: Int, attachToRoot: Boolean = false): View {
        return LayoutInflater.from(context).inflate(layoutRes, this, attachToRoot)
    }

    private fun setupEvidenceCards(): EvidencesAdapter {
        evidenceAdapter = EvidencesAdapter(reportViewModel.evidenceTypeList, WeakReference(this))
        rootView.grid_evidence.layoutManager = GridLayoutManager(context, 2)
        rootView.grid_evidence.adapter = evidenceAdapter

        prepareValidation()

        rootView.let {
            addTouchListener(it.grid_evidence)
        }

        return evidenceAdapter!!
    }

    fun validateFieldsEmpty() = validation.validate(COUNTRY_BR)

    fun openCameraForEvidence(evidenceType: EvidenceType) {
        Intent(TechnicalReportApplication.instance, CameraActivity::class.java).apply {
            putExtra(CameraActivity.MASK_TYPE, evidenceType.lightBoxMask)
            putExtra(CameraActivity.MASK_RESOURCE, evidenceType.id.toString())
            putExtra(CameraActivity.ORIENTATION, if (evidenceType.imageOrientation == EvidenceType.Orientation.LANDSCAPE) ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_PORTRAIT)
            putExtra(CameraActivity.EVIDENCE_TITLE, evidenceType.description)
            putExtra(CameraActivity.FORCE_SKIP_GUIDELINE, forceSkipGuideline)
            activity?.startActivityForResult(this, START_GET_IMAGE)
        }
        forceSkipGuideline = true
    }

    override fun onResume() {

        getEvidenceAdapter().holders.forEach {
            it.value.apply {
                val type = it.value.evidenceTitle.text.toString()
                val path = reportViewModel.evidencePathMap[type]
                val settingPath = path != null
                if (settingPath) {
                    getEvidenceAdapter().setCardOnClick(this, clear = true)
                }
                this.setButtonsVisibility(settingPath)
                Picasso.get().load(if (settingPath) path else null).into(this.imageEvidenceThumbnail)
                getEvidenceAdapter().setCardError(type, false)
            }
        }

        super.onResume()
    }

    fun setEvidencePath(type: String, path: String?, placeholder: String? = null) {
        getEvidenceAdapter().holders[type]?.apply {
            val settingPath = path != null
            if (settingPath) {
                getEvidenceAdapter().setCardOnClick(this, clear = true)
            }
            this.setButtonsVisibility(settingPath)
            Picasso.get().load(if (settingPath) path else placeholder).into(this.imageEvidenceThumbnail)
            getEvidenceAdapter().setCardError(type, false)
        }
    }

    override fun setValuesToViewModel() {
        reportViewModel.getReport().value?.evidences = getEvidence()
    }

    override fun setValuesToView(report: Report) {
        evidenceAdapter = setupEvidenceCards()
    }

    private fun getEvidence(): List<Evidence> =
            reportViewModel.evidencePathMap.map { evidence ->
                Evidence(evidenceType = reportViewModel.evidenceTypeList.first { it.description == evidence.key },
                        imagePath = evidence.value ?: StringUtils.EMPTY)
            }

}
