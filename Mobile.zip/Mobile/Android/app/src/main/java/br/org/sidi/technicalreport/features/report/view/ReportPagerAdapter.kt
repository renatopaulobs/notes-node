/*
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 */
package br.org.sidi.technicalreport.features.report.view

import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentStatePagerAdapter

class ReportPagerAdapter(fm: FragmentManager) : FragmentStatePagerAdapter(fm) {
    companion object {
        const val TOTAL_PAGES = 4

        const val CUSTOMER_PAGE_POSITION = 0
        const val TECHNICAL_REPORT_PAGE_POSITION = 1
        const val SYMPTOM_PAGE_POSITION = 2
        const val EVIDENCE_PAGE_POSITION = 3
    }

    private var fragmentList: MutableList<AbstractReportPageFragment> = mutableListOf()

    var currentTotalPages = 2

    init {
        val techReportPage = TechnicalReportPageFragment()
        val symptomPage = SymptomPageFragment()
        val evidencePage = EvidencePageFragment()

        fragmentList.add(CustomerPageFragment())
        fragmentList.add(techReportPage)
        fragmentList.add(symptomPage)
        fragmentList.add(evidencePage)
    }

    override fun getItem(position: Int): AbstractReportPageFragment {
        return fragmentList[position]
    }

    override fun getCount(): Int {
        return currentTotalPages
    }



}