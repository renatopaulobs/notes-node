/*
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 */

package br.org.sidi.technicalreport.features.report.view

import android.content.Context
import android.support.constraint.ConstraintLayout
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import br.org.sidi.technicalreport.R
import br.org.sidi.technicalreport.features.report.model.Report
import br.org.sidi.technicalreport.features.report.model.ReportWithEvidences
import br.org.sidi.technicalreport.util.DateUtils
import kotlinx.android.synthetic.main.report_list_item.view.*
import org.apache.commons.lang3.StringUtils
import org.jetbrains.anko.backgroundDrawable
import java.text.SimpleDateFormat
import java.util.*

class ReportListAdapter(private val rootContext: Context,
                        private var reports: MutableList<ReportWithEvidences>) :
        ArrayAdapter<Report>(rootContext, R.layout.report_list_item) {

    private var currentList: MutableList<ReportWithEvidences> = reports

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view = convertView
                ?: LayoutInflater.from(rootContext).inflate(R.layout.report_list_item, parent, false) as ConstraintLayout
        val reportWithEvidences = currentList[position]
        reportWithEvidences.report.let {
            view.service_order_label.text = String.format(rootContext.getString(R.string.os_number_title_pattern), it.SONumber, it.sequenceNumber)
            view.product_defect_label.text = String.format(rootContext.getString(R.string.prod_def_summary_report_pattern), it.productName, it.defectName)
            view.date_label.text = DateUtils.parseToListReplyFormat(SimpleDateFormat(rootContext.getString(R.string.format_date_with_hours)).format(Date(it.creationDate)))
            view.status_label.text = rootContext.getString(Report.ReportStatus.getStringResource(it.status))
            view.status_label.backgroundDrawable = rootContext.getDrawable(Report.ReportStatus.getShapeResource(it.status))
        }
        return view
    }

    override fun getItem(position: Int): Report? {
        if (position < currentList.size) {
            val result = currentList[position]
            result.report.apply { this.evidences = result.evidences.filter { it.reportId == result.report.id } }
            return result.report
        }
        return null
    }

    fun setData(newReports: MutableList<ReportWithEvidences>) {
        reports = newReports
        currentList = newReports
    }

    override fun getCount(): Int {
        return currentList.count()
    }

    fun filter(query: String?) {
        currentList = if (!query.isNullOrBlank()) {
            val queryFilter = query?.toLowerCase(Locale.getDefault())
            reports.filter {
                it.report.SONumber.toLowerCase(Locale.getDefault()).contains(queryFilter
                        ?: StringUtils.EMPTY, false)
            }.toMutableList()
        } else {
            reports
        }
        notifyDataSetChanged()
    }

}
