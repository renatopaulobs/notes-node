/*
 *
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 *
 */

package br.org.sidi.technicalreport.features.report.view

import android.arch.lifecycle.ViewModelProviders
import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.GridLayoutManager
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import br.org.sidi.technicalreport.R
import br.org.sidi.technicalreport.features.report.model.Report
import br.org.sidi.technicalreport.features.report.model.ReportSaveData
import br.org.sidi.technicalreport.features.report.viewmodel.PreviewReportViewModel
import br.org.sidi.technicalreport.util.ImageToBase64
import br.org.sidi.technicalreport.util.ToastUtils
import br.org.sidi.technicalreport.util.isOnline
import kotlinx.android.synthetic.main.activity_preview_report.*
import org.apache.commons.lang3.StringUtils
import org.jetbrains.anko.alert
import org.jetbrains.anko.progressDialog
import org.jetbrains.anko.textColor

class PreviewReportActivity : AppCompatActivity() {

    private val viewModel: PreviewReportViewModel by lazy { ViewModelProviders.of(this).get(PreviewReportViewModel::class.java) }
    private val dialog by lazy { progressDialog(getString(R.string.sending_technical_report)) }

    companion object {
        const val REPORT_KEY = "REPORT_KEY"
        const val ACTION_DETAILS = "ACTION_DETAILS"
        const val PREVIEW_REPORT = "br.org.sidi.technicalreport.features.report.view.PreviewReportActivity"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val title = intent.getStringExtra(Intent.EXTRA_TITLE)
        supportActionBar?.title = title ?: getString(R.string.new_report_title)

        setContentView(R.layout.activity_preview_report)

        supportActionBar?.setHomeAsUpIndicator(R.drawable.ic_baseline_close_24px)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.elevation = 0f

        send_button.setOnClickListener { onSendButtonClick() }
        back_button.setOnClickListener { finish() }

        setupReport()
        setupView()
    }

    private fun setupView() {
        val details = intent.getStringExtra(ACTION_DETAILS)
        when (details) {
            ReportListActivity.REPORT_LIST_ACTIVITY -> {
                send_button.visibility = View.GONE
                back_button.visibility = View.GONE
                preview.visibility = View.GONE
            }
        }
    }

    private fun setupReport() {
        val report = intent.getSerializableExtra(REPORT_KEY) as Report
        setupReport(report)
        viewModel.setupReportSaveData(report)
        recycler_view_id.layoutManager = GridLayoutManager(this, 2)
        recycler_view_id.adapter = ReportImagesAdapter(report.evidences)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater = menuInflater
        val details = intent.getStringExtra(ACTION_DETAILS)
        when (details) {
            ReportListActivity.REPORT_LIST_ACTIVITY -> {
                inflater.inflate(R.menu.menu_view_report, menu)
                val report = intent.getSerializableExtra(REPORT_KEY) as Report
                if (report.status != Report.ReportStatus.DRAFT.code) {
                    menu?.findItem(R.id.edit_report)?.isVisible = false
                    menu?.findItem(R.id.delete_report)?.isVisible = false
                }
            }
            else -> inflater.inflate(R.menu.menu_create_report, menu)
        }
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when (item?.itemId) {
            android.R.id.home -> finish()
            R.id.save_report -> {
                viewModel.saveReport()
                ToastUtils.createToast(this@PreviewReportActivity, R.string.report_saved_successfully)
            }
            R.id.delete_report -> {
                alert(String.format(getString(R.string.confirm_delete_report), viewModel.reportSaveData.productName, viewModel.reportSaveData.defectName, viewModel.reportSaveData.SONumber, viewModel.reportSaveData.sequenceNumber)) {
                    negativeButton(getString(R.string.cancel)) { it.cancel() }
                    positiveButton(getString(R.string.remove)) {
                        viewModel.deleteReport()
                        finish()
                        ToastUtils.createToast(this@PreviewReportActivity, R.string.report_removed_successfully)
                    }
                }.show()
            }
            R.id.edit_report -> {
                val intent = Intent(this@PreviewReportActivity, CreateReportActivity::class.java)
                intent.putExtra(Intent.EXTRA_TITLE, getString(R.string.edit_report_label))
                intent.putExtra(getString(R.string.action_details_key), PREVIEW_REPORT)
                intent.putExtra(getString(R.string.report_key), viewModel.reportSaveData.getReportFromReportSaveData())
                startActivity(intent)
            }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun convertEvidenceImage(report: ReportSaveData) {
        report.evidences = report.evidences.map {
            it.evidenceImage = ImageToBase64.encodeExternalBitmapToBase64(this, it.evidencePath!!)
            it
        }
    }

    private fun onSendButtonClick() {
        alert(getString(R.string.confirm_sending)) {
            positiveButton(getString(R.string.send_button)) {
                sendReport()
            }
            negativeButton(getString(R.string.cancel)) {}
        }.show()
    }

    private fun sendReport() {
        showDialog()
        convertEvidenceImage(viewModel.reportSaveData)
        viewModel.sendReport(viewModel.reportSaveData, {
            dialog.hide()
            setResult(CreateReportActivity.RESULT_SUCCESS_SEND_REPORT)
            finish()
        }, {
            dialog.hide()

            alert(getString(if (!isOnline()) R.string.no_internet_connection_send_report_msg else R.string.error_sending_report)) {
                positiveButton(getString(R.string.try_again)) { sendReport() }
                negativeButton(getString(R.string.save_button)) { it.cancel() }

            }.show()
        }, {
            alert(getString(R.string.error_out_of_sync)) {
                positiveButton(getString(R.string.btn_continue)) { _ ->
                    setResult(when {
                        it.product -> CreateReportActivity.RESULT_OUT_OF_SYNC_PRODUCT
                        it.defect -> CreateReportActivity.RESULT_OUT_OF_SYNC_DEFECT
                        it.cause -> CreateReportActivity.RESULT_OUT_OF_SYNC_CAUSE
                        else -> CreateReportActivity.RESULT_OUT_OF_SYNC_EVIDENCES
                    })
                    finish()
                }
                negativeButton(getString(R.string.cancel)) { it.cancel() }
            }.show()
        })
    }

    override fun onResume() {
        super.onResume()
        val id = viewModel.reportSaveData.id
        val report = viewModel.getReport(id)
        supportActionBar?.title = String.format(getString(R.string.prod_def_summary_report_pattern), report.productName, report.defectName)
        viewModel.setupReportSaveData(report)
        setupReport(report)
    }

    private fun showDialog() {
        dialog.setProgressNumberFormat(null)
        dialog.setProgressPercentFormat(null)
        dialog.setCancelable(false)
        dialog.isIndeterminate = true
        dialog.show()
    }

    private fun setNotFilledInTextView(field: TextView) {
        field.text = getString(R.string.not_filled_error)
        field.textColor = getColor(R.color.colorDefaultError)
    }

    private fun fill(field: TextView, value: String?) {
        field.text = value
        field.textColor = getColor(R.color.colorDefaultText)
    }

    private fun setupReport(report: Report) {
        if (report.customerName == StringUtils.EMPTY) {
            setNotFilledInTextView(name_or_social_name)
        } else {
            fill(name_or_social_name, report.customerName)
        }
        if (report.customerNaturalPersonDocument == StringUtils.EMPTY) {
            setNotFilledInTextView(person_document)
        } else {
            fill(person_document, report.customerNaturalPersonDocument)
        }
        if (report.customerTelephone == StringUtils.EMPTY) {
            setNotFilledInTextView(phone)
        } else {
            fill(phone, report.customerTelephone)
        }
        if (report.customerAddress == StringUtils.EMPTY) {
            setNotFilledInTextView(address)
        } else {
            fill(address, "${report.customerAddress.trim()}. ${report.customerCityName.trim()} - ${report.customerStateCode}")
        }
        if (report.productName == StringUtils.EMPTY) {
            setNotFilledInTextView(product)
        } else {
            fill(product, report.productName)
        }
        if (report.deviceModel == StringUtils.EMPTY) {
            setNotFilledInTextView(device_model)
        } else {
            fill(device_model, report.deviceModel)
        }
        if (report.deviceSN == StringUtils.EMPTY) {
            setNotFilledInTextView(serial_number)
        } else {
            fill(serial_number, report.deviceSN)
        }
        if (report.symptom == StringUtils.EMPTY) {
            setNotFilledInTextView(symptom)
        } else {
            fill(symptom, report.symptom)
        }
        if (report.defectName == StringUtils.EMPTY) {
            setNotFilledInTextView(defect)
        } else {
            fill(defect, report.defectName)
        }
        if (report.rootCauseText == StringUtils.EMPTY) {
            setNotFilledInTextView(diagnostic)
        } else {
            fill(diagnostic, report.rootCauseText)
        }
        if (report.conclusion == StringUtils.EMPTY) {
            setNotFilledInTextView(conclusion)
        } else {
            fill(conclusion, report.conclusion)
        }
        if (report.technicianName == StringUtils.EMPTY) {
            setNotFilledInTextView(technical_name)
        } else {
            fill(technical_name, report.technicianName)
        }
        if (report.technicianNaturalPersonDocument == StringUtils.EMPTY) {
            setNotFilledInTextView(technical_person_document)
        } else {
            fill(technical_person_document, report.technicianNaturalPersonDocument)
        }
        if (report.technicianProfessionalDocument == StringUtils.EMPTY) {
            setNotFilledInTextView(technical_document)
        } else {
            fill(technical_document, report.technicianProfessionalDocument)
        }
        if (report.customerEmail == StringUtils.EMPTY) {
            setNotFilledInTextView(email)
        } else {
            fill(email, report.customerEmail)
        }
        if (report.SONumber == StringUtils.EMPTY) {
            setNotFilledInTextView(service_order)
        } else {
            fill(service_order, report.SONumber)
        }
    }
}
