/*
 *
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 *
 */

package br.org.sidi.technicalreport.features.report.model

import android.arch.persistence.room.ColumnInfo
import android.arch.persistence.room.Entity
import android.arch.persistence.room.Ignore
import android.arch.persistence.room.PrimaryKey
import br.org.sidi.technicalreport.features.report.model.Evidence.Companion.EVIDENCE_TABLE
import org.apache.commons.lang3.StringUtils
import java.io.Serializable

@Entity(tableName = EVIDENCE_TABLE)
data class Evidence(@PrimaryKey(autoGenerate = true)
                    @ColumnInfo(name = EVIDENCE_ID_COLUMN)
                    var id: Long = 0,
                    var imagePath: String? = StringUtils.EMPTY,
                    @Ignore var evidenceType: EvidenceType = EvidenceType(),
                    var evidenceTypeId: Long = evidenceType.id,
                    var evidenceTypeDescription: String? = evidenceType.description,
                    var reportId: Long = 0,
                    var evidenceImage: String? = StringUtils.EMPTY) : Serializable {
    companion object {
        const val EVIDENCE_TABLE = "evidences"
        const val EVIDENCE_ID_COLUMN = "evidenceId"
    }
}

class EvidenceDTO(var evidenceTypeId: Long, var evidenceTypeDescription: String?,
                  var evidenceImage: String?, var evidencePath: String?)
