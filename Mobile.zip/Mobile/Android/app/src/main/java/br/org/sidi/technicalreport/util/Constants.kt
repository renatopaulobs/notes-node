/*
 * Copyright (c) 2018 Samsung Electronics Co., Ltd. , (c) Center of Informatics
 * Federal University of Pernambuco.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 */
package br.org.sidi.technicalreport.util

class Constant {
    companion object {
        const val TELEPHONE_REGULAR_EXPRESSION = "^(?:(?:|00)?\\s?)?(?:\\(?([1-9][0-9])\\)?\\s?)?(?:((?:9\\d|[2-9])\\d{3})\\-?(\\d{4}))\$"
        const val XSS_REGULAR_EXPRESSION = "(<[^>]*>[^>]*)+"
        const val REQUEST_PERMISSIONS = 1
        const val GMT_0_TIMEZONE = "UTC"
    }
}